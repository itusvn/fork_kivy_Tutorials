import mysql.connector

host = "localhost"
user = "root"
passwd = ""
db = "project_management"

def connection():
    return mysql.connector.connect(host=host, user=user, password=passwd, database=db)