import json
from kivy.clock import Clock
from kivy.uix.modalview import ModalView
from kivy.lang import Builder
from kivy.properties import StringProperty, ObjectProperty, NumericProperty, ListProperty
from kivymd.uix.pickers import MDModalDatePicker, MDTimePickerDialVertical
from data.connection import connection
from widgets.popups import WarningPopUp, ConfirmPopUp

Builder.load_string("""

""")