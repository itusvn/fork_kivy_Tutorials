from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

Builder.load_file('views/home/home.kv')

class Home(Screen):
    def on_enter(self, *args):
        return super().on_enter(*args)
