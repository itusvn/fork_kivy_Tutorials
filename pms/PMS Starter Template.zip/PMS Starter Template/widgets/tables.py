import json
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.behaviors import ButtonBehavior
from kivy.properties import StringProperty, ObjectProperty, NumericProperty
from kivy.lang import Builder
from data.connection import connection

Builder.load_string("""

""")