import hashlib
import mysql.connector

host = "localhost"
user = "root"
passwd = ""
db = "project_management"

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def connection():
    return mysql.connector.connect(host=host, user=user, password=passwd, database=db)

def insert_dummy_data():
    conn = None
    try:
        conn = connection()
        cur = conn.cursor()

        # Hashed password
        hashed_pw = hash_password("pass12345")

        # Insert one user
        cur.execute("""
            INSERT INTO users (name, email, phone, password)
            VALUES (%s, %s, %s, %s)
        """, ("John Doe", "john.doe@example.com", "1234567890", hashed_pw))

        # Get user_id
        cur.execute("SELECT id FROM users WHERE email = %s", ("john.doe@example.com",))
        user_id = cur.fetchone()[0]

        # Insert staff (all linked to the same user)
        cur.execute("""
            INSERT INTO staff (user_id, name, email, password, role)
            VALUES 
            (%s, 'Emily Carter', 'emily@example.com', %s, 'Project Manager'),
            (%s, 'Mark Johnson', 'mark@example.com', %s, 'Developer'),
            (%s, 'Sophia Lee', 'sophia@example.com', %s, 'Designer')
        """, (user_id, hashed_pw, user_id, hashed_pw, user_id, hashed_pw))

        # Insert projects
        cur.execute("""
            INSERT INTO projects (user_id, name, description, start_date, end_date, status)
            VALUES
            (%s, 'Website Overhaul', 'Redesign and improve the existing company website.', '2025-07-01', '2025-08-10', 'In Progress'),
            (%s, 'Mobile App Build', 'Develop a mobile application for internal task tracking.', '2025-06-20', '2025-09-01', 'Not Started')
        """, (user_id, user_id))

        # Get project IDs
        cur.execute("SELECT id FROM projects")
        project_ids = [row[0] for row in cur.fetchall()]

        # Get staff IDs
        cur.execute("SELECT id FROM staff")
        staff_ids = [row[0] for row in cur.fetchall()]

        # Insert tasks
        cur.execute("""
            INSERT INTO tasks (user_id, project_id, title, description, assigned_to, due_date, status)
            VALUES
            (%s, %s, 'Create Homepage Layout', 'Design the homepage UI layout', %s, '2025-07-05', 'Pending'),
            (%s, %s, 'Setup Database', 'Initialize and configure MySQL database', %s, '2025-07-08', 'In Progress'),
            (%s, %s, 'Design App Screens', 'Create wireframes for mobile app', %s, '2025-07-15', 'Pending')
        """, (
            user_id, project_ids[0], staff_ids[2],
            user_id, project_ids[0], staff_ids[1],
            user_id, project_ids[1], staff_ids[2]
        ))

        # Insert comments
        cur.execute("""
            INSERT INTO comments (user_id, task_id, staff_id, comment)
            VALUES
            (%s, 1, %s, 'Working on homepage sketches today.'),
            (%s, 2, %s, 'Database setup is nearly done.')
        """, (user_id, staff_ids[2], user_id, staff_ids[1]))

        # Insert attachments
        cur.execute("""
            INSERT INTO attachments (user_id, task_id, file_name)
            VALUES
            (%s, 1, 'homepage_layout.png'),
            (%s, 3, 'app_wireframes.pdf')
        """, (user_id, user_id))

        conn.commit()
        cur.close()
        print("Universal dummy data inserted successfully!")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    insert_dummy_data()
