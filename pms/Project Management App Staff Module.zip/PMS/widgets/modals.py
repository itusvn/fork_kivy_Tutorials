import json
from kivy.clock import Clock
from kivy.uix.modalview import ModalView
from kivy.lang import Builder
from kivy.properties import StringProperty, ObjectProperty, NumericProperty, ListProperty
from kivymd.uix.pickers import MDModalDatePicker, MDTimePickerDialVertical
from data.connection import connection
from widgets.popups import WarningPopUp, ConfirmPopUp

Builder.load_string("""
<NotificationsModal>:
    background: ""
    background_color: (0,0,0,0)
    
    AnchorLayout:
        anchor_x: "right"
        
        BoxLayout:
            size_hint_x: None
            width: "500dp"
            padding: [0, "40dp", "100dp", "20dp"]
            
            BoxLayout:
                orientation: "vertical"
                spacing: "20dp"
                canvas.before:
                    Color:
                        rgba: rgba("#ffffff")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(20)]
                        
                BoxLayout:
                    size_hint_y: None
                    height: "60dp"
                    spacing: "20dp"
                    padding: ["20dp", "20dp", "20dp", 0]
                    
                    MDLabel:
                        text: "Notifications"
                        font_style: "Label"
                        role: "large"
                        bold: True
                    
                    MDIconButton:
                        icon: "close"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}
                        on_press: root.dismiss()
                        
                BoxLayout:


############################################################################
<ProjectModal>:
    background: ""
    background_color: (0,0,0,0)
    
    AnchorLayout:
        padding: "50dp"
        anchor_x: "right"
            
        BoxLayout:
            orientation: "vertical"
            spacing: "20dp"
            canvas.before:
                Color:
                    rgba: rgba("#ffffff")
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(20)]
                    
            BoxLayout:
                size_hint_y: None
                height: "60dp"
                spacing: "20dp"
                padding: ["20dp", "20dp", "20dp", 0]
                
                MDLabel:
                    text: "Project"
                    font_style: "Label"
                    role: "large"
                    bold: True
                
                MDIconButton:
                    icon: "close"
                    theme_text_color: "Custom"
                    text_color: "#8d8a8c"
                    pos_hint: {"center_x": 0.5, "center_y": 0.5}
                    on_press: root.dismiss()
                    
            BoxLayout:
            
#########################################################
<AddProjectModal>:
    background: ""
    background_color: (0,0,0,0)
    
    AnchorLayout:
        padding: "50dp"
        anchor_x: "right"
            
        BoxLayout:
            size_hint_x: None
            width: "400dp"
            orientation: "vertical"
            spacing: "20dp"
            canvas.before:
                Color:
                    rgba: rgba("#ffffff")
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(20)]
                    
            BoxLayout:
                size_hint_y: None
                height: "60dp"
                spacing: "20dp"
                padding: ["20dp", "20dp", "20dp", 0]
                
                MDLabel:
                    id: modal_title
                    text: "Add project"
                    font_style: "Label"
                    role: "large"
                    bold: True
                
                MDIconButton:
                    icon: "close"
                    theme_text_color: "Custom"
                    text_color: "#8d8a8c"
                    pos_hint: {"center_x": 0.5, "center_y": 0.5}
                    on_press: root.dismiss()
                    
            BoxLayout:
                ScrollView:
                    bar_width: 0
                    bar_color: [0,0,0,0]
                    size_hint_y: None
                    height: self.parent.height

                    GridLayout:
                        cols: 1
                        size_hint_y: None
                        height: self.minimum_height
                        padding: "20dp"
                        spacing: "20dp"
                        
                        CustomFileChooser:
                            id: image
                        
                        CustomTextField:
                            id: name
                            icon: "briefcase-outline"
                            label: "Name"
                            hint_text: "Project name..."
                        
                        CustomTextFieldLarge:
                            id: description
                            size_hint_y: None
                            height: "120dp"
                            icon: "note-text-outline"
                            label: "Description"
                            hint_text: "Project description..."
                            
                        CustomDatePicker:
                            id: start_date
                            label: "Start date"
                            
                        CustomDatePicker:
                            id: end_date
                            label: "End date"
                            
                        CustomDropDown:
                            id: status
                            icon: ""
                            label: "Status"
                            text: "Select project's status..."
                            choices: ["In progress", "Not started", "Cancelled", "On-hold"]
                            
                        MDLabel:
                            id: error
                            size_hint_y: None
                            height: "25dp"
                            font_style: "Label"
                            role: "small"
                            color: "red"
                            halign: "center"
                            
                        CustomFlatButton:
                            id: modal_button
                            size_hint_y: None
                            height: "40dp"
                            text: "Add"
                            on_press: root.callback(root)
            
#########################################################
<StaffModal>:
    background: ""
    background_color: (0,0,0,0)
    
    AnchorLayout:
        padding: "50dp"
        anchor_x: "right"
            
        BoxLayout:
            size_hint_x: None
            width: "400dp"
            orientation: "vertical"
            spacing: "20dp"
            canvas.before:
                Color:
                    rgba: rgba("#ffffff")
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(20)]
                    
            BoxLayout:
                size_hint_y: None
                height: "60dp"
                spacing: "20dp"
                padding: ["20dp", "20dp", "20dp", 0]
                
                MDLabel:
                    id: modal_title
                    text: "Add staff"
                    font_style: "Label"
                    role: "large"
                    bold: True
                
                MDIconButton:
                    icon: "close"
                    theme_text_color: "Custom"
                    text_color: "#8d8a8c"
                    pos_hint: {"center_x": 0.5, "center_y": 0.5}
                    on_press: root.dismiss()
                    
            BoxLayout:
                ScrollView:
                    bar_width: 0
                    bar_color: [0,0,0,0]
                    size_hint_y: None
                    height: self.parent.height

                    GridLayout:
                        cols: 1
                        size_hint_y: None
                        height: self.minimum_height
                        padding: "20dp"
                        spacing: "20dp"
                        
                        CustomFileChooser:
                            id: image
                        
                        CustomTextField:
                            id: name
                            icon: "briefcase-outline"
                            label: "Name"
                            hint_text: "Staff member's name..."
                        
                        CustomTextField:
                            id: email
                            icon: "email-outline"
                            label: "Email"
                            hint_text: "Staff member's email address..."
                            
                        CustomTextFieldPassword:
                            id: password
                            icon: "lock-outline"
                            label: "Password"
                            hint_text: "Staff member's password..."
                            
                        CustomDropDown:
                            id: role
                            icon: "cog-outline"
                            label: "Role"
                            text: "Select staff member's role..."
                            choices: ["Project manager", "Designer", "Developer", "Digital marketer"]
                            
                        MDLabel:
                            id: error
                            size_hint_y: None
                            height: "25dp"
                            font_style: "Label"
                            role: "small"
                            color: "red"
                            halign: "center"
                            
                        CustomFlatButton:
                            id: modal_button
                            size_hint_y: None
                            height: "40dp"
                            text: "Add"
                            on_press: root.callback(root)
                        
                        

""")

class NotificationsModal(ModalView):
    id = NumericProperty()

###################################################

class ProjectModal(ModalView):
    id = NumericProperty()

###################################################
class AddProjectModal(ModalView):
    id_ = StringProperty()
    name = StringProperty()
    description = StringProperty()
    start_date = StringProperty()
    end_date = StringProperty()
    status = StringProperty()
    close = StringProperty()
    callback = ObjectProperty(allownone = True)

    def on_name(self, instance, name):
        self.ids.name.ids.text_input.text = name
        self.ids.modal_title.text = "Update project"
        self.ids.modal_button.text = "Update"

    def on_description(self, instance, description):
        self.ids.description.ids.text_input.text = description

    def on_start_date(self, instance, start_date):
        self.ids.start_date.text = start_date

    def on_end_date(self, instance, end_date):
        self.ids.end_date.text = end_date

    def on_status(self, instance, status):
        self.ids.status.text = status

    def on_close(self, instance, close):
        self.dismiss()

###################################################

###################################################
class StaffModal(ModalView):
    id_ = StringProperty()
    name = StringProperty()
    email = StringProperty()
    password = StringProperty()
    role = StringProperty()
    close = StringProperty()
    callback = ObjectProperty(allownone = True)

    def on_name(self, instance, name):
        self.ids.name.ids.text_input.text = name
        self.ids.modal_title.text = "Update staff"
        self.ids.modal_button.text = "Update"

    def on_email(self, instance, email):
        self.ids.email.ids.text_input.text = email

    def on_role(self, instance, role):
        self.ids.role.text = role

    def on_close(self, instance, close):
        self.dismiss()

###################################################
