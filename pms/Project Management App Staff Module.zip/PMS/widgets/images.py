from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.modalview import ModalView
from kivy.lang import Builder
from kivy.properties import StringProperty, ObjectProperty, NumericProperty, ListProperty

Builder.load_string("""
<CustomProfilePicture>:
    on_press: root.enlarge_image()
    padding: "1dp"
    canvas.before:
        Color:
            rgba: rgba("#6200EE")
        RoundedRectangle:
            size: self.size
            pos: self.pos
            radius: [self.height]
            
    BoxLayout:
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                size: self.size
                pos: self.pos
                radius: [self.height]
                source: root.source
                
###################################################################
<CustomImage>:
    on_press: root.enlarge_image()
    padding: "5dp"
            
    BoxLayout:
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                size: self.size
                pos: self.pos
                radius: [dp(5)]
                source: root.source
                
###################################################################
<EnlargedImage>:
    background: ""
    background_color: [0,0,0,0.7]
    
    AnchorLayout:
        anchor_x: "center"
        anchor_y: "center"
        
        BoxLayout:
            orientation: "vertical"
            padding: "20dp"
            spacing: "20dp"
            
            BoxLayout:
                size_hint_y: None
                height: "50dp"
                
                BoxLayout:
                
                FloatLayout:
                    size_hint_x: None
                    width: self.height
                    
                    MDIconButton:
                        icon: "close"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}
                        on_press: root.dismiss()
                        
            BoxLayout:
                Image:
                    source: root.source
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

""")

class CustomProfilePicture(ButtonBehavior, BoxLayout):
    source = StringProperty()

    def enlarge_image(self):
        enlarge_image = EnlargedImage()
        enlarge_image.source = self.source
        enlarge_image.open()

##########################################################################

class CustomImage(ButtonBehavior, BoxLayout):
    source = StringProperty()

    def enlarge_image(self):
        enlarge_image = EnlargedImage()
        enlarge_image.source = self.source
        enlarge_image.open()

##########################################################################

class EnlargedImage(ModalView):
    source = StringProperty()