import json
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.behaviors import ButtonBehavior
from kivy.properties import StringProperty, ObjectProperty, NumericProperty, ColorProperty
from kivy.lang import Builder
from data.connection import connection

Builder.load_string("""

<ProjectsTab>:
    size_hint_y: None
    height: "70dp"
    padding: ["10dp", 0]
    spacing: "10dp"
    on_press: root.update_callback(self)
    canvas.before:
        Color:
            rgba: root.bg_color
        Rectangle:
            pos: self.pos
            size: self.size
        Color:
            rgba: rgba("#e9e9e9")
        Rectangle:
            pos: self.pos
            size: [self.size[0], dp(1)]
            
    CustomImage:
        size_hint_x: None
        width: "70dp"
        source: root.source

    MDLabel:
        text: root.name
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.description
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.start_date
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.end_date
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.status
        font_style: "Label"
        role: "medium"
        
    FloatLayout:
        size_hint_x: None
        width: "40dp"
        
        MDIconButton:
            icon: "delete-outline"
            theme_text_color: "Custom"
            text_color: "#ff6666"
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            on_press: root.delete_callback(root)
        
################################################################

<StaffTab>:
    size_hint_y: None
    height: "70dp"
    padding: ["10dp", 0]
    spacing: "10dp"
    on_press: root.update_callback(self)
    canvas.before:
        Color:
            rgba: root.bg_color
        Rectangle:
            pos: self.pos
            size: self.size
        Color:
            rgba: rgba("#e9e9e9")
        Rectangle:
            pos: self.pos
            size: [self.size[0], dp(1)]
            
    CustomImage:
        size_hint_x: None
        width: "70dp"
        source: root.source

    MDLabel:
        text: root.name
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.email
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.role
        font_style: "Label"
        role: "medium"
        
    FloatLayout:
        size_hint_x: None
        width: "40dp"
        
        MDIconButton:
            icon: "delete-outline"
            theme_text_color: "Custom"
            text_color: "#ff6666"
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            on_press: root.delete_callback(root)

""")

class ProjectsTab(ButtonBehavior, BoxLayout):
    id_ = StringProperty()
    source = StringProperty()
    bg_color = ColorProperty()
    name = StringProperty()
    description = StringProperty()
    start_date = StringProperty()
    end_date = StringProperty()
    status = StringProperty()
    update_callback = ObjectProperty(allownone = True)
    delete_callback = ObjectProperty(allownone = True)

############################################################

class StaffTab(ButtonBehavior, BoxLayout):
    id_ = StringProperty()
    source = StringProperty()
    bg_color = ColorProperty()
    name = StringProperty()
    email = StringProperty()
    password = StringProperty()
    role = StringProperty()
    update_callback = ObjectProperty(allownone = True)
    delete_callback = ObjectProperty(allownone = True)
