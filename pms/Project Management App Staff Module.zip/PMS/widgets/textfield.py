import json

from kivy.clock import Clock
from kivy.lang import Builder
from kivy.metrics import dp
from kivy.properties import StringProperty, ListProperty, ObjectProperty, NumericProperty
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.dropdown import DropDown
from kivy.uix.textinput import TextInput

from data.connection import connection
from widgets.popups import WarningPopUp

Builder.load_string('''
<TextField>:
    cursor_color: [0,0,0,1]
    foreground_color: [0,0,0,1]
    background_color: 0, 0, 0, 0
    background_normal: ''
    background_active: ''
    write_tab: False
    font_size: "12sp"
    font_name: app.body
    
###############################
<CustomTextField>:
    size_hint_y: None
    height: "56dp"
    padding: "1dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(20)]
            
    BoxLayout:
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(20)]
    
        FloatLayout:
            size_hint_x: None
            width: self.height
    
            MDIcon:
                icon: root.icon
                theme_text_color: "Custom"
                text_color: "#000000"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
        BoxLayout:
            orientation: "vertical"
            padding: [0, "2.5dp"]
            
            BoxLayout:
                size_hint_y: None
                height: "20dp"
                padding: ["5dp", 0]
                        
                MDLabel:
                    text: root.label
                    font_style: "Label"
                    role: "small"
                    color: "#8d8a8c"
                
            BoxLayout:
                size_hint_y: None
                height: "30dp"
                canvas.before:
                    Color:
                        rgba: rgba("#ffffff")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(20)]
                        
                TextField:
                    id: text_input
                    multiline: "False"
                    hint_text: root.hint_text
    
###############################
<CustomTextFieldInt>:
    size_hint_y: None
    height: "56dp"
    padding: "1dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(20)]
            
    BoxLayout:
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(20)]
    
        FloatLayout:
            size_hint_x: None
            width: self.height
    
            MDIcon:
                icon: root.icon
                theme_text_color: "Custom"
                text_color: "#000000"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
        BoxLayout:
            orientation: "vertical"
            padding: [0, "2.5dp"]
            
            BoxLayout:
                size_hint_y: None
                height: "20dp"
                padding: ["5dp", 0]
                        
                MDLabel:
                    text: root.label
                    font_style: "Label"
                    role: "small"
                    color: "#8d8a8c"
                
            BoxLayout:
                size_hint_y: None
                height: "30dp"
                canvas.before:
                    Color:
                        rgba: rgba("#ffffff")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(20)]
                        
                TextField:
                    id: text_input
                    multiline: "False"
                    hint_text: root.hint_text
                    input_filter: "int"
    
###############################
<CustomTextFieldFloat>:
    size_hint_y: None
    height: "56dp"
    padding: "1dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(20)]
            
    BoxLayout:
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(20)]
    
        FloatLayout:
            size_hint_x: None
            width: self.height
    
            MDIcon:
                icon: root.icon
                theme_text_color: "Custom"
                text_color: "#000000"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
        BoxLayout:
            orientation: "vertical"
            padding: [0, "2.5dp"]
            
            BoxLayout:
                size_hint_y: None
                height: "20dp"
                padding: ["5dp", 0]
                        
                MDLabel:
                    text: root.label
                    font_style: "Label"
                    role: "small"
                    color: "#8d8a8c"
                
            BoxLayout:
                size_hint_y: None
                height: "30dp"
                canvas.before:
                    Color:
                        rgba: rgba("#ffffff")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(20)]
                        
                TextField:
                    id: text_input
                    multiline: "False"
                    hint_text: root.hint_text
                    input_filter: "float"
    
###############################
<CustomTextFieldPassword>:
    size_hint_y: None
    height: "56dp"
    padding: "1dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(20)]
            
    BoxLayout:
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(20)]
    
        FloatLayout:
            size_hint_x: None
            width: self.height
    
            MDIcon:
                icon: root.icon
                theme_text_color: "Custom"
                text_color: "#000000"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
        BoxLayout:
            orientation: "vertical"
            padding: [0, "2.5dp"]
            
            BoxLayout:
                size_hint_y: None
                height: "20dp"
                padding: ["5dp", 0]
                        
                MDLabel:
                    text: root.label
                    font_style: "Label"
                    role: "small"
                    color: "#8d8a8c"
                
            BoxLayout:
                size_hint_y: None
                height: "30dp"
                canvas.before:
                    Color:
                        rgba: rgba("#ffffff")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(20)]
                        
                TextField:
                    id: text_input
                    multiline: "False"
                    hint_text: root.hint_text
                    password: True
        
        FloatLayout:
            size_hint_x: None
            width: self.height

            MDIconButton:
                icon: "eye-off-outline" if text_input.password == True else "eye-outline"
                theme_text_color: "Custom"
                text_color: "#8d8a8c"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                on_press: root.show_password()
    
###############################
<CustomTextFieldLarge>:
    size_hint_y: None
    height: "76dp"
    padding: "1dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(20)]
            
    BoxLayout:
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(20)]
    
        BoxLayout:
            orientation: "vertical"
            size_hint_x: None
            width: "55dp"
    
            MDIcon:
                size_hint_y: None
                height: self.width
                icon: root.icon
                theme_text_color: "Custom"
                text_color: "#000000"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
            BoxLayout:
                
        BoxLayout:
            orientation: "vertical"
            padding: [0, "2.5dp"]
            
            BoxLayout:
                size_hint_y: None
                height: "20dp"
                padding: ["5dp", 0]
                        
                MDLabel:
                    text: root.label
                    font_style: "Label"
                    role: "small"
                    color: "#8d8a8c"
                
            BoxLayout:
                canvas.before:
                    Color:
                        rgba: rgba("#ffffff")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(20)]
                        
                TextField:
                    id: text_input
                    multiline: "False"
                    hint_text: root.hint_text
            
#########################################################################
        
''')

class TextField(TextInput):
    def __init__(self, **kw) -> None:
        super().__init__(**kw)
 
class CustomTextField(BoxLayout):
    icon = StringProperty()
    label = StringProperty()
    hint_text = StringProperty()

class CustomTextFieldInt(BoxLayout):
    icon = StringProperty()
    label = StringProperty()
    hint_text = StringProperty()

class CustomTextFieldFloat(BoxLayout):
    icon = StringProperty()
    label = StringProperty()
    hint_text = StringProperty()

class CustomTextFieldPassword(BoxLayout):
    icon = StringProperty()
    label = StringProperty()
    hint_text = StringProperty()

    def show_password(self):
        if self.ids.text_input.password:
            self.ids.text_input.password = False
        else:
            self.ids.text_input.password = True

class CustomTextFieldLarge(BoxLayout):
    icon = StringProperty()
    label = StringProperty()
    hint_text = StringProperty()