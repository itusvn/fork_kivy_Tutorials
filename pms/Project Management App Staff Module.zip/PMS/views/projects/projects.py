import json
from pathlib import Path

from kivy.clock import Clock
from kivy.properties import NumericProperty, ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivy.utils import rgba

from data.connection import connection
from widgets.modals import AddProjectModal
from widgets.popups import WarningPopUp, ConfirmPopUp
from widgets.tables import ProjectsTab

Builder.load_file('views/projects/projects.kv')

class Projects(Screen):
    user_id = NumericProperty()
    projects_in_db = ListProperty()
    def on_enter(self, *args):
        self.addProject = []
        self.updateProject = []
        self.deleteProject = None
        Clock.schedule_once(self.run_essentials, 0.1)

    def run_essentials(self, *args):
        self.get_user_id()
        self.show_projects_in_db()


    def get_user_id(self):
        try:
            SESSION_FILE = "session.json"
            with open(SESSION_FILE, "r") as file:
                session = json.load(file)
                self.user_id = session.get("user_id")
        except FileNotFoundError:
            return None

    def search(self):
        text = self.ids.search.text
        search_term = f"%{text.lower()}%"
        conn = connection()
        cursor = conn.cursor()
        try:
            self.projects_in_db = []
            sql = """
                SELECT * 
                FROM projects 
                WHERE user_id = %s AND (
                    LOWER(name) LIKE %s OR
                    LOWER(description) LIKE %s OR
                    LOWER(start_date) LIKE %s OR
                    LOWER(end_date) LIKE %s OR
                    LOWER(status) LIKE %s
                )
            """
            values = [
                str(self.user_id),
                search_term,
                search_term,
                search_term,
                search_term,
                search_term
            ]
            cursor.execute(sql, values)
            projects_in_db = cursor.fetchall()
            for x in projects_in_db:
                data = {
                    "id": str(x[0]),
                    "name": str(x[2]),
                    "description": str(x[3]),
                    "start_date": str(x[4]),
                    "end_date": str(x[5]),
                    "status": str(x[6])
                }

                self.projects_in_db.append(data)

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def show_projects_in_db(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            self.projects_in_db = []
            sql = "SELECT * FROM projects WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            projects_in_db = cursor.fetchall()
            for x in projects_in_db:
                data = {
                    "id": str(x[0]),
                    "name": str(x[2]),
                    "description": str(x[3]),
                    "start_date": str(x[4]),
                    "end_date": str(x[5]),
                    "status": str(x[6])
                }

                img = x[7]
                output_path =  Path("assets/images")
                output_path.mkdir(parents=True, exist_ok=True)

                safe_name = x[2].replace(" ", "_") + "_" + str(x[0])
                filename = f"{safe_name}.png"
                file_path = output_path / filename

                if img:
                    write_image = True
                    if file_path.exists():
                        with open(file_path, "rb") as existing_file:
                            existing_data = existing_file.read()
                            if existing_data == img:
                                write_image = False

                    if write_image:
                        with open(file_path, "wb") as g:
                            g.write(img)

                self.projects_in_db.append(data)

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def on_projects_in_db(self, instance, projects_in_db):
        table = self.ids.projects_in_db_list
        table.clear_widgets()
        for row_index, x in enumerate(projects_in_db):
            color = rgba("#ffffff") if row_index % 2 == 0 else rgba("#f9f9f9")
            name_ = x["name"]
            name = name_.replace(" ", "_") + "_" + str(x["id"])
            tableRow = ProjectsTab()
            tableRow.id_ = str(x["id"])
            tableRow.bg_color = color
            tableRow.source = f"assets/images/{name}.png"
            tableRow.name = str(x["name"])
            tableRow.description = str(x["description"])
            tableRow.start_date = str(x["start_date"])
            tableRow.end_date = str(x["end_date"])
            tableRow.status = str(x["status"])
            tableRow.update_callback = self.open_update_modal
            tableRow.delete_callback = self.delete_project
            table.add_widget(tableRow)

####################################################################

    def open_add_modal(self):
        add_modal = AddProjectModal()
        add_modal.callback = self.add_project
        add_modal.open()

####################################################################

    def open_update_modal(self, instance):
        update_modal = AddProjectModal()
        update_modal.id_ = instance.id_
        update_modal.name = instance.name
        update_modal.description = instance.description
        update_modal.start_date = instance.start_date
        update_modal.end_date = instance.end_date
        update_modal.status = instance.status
        update_modal.callback = self.update_project
        update_modal.open()

####################################################################

    def add_project(self, instance):
        name = instance.ids.name.ids.text_input.text
        description = instance.ids.description.ids.text_input.text
        start_date = instance.ids.start_date.ids.date.text
        end_date = instance.ids.end_date.ids.date.text
        status = instance.ids.status.text
        img = instance.ids.image.ids.text_input.text

        if name == "" or description == "" or start_date == "" or end_date == "" or status == "Select project's status...":
            instance.ids.error.text = "Fill in all required fields!"
        else:
            instance.close = "close"
            self.addProject = [name, description, start_date, end_date, status, img]
            add_project = ConfirmPopUp()
            add_project.title = "Are you sure you want to add this project?"
            add_project.callback = self.add_project_callback
            add_project.open()

    def add_project_callback(self, *args):
        name = self.addProject[0]
        description = self.addProject[1]
        start_date = self.addProject[2]
        end_date = self.addProject[3]
        status = self.addProject[4]
        img = self.addProject[5]

        if img == "Select image...":
            with open("assets/images/blank_projects.png", "rb") as file:
                binary_data = file.read()

        else:
            with open(img, "rb") as file:
                binary_data = file.read()

        conn = connection()
        cursor = conn.cursor()
        try:
            sql = "INSERT INTO projects (user_id, name, description, start_date, end_date, status, img) VALUES (%s,%s,%s,%s,%s,%s,%s)"
            values = [self.user_id, name, description, start_date, end_date, status, binary_data]
            cursor.execute(sql, values)
            conn.commit()
            self.show_projects_in_db()

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()


####################################################################

    def update_project(self, instance):
        id_ = instance.id_
        name = instance.ids.name.ids.text_input.text
        description = instance.ids.description.ids.text_input.text
        start_date = instance.ids.start_date.ids.date.text
        end_date = instance.ids.end_date.ids.date.text
        status = instance.ids.status.text
        img = instance.ids.image.ids.text_input.text

        if name == "" or description == "" or start_date == "" or end_date == "" or status == "Select project's status...":
            instance.ids.error.text = "Fill in all required fields!"
        else:
            instance.close = "close"
            self.updateProject = [id_, name, description, start_date, end_date, status, img]
            update_project = ConfirmPopUp()
            update_project.title = "Are you sure you want to update this project?"
            update_project.callback = self.update_project_callback
            update_project.open()

    def update_project_callback(self, *args):
        id_ = self.updateProject[0]
        name = self.updateProject[1]
        description = self.updateProject[2]
        start_date = self.updateProject[3]
        end_date = self.updateProject[4]
        status = self.updateProject[5]
        img = self.updateProject[6]

        if img == "Select image...":
            conn = connection()
            cursor = conn.cursor()
            try:
                sql = "UPDATE projects SET name=%s, description=%s, start_date=%s, end_date=%s, status=%s WHERE id=%s"
                values = [name, description, start_date, end_date, status, id_]
                cursor.execute(sql, values)
                conn.commit()
                self.show_projects_in_db()

            except Exception as error:
                warning_pop_up = WarningPopUp()
                warning_pop_up.title = f"{error}"
                warning_pop_up.open()

            finally:
                if conn:
                    conn.close()

        else:
            with open(img, "rb") as file:
                binary_data = file.read()

            conn = connection()
            cursor = conn.cursor()
            try:
                sql = "UPDATE projects SET name=%s, description=%s, start_date=%s, end_date=%s, status=%s, img=%s WHERE id=%s"
                values = [name, description, start_date, end_date, status, binary_data, id_]
                cursor.execute(sql, values)
                conn.commit()
                self.show_projects_in_db()

            except Exception as error:
                warning_pop_up = WarningPopUp()
                warning_pop_up.title = f"{error}"
                warning_pop_up.open()

            finally:
                if conn:
                    conn.close()










####################################################################

    def delete_project(self, instance):
        self.deleteProject = instance.id_
        add_project = ConfirmPopUp()
        add_project.title = "Are you sure you want to delete this project?"
        add_project.callback = self.delete_project_callback
        add_project.open()

    def delete_project_callback(self, *args):
        id_ = self.deleteProject

        conn = connection()
        cursor = conn.cursor()
        try:
            sql = "DELETE FROM projects WHERE id = %s"
            values = [id_]
            cursor.execute(sql, values)
            conn.commit()
            self.show_projects_in_db()

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()






















