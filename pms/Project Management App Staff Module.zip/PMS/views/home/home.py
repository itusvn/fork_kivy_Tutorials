import json

from kivy.clock import Clock
from kivy.properties import NumericProperty, StringProperty, ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivymd.app import MDApp

from data.connection import connection
from widgets.buttons import NavigationTab
from widgets.modals import ProjectModal, NotificationsModal
from widgets.popups import WarningPopUp, ConfirmPopUp

Builder.load_file('views/home/home.kv')

class Home(Screen):
    user_id = NumericProperty()
    user = StringProperty()
    role = StringProperty()
    projects_in_db = ListProperty()
    avatar = StringProperty()
    def on_enter(self, *args):
        Clock.schedule_once(self.run_essentials, 0.1)

    def run_essentials(self, *args):
        self.get_user_id()
        self.get_projects()

    def get_user_id(self):
        try:
            SESSION_FILE = "session.json"
            with open(SESSION_FILE, "r") as file:
                session = json.load(file)
                self.user_id = session.get("user_id")
                self.user = session.get("user")
                self.role = session.get("role")

                name_ = session.get("user")
                name = name_.replace(" ", "_") + "_" + str(session.get("staff_id"))
                self.avatar = f"assets/images/{name}.png"
        except FileNotFoundError:
            return None

    def get_projects(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            self.projects_in_db = []
            sql = "SELECT * FROM projects WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            projects_list = cursor.fetchall()
            for x in projects_list:
                data = {
                    "id": str(x[0]),
                    "name": x[2]
                }

                self.projects_in_db.append(data)

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def on_projects_in_db(self, instance, projects_in_db):
        table = self.ids.projects_in_db_list
        table.clear_widgets()
        for x in projects_in_db:
            navigationRow = NavigationTab()
            navigationRow.id = x["id"]
            navigationRow.icon = "briefcase-outline"
            navigationRow.text = x["name"]
            navigationRow.group = "navigation"
            navigationRow.bind(on_release = self.show_project)
            table.add_widget(navigationRow)

    def show_project(self, instance):
        project = ProjectModal()
        project.id = instance.id
        project.open()


    def logout(self):
        logout = ConfirmPopUp()
        logout.title = "Are you sure you want to log out?"
        logout.callback = self.logout_callback
        logout.open()

    def logout_callback(self, *args):
        SESSION_FILE = "session.json"
        with open(SESSION_FILE, "w") as file:
            json.dump({"user_id": self.user_id, "staff_id": 0, "user": "", "role": ""}, file)

        MDApp.get_running_app().root.ids.screen_manager.current = "login_screen"

    def show_notifications(self):
        notifications = NotificationsModal()
        notifications.id = self.user_id
        notifications.open()
