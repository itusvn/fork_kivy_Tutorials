import json
from pathlib import Path

from kivy.clock import Clock
from kivy.properties import NumericProperty, ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivy.utils import rgba

from data.connection import connection
from widgets.modals import StaffModal
from widgets.popups import WarningPopUp, ConfirmPopUp
from widgets.tables import StaffTab

Builder.load_file('views/staff/staff.kv')

class Staff(Screen):
    user_id = NumericProperty()
    staff_in_db = ListProperty()
    def on_enter(self, *args):
        self.addStaff = []
        self.updateStaff = []
        self.deleteStaff = None
        Clock.schedule_once(self.run_essentials, 0.1)

    def run_essentials(self, *args):
        self.get_user_id()
        self.show_staff_in_db()


    def get_user_id(self):
        try:
            SESSION_FILE = "session.json"
            with open(SESSION_FILE, "r") as file:
                session = json.load(file)
                self.user_id = session.get("user_id")
        except FileNotFoundError:
            return None

    def search(self):
        text = self.ids.search.text
        search_term = f"%{text.lower()}%"
        conn = connection()
        cursor = conn.cursor()
        try:
            self.staff_in_db = []
            sql = """
                SELECT * 
                FROM staff 
                WHERE user_id = %s AND (
                    LOWER(name) LIKE %s OR
                    LOWER(email) LIKE %s OR
                    LOWER(role) LIKE %s
                )
            """
            values = [
                str(self.user_id),
                search_term,
                search_term,
                search_term
            ]
            cursor.execute(sql, values)
            staff_in_db = cursor.fetchall()
            for x in staff_in_db:
                data = {
                    "id": str(x[0]),
                    "name": str(x[2]),
                    "email": str(x[3]),
                    "password": str(x[4]),
                    "role": str(x[5])
                }

                self.staff_in_db.append(data)

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def show_staff_in_db(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            self.staff_in_db = []
            sql = "SELECT * FROM staff WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            staff_in_db = cursor.fetchall()
            for x in staff_in_db:
                data = {
                    "id": str(x[0]),
                    "name": str(x[2]),
                    "email": str(x[3]),
                    "password": str(x[4]),
                    "role": str(x[5])
                }

                img = x[6]
                output_path =  Path("assets/images")
                output_path.mkdir(parents=True, exist_ok=True)

                safe_name = x[2].replace(" ", "_") + "_" + str(x[0])
                filename = f"{safe_name}.png"
                file_path = output_path / filename

                if img:
                    write_image = True
                    if file_path.exists():
                        with open(file_path, "rb") as existing_file:
                            existing_data = existing_file.read()
                            if existing_data == img:
                                write_image = False

                    if write_image:
                        with open(file_path, "wb") as g:
                            g.write(img)

                self.staff_in_db.append(data)

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def on_staff_in_db(self, instance, staff_in_db):
        table = self.ids.staff_in_db_list
        table.clear_widgets()
        for row_index, x in enumerate(staff_in_db):
            color = rgba("#ffffff") if row_index % 2 == 0 else rgba("#f9f9f9")
            name_ = x["name"]
            name = name_.replace(" ", "_") + "_" + str(x["id"])
            tableRow = StaffTab()
            tableRow.id_ = str(x["id"])
            tableRow.bg_color = color
            tableRow.source = f"assets/images/{name}.png"
            tableRow.name = str(x["name"])
            tableRow.email = str(x["email"])
            tableRow.password = str(x["password"])
            tableRow.role = str(x["role"])
            tableRow.update_callback = self.open_update_modal
            tableRow.delete_callback = self.delete_staff
            table.add_widget(tableRow)

####################################################################

    def open_add_modal(self):
        add_modal = StaffModal()
        add_modal.callback = self.add_staff
        add_modal.open()

####################################################################

    def open_update_modal(self, instance):
        update_modal = StaffModal()
        update_modal.id_ = instance.id_
        update_modal.name = instance.name
        update_modal.email = instance.email
        update_modal.password = instance.password
        update_modal.role = instance.role
        update_modal.callback = self.update_staff
        update_modal.open()

####################################################################

    def add_staff(self, instance):
        name = instance.ids.name.ids.text_input.text
        email = instance.ids.email.ids.text_input.text
        password = instance.ids.password.ids.text_input.text
        role = instance.ids.role.text
        img = instance.ids.image.ids.text_input.text

        if name == "" or email == "" or password == "" or role == "Select staff member's role...":
            instance.ids.error.text = "Fill in all required fields!"

        elif len(password) < 8:
            instance.ids.error.text = "Password must be at least 8 characters long!"

        else:
            instance.close = "close"
            self.addStaff = [name, email, password, role, img]
            add_staff = ConfirmPopUp()
            add_staff.title = "Are you sure you want to add this staff member?"
            add_staff.callback = self.add_staff_callback
            add_staff.open()

    def add_staff_callback(self, *args):
        name = self.addStaff[0]
        email = self.addStaff[1]
        password = self.addStaff[2]
        role = self.addStaff[3]
        img = self.addStaff[4]

        if img == "Select image...":
            with open("assets/images/avatar.png", "rb") as file:
                binary_data = file.read()

        else:
            with open(img, "rb") as file:
                binary_data = file.read()

        conn = connection()
        cursor = conn.cursor()
        try:
            sql = "INSERT INTO staff (user_id, name, email, password, role,img) VALUES (%s,%s,%s,%s,%s,%s)"
            values = [self.user_id, name, email, password, role, binary_data]
            cursor.execute(sql, values)
            conn.commit()
            self.show_staff_in_db()

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()


####################################################################

    def update_staff(self, instance):
        id_ = instance.id_
        name = instance.ids.name.ids.text_input.text
        email = instance.ids.email.ids.text_input.text
        password = instance.ids.password.ids.text_input.text
        role = instance.ids.role.text
        img = instance.ids.image.ids.text_input.text

        if name == "" or email == "" or password == "" or role == "Select staff member's role...":
            instance.ids.error.text = "Fill in all required fields!"

        elif len(password) < 8:
            instance.ids.error.text = "Password must be at least 8 characters long!"

        else:
            instance.close = "close"
            self.updateStaff = [id_, name, email, password, role,img]
            update_staff = ConfirmPopUp()
            update_staff.title = "Are you sure you want to update this staff member?"
            update_staff.callback = self.update_staff_callback
            update_staff.open()

    def update_staff_callback(self, *args):
        id_ = self.updateStaff[0]
        name = self.updateStaff[1]
        email = self.updateStaff[2]
        password = self.updateStaff[3]
        role = self.updateStaff[4]
        img = self.updateStaff[5]

        if img == "Select image...":
            conn = connection()
            cursor = conn.cursor()
            try:
                sql = "UPDATE staff SET name=%s, email=%s, password=%s, role=%s WHERE id=%s"
                values = [name, email, password, role, id_]
                cursor.execute(sql, values)
                conn.commit()
                self.show_staff_in_db()

            except Exception as error:
                warning_pop_up = WarningPopUp()
                warning_pop_up.title = f"{error}"
                warning_pop_up.open()

            finally:
                if conn:
                    conn.close()

        else:
            with open(img, "rb") as file:
                binary_data = file.read()

            conn = connection()
            cursor = conn.cursor()
            try:
                sql = "UPDATE staff SET name=%s, email=%s, password=%s, role=%s, img=%s WHERE id=%s"
                values = [name, email, password, role, binary_data, id_]
                cursor.execute(sql, values)
                conn.commit()
                self.show_staff_in_db()

            except Exception as error:
                warning_pop_up = WarningPopUp()
                warning_pop_up.title = f"{error}"
                warning_pop_up.open()

            finally:
                if conn:
                    conn.close()










####################################################################

    def delete_staff(self, instance):
        self.deleteStaff = instance.id_
        add_staff = ConfirmPopUp()
        add_staff.title = "Are you sure you want to delete this staff member?"
        add_staff.callback = self.delete_staff_callback
        add_staff.open()

    def delete_staff_callback(self, *args):
        id_ = self.deleteStaff

        conn = connection()
        cursor = conn.cursor()
        try:
            sql = "DELETE FROM staff WHERE id = %s"
            values = [id_]
            cursor.execute(sql, values)
            conn.commit()
            self.show_staff_in_db()

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()






















