from kivy.lang import Builder
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.dropdown import DropDown
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.spinner import Spinner
from kivy.properties import StringProperty, ListProperty, NumericProperty, ObjectProperty
from kivy.uix.behaviors import ToggleButtonBehavior, ButtonBehavior
from kivymd.uix.behaviors import RectangularRippleBehavior, CommonElevationBehavior, BackgroundColorBehavior
from kivymd.uix.pickers import MDModalDatePicker, MDTimePickerDialVertical

from widgets.popups import WarningPopUp

Builder.load_string("""
<NavigationTab>:
    background_normal: ''
    background_down: ''
    background_color: [0,0,0,0]
    size_hint_y: None
    height: "40dp"
    allow_no_selection: False
    canvas.before:
        Color:
            rgba: [0,0,0,0] if root.state == "normal" else [0.4,0,0.933,.1]
        Rectangle:
            pos: self.pos
            size: self.size
                    
    FloatLayout:
        size_hint_x: None
        width: self.height
        MDIcon:
            icon: root.icon
            theme_text_color: "Custom"
            text_color: rgba("#000000") if root.state == "normal" else rgba("#6200EE")
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
    MDLabel:
        text: root.text
        valign: "middle"
        font_style: "Label"
        role: "medium"
        # bold: True
        color: rgba("#000000") if root.state == "normal" else rgba("#6200EE")

##########################################################
<NavigationTabHoz>:
    orientation: "vertical"
    background_normal: ''
    background_down: ''
    background_color: [0,0,0,0]
    size_hint_y: None
    height: "35dp"
    spacing: "4dp"
    allow_no_selection: False
    
    BoxLayout:
        padding: ["10dp", 0]
        spacing: "4dp"
                
        FloatLayout:
            size_hint_x: None
            width: self.height
    
            MDIcon:
                icon: root.icon
                theme_text_color: "Custom"
                text_color: rgba("#6c696b")
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
        MDLabel:
            text: root.text
            valign: "middle"
            font_style: "Label"
            role: "medium"
            bold: True
            color: rgba("#6c696b") if root.state == "normal" else rgba("#6200EE")
    
    BoxLayout:
        size_hint_y: None
        height: "1dp" if root.state == "normal" else "3dp"
        canvas.before:
            Color:
                rgba: rgba("#6c696b") if root.state == "normal" else rgba("#6200EE")
            Rectangle:
                pos: self.pos
                size: self.size

#####################################
<CustomButton>:
    theme_elevation_level: "Custom"
    elevation_level: 1
    theme_shadow_offset: "Custom"
    shadow_offset: 0, -1
    theme_shadow_softness: "Custom"
    shadow_softness: 1
    background_normal: ''
    background_down: ''
    background_color: [0,0,0,0]
    radius: [dp(20),dp(20),dp(20),dp(20)]
            
    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIcon:
            icon: root.icon
            theme_text_color: "Custom"
            text_color: "#ffffff"
            pos_hint: {"center_x":0.5, "center_y":0.5}
            
    MDLabel:
        text: root.text
        font_style: "Label"
        role: "medium"
        bold: True
        color: "#ffffff"

#####################################
<CustomFlatButton>:
    theme_elevation_level: "Custom"
    elevation_level: 1
    theme_shadow_offset: "Custom"
    shadow_offset: 0, -1
    theme_shadow_softness: "Custom"
    shadow_softness: 1
    background_normal: ''
    background_down: ''
    background_color: [0,0,0,0]
    radius: [dp(20),dp(20),dp(20),dp(20)]
            
    MDLabel:
        text: root.text
        font_style: "Title"
        role: "medium"
        bold: True
        halign: "center"
        color: "#ffffff"
            
#########################################################################
                    
<DropDownWidgetList>:
    orientation: "vertical"
    canvas.before:
        Color:
            rgba: rgba("#f7f7f7")
        RoundedRectangle:
            size: self.size
            pos: self.pos
            radius: [5,5,5,5]

    BoxLayout:
        padding: ['10dp', 0]
        
        MDLabel:
            text: root.text
            font_style: "Label"
            role: "medium"
            halign: "center"
        
    BoxLayout:
        size_hint_y: None
        height: "1dp"
        canvas.before:
            Color:
                rgba: rgba("#e9e9e9")
            Rectangle:
                size: self.size
                pos: self.pos

#########################################################################
                    
<DropDownWidget>:
    orientation: "vertical"
    canvas.before:
        Color:
            rgba: rgba("#f7f7f7")
        RoundedRectangle:
            size: self.size
            pos: self.pos
            radius: [5,5,5,5]

    BoxLayout:
        padding: ['10dp', 0]
        
        MDLabel:
            text: root.text
            font_style: "Label"
            role: "medium"
            halign: "center"
        
    BoxLayout:
        size_hint_y: None
        height: "1dp"
        canvas.before:
            Color:
                rgba: rgba("#e9e9e9")
            Rectangle:
                size: self.size
                pos: self.pos
        


#####################################
<CustomDropDownList>:
    background_normal: ''
    background_down: ''
    background_color: [0,0,0,0]
    size_hint_y: None
    height: "56dp"
    padding: "1dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(20)]
            
    BoxLayout:
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(20)]
    
        FloatLayout:
            size_hint_x: None
            width: self.height
    
            MDIcon:
                icon: root.icon
                theme_text_color: "Custom"
                text_color: "#000000"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
        BoxLayout:
            orientation: "vertical"
            padding: [0, "2.5dp"]
            
            BoxLayout:
                size_hint_y: None
                height: "20dp"
                padding: ["5dp", 0]
                        
                MDLabel:
                    text: root.label
                    font_style: "Label"
                    role: "small"
                    color: "#8d8a8c"
                
            BoxLayout:
                size_hint_y: None
                height: "30dp"
                padding: ["5dp", 0]
                canvas.before:
                    Color:
                        rgba: rgba("#ffffff")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [5,5,5,5]

                MDLabel:
                    id: text_input
                    text: root.text
                    font_style: "Label"
                    role: "medium"
                    color: "#000000"
            
        FloatLayout:
            size_hint_x: None
            width: self.height
            
            MDIcon:
                icon: "chevron-down"
                theme_text_color: "Custom"
                text_color: "#8d8a8c"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
        

#####################################
<CustomDropDown>:
    background_normal: ''
    background_down: ''
    background_color: [0,0,0,0]
    size_hint_y: None
    height: "56dp"
    padding: "1dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(20)]
            
    BoxLayout:
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(20)]
    
        FloatLayout:
            size_hint_x: None
            width: self.height
    
            MDIcon:
                icon: root.icon
                theme_text_color: "Custom"
                text_color: "#000000"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
        BoxLayout:
            orientation: "vertical"
            padding: [0, "2.5dp"]
            
            BoxLayout:
                size_hint_y: None
                height: "20dp"
                padding: ["5dp", 0]
                        
                MDLabel:
                    text: root.label
                    font_style: "Label"
                    role: "small"
                    color: "#8d8a8c"
                
            BoxLayout:
                size_hint_y: None
                height: "30dp"
                padding: ["5dp", 0]
                canvas.before:
                    Color:
                        rgba: rgba("#ffffff")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [5,5,5,5]

                MDLabel:
                    id: text_input
                    text: root.text
                    font_style: "Label"
                    role: "medium"
                    color: "#000000"
            
        FloatLayout:
            size_hint_x: None
            width: self.height
            
            MDIcon:
                icon: "chevron-down"
                theme_text_color: "Custom"
                text_color: "#8d8a8c"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
                
##################################################################3
<CustomDatePicker>:
    background_normal: ''
    background_down: ''
    background_color: [0,0,0,0]
    size_hint_y: None
    height: "56dp"
    padding: "1dp"
    on_press: root.open_date_picker()
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(20)]
            
    BoxLayout:
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(20)]
        
        FloatLayout:
            size_hint_x: None
            width: self.height
            
            MDIcon:
                icon: "calendar"
                theme_text_color: "Custom"
                text_color: "#000000"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
        BoxLayout:
            orientation: "vertical"
            padding: [0, "2.5dp"]
            
            BoxLayout:
                size_hint_y: None
                height: "20dp"
                padding: ["5dp", 0]
                        
                MDLabel:
                    text: root.label
                    font_style: "Label"
                    role: "small"
                    color: "#8d8a8c"
                
            BoxLayout:
                size_hint_y: None
                height: "30dp"
                padding: ["5dp", 0]
                canvas.before:
                    Color:
                        rgba: rgba("#ffffff")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [5,5,5,5]

                MDLabel:
                    id: date
                    text: root.text
                    font_style: "Label"
                    role: "medium"
                    color: "#000000"
        
        FloatLayout:
            size_hint_x: None
            width: self.height
            
            MDIcon:
                icon: "chevron-down"
                theme_text_color: "Custom"
                text_color: "#8d8a8c"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
                
##################################################################3
<CustomTimePicker>:
    background_normal: ''
    background_down: ''
    background_color: [0,0,0,0]
    size_hint_y: None
    height: "56dp"
    padding: "1dp"
    on_press: root.open_time_picker()
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(20)]
            
    BoxLayout:
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(20)]
        
        FloatLayout:
            size_hint_x: None
            width: self.height
            
            MDIcon:
                icon: "clock-outline"
                theme_text_color: "Custom"
                text_color: "#000000"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
        BoxLayout:
            orientation: "vertical"
            padding: [0, "2.5dp"]
            
            BoxLayout:
                size_hint_y: None
                height: "20dp"
                padding: ["5dp", 0]
                        
                MDLabel:
                    text: root.label
                    font_style: "Label"
                    role: "small"
                    color: "#8d8a8c"
                
            BoxLayout:
                size_hint_y: None
                height: "30dp"
                padding: ["5dp", 0]
                canvas.before:
                    Color:
                        rgba: rgba("#ffffff")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [5,5,5,5]

                MDLabel:
                    id: time
                    text: root.text
                    font_style: "Label"
                    role: "medium"
                    color: "#000000"
        
        FloatLayout:
            size_hint_x: None
            width: self.height
            
            MDIcon:
                icon: "chevron-down"
                theme_text_color: "Custom"
                text_color: "#8d8a8c"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
        
"""
)
class NavigationTab(ToggleButtonBehavior, BoxLayout):
    id = NumericProperty()
    icon = StringProperty()
    text = StringProperty()

    # def on_id
    #
    # def show_project(self, instance):
    #     project = ProjectModal()
    #     project.id = instance.id
    #     project.open()

######################################################

class NavigationTabHoz(ToggleButtonBehavior, BoxLayout):
    icon = StringProperty()
    text = StringProperty()

######################################################

class CustomButton(RectangularRippleBehavior, CommonElevationBehavior, ButtonBehavior, BoxLayout, BackgroundColorBehavior):
    icon = StringProperty()
    text = StringProperty()

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.md_bg_color = "#6200EE"

######################################################

class CustomFlatButton(RectangularRippleBehavior, CommonElevationBehavior, ButtonBehavior, BoxLayout, BackgroundColorBehavior):
    text = StringProperty()

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.md_bg_color = "#6200EE"

######################################################

class CustomDropDownList(ButtonBehavior, BoxLayout):
    icon = StringProperty()
    label = StringProperty()
    text = StringProperty()
    choices = ListProperty()
    suggestion_widget = ObjectProperty(allownone=True)
    callback = ObjectProperty(allownone=True)
    dropdown = ObjectProperty(None, allownone=True)

    def on_release(self):
        if self.dropdown:
            self.dropdown.dismiss()
            self.dropdown = None
        else:
            self.show_suggestions()

    def show_suggestions(self):
        try:
            self.dropdown = DropDown()
            self.dropdown.auto_width = False
            self.dropdown.size_hint_x = None
            self.dropdown.width = self.width

            for c in self.choices:
                suggestion_widget = DropDownWidgetList()
                suggestion_widget.id = str(c['id'])
                suggestion_widget.text = str(c['text'])
                suggestion_widget.size_hint_y = None
                suggestion_widget.height = dp(40)
                suggestion_widget.bind(on_release=self.suggest)

                self.dropdown.add_widget(suggestion_widget)

            if self.choices:
                self.dropdown.open(self)
        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

    def suggest(self, instance):
        self.text = instance.text
        if self.callback:
            self.callback(instance)
        if self.dropdown:
            self.dropdown.dismiss()
            self.dropdown = None

######################################################

class CustomDropDown(ButtonBehavior, BoxLayout):
    icon = StringProperty()
    label = StringProperty()
    text = StringProperty()
    choices = ListProperty()
    suggestion_widget = ObjectProperty(allownone=True)
    dropdown = ObjectProperty(None, allownone=True)

    def on_release(self):
        if self.dropdown:
            self.dropdown.dismiss()
            self.dropdown = None
        else:
            self.show_suggestions()

    def show_suggestions(self):
        try:
            self.dropdown = DropDown()
            self.dropdown.auto_width = False
            self.dropdown.size_hint_x = None
            self.dropdown.width = self.width

            for c in self.choices:
                suggestion_widget = DropDownWidget()
                suggestion_widget.text = str(c)
                suggestion_widget.size_hint_y = None
                suggestion_widget.height = dp(40)
                suggestion_widget.bind(on_release=self.suggest)

                self.dropdown.add_widget(suggestion_widget)

            if self.choices:
                self.dropdown.open(self)
        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

    def suggest(self, instance):
        self.text = instance.text
        if self.dropdown:
            self.dropdown.dismiss()
            self.dropdown = None

######################################################

class DropDownWidgetList(ButtonBehavior, BoxLayout):
    id = NumericProperty()
    text = StringProperty()

######################################################

class DropDownWidget(ButtonBehavior, BoxLayout):
    text = StringProperty()

######################################################

class CustomDatePicker(ButtonBehavior, BoxLayout):
    label = StringProperty()
    text = StringProperty()

    def open_date_picker(self):
        date_picker = MDModalDatePicker()
        date_picker.bind(on_ok = self.on_date_ok)
        date_picker.bind(on_cancel = self.on_date_cancel)
        date_picker.open()

    def on_date_ok(self, instance_date_picker):
        self.ids.date.text = str(instance_date_picker.get_date()[0])
        instance_date_picker.dismiss()

    def on_date_cancel(self, instance_date_picker):
        instance_date_picker.dismiss()

######################################################

class CustomTimePicker(ButtonBehavior, BoxLayout):
    label = StringProperty()
    text = StringProperty()

    def open_time_picker(self):
        time_picker = MDTimePickerDialVertical()
        time_picker.bind(on_ok = self.on_date_ok)
        time_picker.bind(on_cancel = self.on_date_cancel)
        time_picker.open()

    def on_date_ok(self, instance_time_picker):
        self.ids.time.text = str(instance_time_picker.time)
        instance_time_picker.dismiss()

    def on_date_cancel(self, instance_time_picker):
        instance_time_picker.dismiss()
