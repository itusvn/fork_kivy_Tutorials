from kivy.uix.floatlayout import FloatLayout
from kivy.uix.modalview import ModalView
from kivy.properties import ObjectProperty, StringProperty, ListProperty
from kivy.lang import Builder

Builder.load_string("""

<ConfirmPopUp>:
    background: ""
    background_color: [0,0,0,0.1]
    MDCard:
        orientation: "vertical"
        radius: "5dp"
        size_hint: None, None
        size: "400dp","125dp"
        padding: "10dp"
        spacing: "10dp"

        MDLabel:
            text: root.title
            font_style: "Label"
            role: "medium"
            halign: "center"

        BoxLayout:
            size_hint_y: None
            height: "40dp"
            spacing: "10dp"

            BoxLayout:


            CustomButton:
                size_hint_x: None
                width: "100dp"
                icon: "cancel"
                text: "No"
                on_press: root.dismiss()

            CustomButton:
                size_hint_x: None
                width: "100dp"
                icon: "thumb-up-outline"
                text: "Yes"
                on_press: 
                    root.callback(self)
                    root.dismiss()

##############################################################

<WarningPopUp>:
    background: ''
    background_color: [0,0,0,0.1]

    MDCard:
        orientation: "vertical"
        radius: "5dp"
        size_hint: None,None
        size: "400dp", "120dp"
        padding: "10dp"
        spacing: "10dp"

        MDLabel:
            text: root.title
            halign: "center"
            font_style: "Title"
            role: "small"

        BoxLayout:
            size_hint_y: None
            height: "40dp"
            spacing: "15dp"

            BoxLayout:

            CustomButton:
                size_hint_x: None
                width: "100dp"
                icon: "close"
                text: "Cancel"
                on_release: root.dismiss()

            BoxLayout:

""")


class ConfirmPopUp(ModalView):
    title = StringProperty()
    callback = ObjectProperty(allownone=True)


##########################################################################

class WarningPopUp(ModalView):
    title = StringProperty()