from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivymd.uix.behaviors import CommonElevationBehavior, BackgroundColorBehavior


class CustomBoxLayout(CommonElevationBehavior, BackgroundColorBehavior, BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.md_bg_color = "white"
        self.theme_elevation_level = "Custom"
        self.elevation_level = 1
        self.theme_shadow_effect = "Custom"
        self.shadow_effect = (0, -1)
        self.theme_shadow_softness = "Custom"
        self.shadow_softness = 4
        self.radius = [dp(20),dp(20),dp(20),dp(20)]


class CustomFloatLayout(CommonElevationBehavior, BackgroundColorBehavior, FloatLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.md_bg_color = "white"
        self.theme_elevation_level = "Custom"
        self.elevation_level = 1
        self.theme_shadow_effect = "Custom"
        self.shadow_effect = (0, -1)
        self.theme_shadow_softness = "Custom"
        self.shadow_softness = 4
        self.radius = [dp(20),dp(20),dp(20),dp(20)]