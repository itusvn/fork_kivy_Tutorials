from kivymd.app import MDApp
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder

height = 650
width = 1050
Window.size = (width, height)

Builder.load_string("""

#: import Splash views.splash.Splash
#: import Auth views.auth.Auth
#: import Login views.login.Login
#: import Home views.home.Home
#: import Projects views.projects.Projects
#: import Staff views.staff.Staff
                    
#: import NavigationTab widgets.buttons.NavigationTab
#: import NavigationTabHoz widgets.buttons.NavigationTabHoz
#: import CustomButton widgets.buttons.CustomButton
#: import CustomFlatButton widgets.buttons.CustomFlatButton
#: import CustomDropDownList widgets.buttons.CustomDropDownList
#: import CustomDropDown widgets.buttons.CustomDropDown
#: import TextField widgets.textfield.TextField
#: import CustomTextField widgets.textfield.CustomTextField
#: import CustomTextFieldInt widgets.textfield.CustomTextFieldInt
#: import CustomTextFieldFloat widgets.textfield.CustomTextFieldFloat
#: import CustomTextFieldPassword widgets.textfield.CustomTextFieldPassword
#: import CustomTextFieldLarge widgets.textfield.CustomTextFieldLarge
#: import CustomBoxLayout widgets.layouts.CustomBoxLayout
#: import CustomFloatLayout widgets.layouts.CustomFloatLayout
#: import Factory kivy.factory.Factory

<MainWindow>:
    orientation: 'vertical'
    canvas.before:
        Color:
            rgba: rgba("#ffffff")
        Rectangle:
            size: self.size
            pos: self.pos

    ScreenManager:
        id: screen_manager

        Splash:
            name: 'splash_screen'

        Login:
            name: 'login_screen'

        Auth:
            name: 'auth_screen'

        Home:
            name: 'home_screen'

""")


class MainWindow(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class MainApp(MDApp):
    body = "assets/fonts/OpenSans-Regular.ttf"
    bold = "assets/fonts/OpenSans-Bold.ttf"
    semibold = "assets/fonts/OpenSans-Semibold.ttf"

    def build(self):
        Window.maximize()
        return MainWindow()


if __name__ == "__main__":
    MainApp().run()
