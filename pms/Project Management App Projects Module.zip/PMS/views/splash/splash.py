import json

from kivy.clock import Clock
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivymd.app import MDApp

Builder.load_file('views/splash/splash.kv')

class Splash(Screen):
    def on_enter(self, *args):
        Clock.schedule_once(self.switch_screens, 10)

    def switch_screens(self, *args):
        try:
            SESSION_FILE = "session.json"
            with open(SESSION_FILE, "r") as file:
                session = json.load(file)
                user_id = session.get("user_id")

                if user_id == 0:
                    MDApp.get_running_app().root.ids.screen_manager.current = "auth_screen"
                else:
                    MDApp.get_running_app().root.ids.screen_manager.current = "login_screen"

        except FileNotFoundError:
            return None
