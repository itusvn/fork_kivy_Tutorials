import hashlib
import json

from kivy.clock import Clock
from kivy.properties import StringProperty, NumericProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivymd.app import MDApp

from data.connection import connection
from widgets.popups import WarningPopUp

Builder.load_file('views/login/login.kv')

class Login(Screen):
    user_id = NumericProperty()
    staff_id = StringProperty()
    def on_enter(self, *args):
        Clock.schedule_once(self.run_essentials, 0.1)

    def run_essentials(self, *args):
        self.get_user_id()
        self.get_staff()
        self.clear()

    def get_user_id(self):
        try:
            SESSION_FILE = "session.json"
            with open(SESSION_FILE, "r") as file:
                session = json.load(file)
                self.user_id = session.get("user_id")
        except FileNotFoundError:
            return None

    def clear(self):
        self.ids.name.ids.text_input.text = "Select your name..."
        self.ids.password.ids.text_input.text = ""


    def get_staff(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            sql = "SELECT * FROM staff WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            staff_list = cursor.fetchall()
            list_of_staff = []
            for x in staff_list:
                data = {
                    "id": str(x[0]),
                    "text": x[2]
                }

                list_of_staff.append(data)

            self.ids.name.choices = list_of_staff

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()


    def add_name_choice(self, instance):
        self.staff_id = str(instance.id)

    def login(self):
        name = self.ids.name.ids.text_input.text
        password = self.ids.password.ids.text_input.text

        if name == "Select your name..." or password == "":
            self.ids.error.text = "Fill in all required fields!"

        elif len(password) < 8:
            self.ids.error.text = "Password must be 8 or more character!"

        else:
            self.ids.error.text = ""
            conn = connection()
            cursor = conn.cursor()
            try:
                sql = "SELECT * FROM staff WHERE id = %s AND name = %s"
                values = [self.staff_id, name]
                cursor.execute(sql, values)
                staff = cursor.fetchall()

                if not staff:
                    self.ids.error.text = "Invalid credentials!"

                else:
                    for x in staff:
                        password_in_db = x[4]
                        role = x[5]

                        password_hashed = hashlib.sha256(password.encode()).hexdigest()

                        if password_hashed == password_in_db:
                            SESSION_FILE = "session.json"
                            with open(SESSION_FILE, "w") as file:
                                json.dump({"user_id": self.user_id, "staff_id": self.staff_id, "user": name, "role": role}, file)

                            MDApp.get_running_app().root.ids.screen_manager.current = "home_screen"

                        else:
                            self.ids.error.text = "Invalid credentials!"



            except Exception as error:
                warning_pop_up = WarningPopUp()
                warning_pop_up.title = f"{error}"
                warning_pop_up.open()

            finally:
                if conn:
                    conn.close()

























