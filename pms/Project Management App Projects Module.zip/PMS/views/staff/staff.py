from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

Builder.load_file('views/staff/staff.kv')

class Staff(Screen):
    def on_enter(self, *args):
        return super().on_enter(*args)
