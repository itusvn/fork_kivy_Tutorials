import sqlite3

# Connect to database (creates file if not exists)
conn = sqlite3.connect("assets/data/inventory.db")
cursor = conn.cursor()

# Create table
cursor.execute("""
CREATE TABLE IF NOT EXISTS inventory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    price REAL NOT NULL,
    img_path TEXT
)
""")


# List of 10 dummy inventory items
dummy_items = [
    ("BURG001", "Burger 1", "Burger", 750.00, "assets/images/burger_1.jpg"),
    ("BURG002", "Burger 2", "Burger", 0.50, "assets/images/burger_2.jpg"),
    ("BURG003", "Burger 3", "Burger", 2.00, "assets/images/burger_3.jpg"),
    ("BURG004", "Burger 4", "Burger", 10.00, "assets/images/burger_4.jpg"),
    ("DES001", "Dessert 1", "Dessert", 5.00, "assets/images/dessert_1.jpg"),
    ("DES002", "Dessert 2", "Dessert", 60.00, "assets/images/dessert_2.jpg"),
    ("DES003", "Dessert 3", "Dessert", 25.00, "assets/images/dessert_3.jpg"),
    ("DES004", "Dessert 4", "Dessert", 50.00, "assets/images/dessert_4.jpg"),
    ("DRINK001", "Drink 1", "Drink", 120.00, "assets/images/drink_1.jpg"),
    ("DRINK002", "Drink 2", "Drink", 80.00, "assets/images/drink_2.jpg"),
    ("DRINK003", "Drink 3", "Drink", 0.50, "assets/images/drink_3.jpg"),
    ("DRINK004", "Drink 4", "Drink", 2.00, "assets/images/drink_4.jpg"),
    ("FRIES001", "Fries 1", "Fries", 10.00, "assets/images/fries_1.jpg"),
    ("FRIES002", "Fries 2", "Fries", 5.00, "assets/images/fries_2.jpg"),
    ("FRIES003", "Fries 3", "Fries", 60.00, "assets/images/fries_3.jpg"),
    ("FRIES004", "Fries 4", "Fries", 25.00, "assets/images/fries_4.jpg")
]

# Insert dummy items using a for loop
for item in dummy_items:
    try:
        cursor.execute("""
        INSERT INTO inventory (code, name, category, price, img_path)
        VALUES (?, ?, ?, ?, ?)
        """, item)
    except sqlite3.IntegrityError:
        print(f"Item with code {item[0]} already exists.")

# Commit changes
conn.commit()

# Commit changes
conn.commit()

# Fetch all items
cursor.execute("SELECT * FROM inventory")
rows = cursor.fetchall()

print("Inventory Items:")
for row in rows:
    print(row)

# Close connection
conn.close()
