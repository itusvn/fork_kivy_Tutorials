from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.spinner import Spinner
from kivy.properties import StringProperty
from kivy.uix.behaviors import ToggleButtonBehavior, ButtonBehavior

Builder.load_string("""

"""
)
