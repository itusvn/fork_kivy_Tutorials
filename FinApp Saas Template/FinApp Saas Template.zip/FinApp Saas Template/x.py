import psycopg2

hostname = "localhost"
database = "fin"
username = "mt"
password = "mt12345678"
port = 5432

conn = None
cursor = None

try:
    conn = psycopg2.connect(host=hostname,dbname=database,user=username,password=password,port=port)
    cursor = conn.cursor()

    ###USERS
    script = """CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            first_name varchar(255) NOT NULL,
            last_name varchar(255) NOT NULL,
            phone varchar(255) NOT NULL,
            email varchar(255) NOT NULL,
            username varchar(255) NOT NULL,
            password varchar(255) NOT NULL
            )"""

    cursor.execute(script)
    conn.commit()
    print("Created table: ma users")

    ###TRANSACTIONS
    script = """CREATE TABLE IF NOT EXISTS transactions (
            id SERIAL PRIMARY KEY,
            user_id  INT,
            date varchar(255) NOT NULL,
            account varchar(255) NOT NULL,
            category varchar(255) NOT NULL,
            type varchar(255) NOT NULL,
            recipient varchar(255) NOT NULL,
            amount varchar(255) NOT NULL,
            method varchar(255) NOT NULL,
            notes varchar(255) NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
            )"""

    cursor.execute(script)
    conn.commit()
    print("Created table: ma transactions")

    ###ACCOUNTS
    script = """CREATE TABLE IF NOT EXISTS accounts (
            id SERIAL PRIMARY KEY,
            user_id  INT,
            account varchar(255) NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
            )"""

    cursor.execute(script)
    conn.commit()
    print("Created table: accounts")

    ###CATEGORIES
    script = """CREATE TABLE IF NOT EXISTS categories (
            id SERIAL PRIMARY KEY,
            user_id  INT,
            category varchar(255) NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
            )"""

    cursor.execute(script)
    conn.commit()
    print("Created table: categories")

except Exception as error:
    print(error)

finally:
    if conn is not None:
        conn.close()
    if cursor is not None:
        cursor.close()
