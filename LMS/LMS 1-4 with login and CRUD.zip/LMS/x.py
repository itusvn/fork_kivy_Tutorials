import psycopg2

def create_tables():
    commands = [
        """
        CREATE TABLE students (
            id SERIAL PRIMARY KEY,
            avatar VARCHAR(255),
            name VARCHAR(100) NOT NULL,
            grade INT NOT NULL,
            class VARCHAR(10) NOT NULL,
            username VARCHAR(50) UNIQUE NOT NULL,
            dob DATE NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            phone VARCHAR(20),
            address TEXT,
            password VARCHAR(255) NOT NULL
        )
        """,
        """
        CREATE TABLE classes (
            id SERIAL PRIMARY KEY,
            class VARCHAR(10) NOT NULL,
            grade INT NOT NULL,
            capacity INT NOT NULL,
            supervisor VARCHAR(100) NOT NULL
        )
        """,
        """
        CREATE TABLE notices (
            id SERIAL PRIMARY KEY,
            subject VARCHAR(100) NOT NULL,
            announcement TEXT NOT NULL,
            date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        """
        CREATE TABLE parents (
            id SERIAL PRIMARY KEY,
            avatar VARCHAR(255),
            name VARCHAR(100) NOT NULL,
            student_id INT NOT NULL,
            username VARCHAR(50) UNIQUE NOT NULL,
            dob DATE NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            phone VARCHAR(20),
            address TEXT,
            password VARCHAR(255) NOT NULL,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        )
        """,
        """
        CREATE TABLE subjects (
            id SERIAL PRIMARY KEY,
            subject_name VARCHAR(100) NOT NULL,
            teacher VARCHAR(100) NOT NULL
        )
        """,
        """
        CREATE TABLE teachers (
            id SERIAL PRIMARY KEY,
            avatar VARCHAR(255),
            name VARCHAR(100) NOT NULL,
            username VARCHAR(50) UNIQUE NOT NULL,
            dob DATE NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            phone VARCHAR(20),
            address TEXT,
            password VARCHAR(255) NOT NULL
        )
        """
    ]

    conn = None
    try:
        conn = psycopg2.connect(
            dbname="lms",
            user="mtech",
            password="12345678Mtech",
            host="localhost",
            port="5432"
        )
        cur = conn.cursor()

        for command in commands:
            cur.execute(command)

        cur.close()
        conn.commit()
    except Exception as error:
        print(f"Error: {error}")
    finally:
        if conn is not None:
            conn.close()


if __name__ == "__main__":
    create_tables()
