import psycopg2
from kivy.clock import Clock
from kivy.uix.modalview import ModalView
from kivy.lang import Builder
from kivymd.uix.filemanager import MDFileManager
from kivy.properties import StringProperty, ObjectProperty
from kivymd.uix.pickers import MDModalDatePicker, MDTimePickerDialVertical

Builder.load_string("""
<TeacherModal>:
    background: ""
    background_color: [0,0,0,0]
    
    AnchorLayout:
        anchor_x: "right"
        
        BoxLayout:
            orientation: "vertical"
            size_hint_x: None
            width: "400dp"
            padding: "10dp"
            spacing: "40dp"
            canvas.before:
                Color:
                    rgba: [1,1,1,1]
                Rectangle:
                    pos: self.pos
                    size: self.size
                    
            BoxLayout:
                size_hint_y: None
                height: "35dp"
                spacing: "10dp"
                
                MDLabel:
                    id: modal_title
                    text: "Add teacher"
                    font_style: "Label"
                    role: "large"
                    bold: True
                    
                FloatLayout:
                    size_hint_x: None
                    width: self.height
                    
                    MDIconButton:
                        icon: "close"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        on_press: root.dismiss()
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}
                        
            BoxLayout:
                orientation: "vertical"
                spacing: "10dp"
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Name"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: name
                        hint_text: "Teacher's full name..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Username"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: username
                        hint_text: "Teacher's username..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "65dp"
                        text: "D.O.B"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    MDLabel:
                        id: dob
                        font_style: "Label"
                        role: "medium"
                        
                    FloatLayout:
                        size_hint_x: None
                        width: self.height
        
                        MDIconButton:
                            icon: "calendar"
                            theme_text_color: "Custom"
                            text_color: "#8d8a8c"
                            pos_hint: {"center_x": 0.5, "center_y": 0.5}
                            on_press: root.show_date_picker()
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Email"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: email
                        hint_text: "Teacher's email address..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Phone"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: phone
                        hint_text: "Teacher's phone number..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Address"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: address
                        hint_text: "Teacher's physical address..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Password"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: password
                        password: True
                        hint_text: "Teacher's password..."
                        multiline: False
                        
                    FloatLayout:
                        size_hint_x: None
                        width: self.height
        
                        MDIconButton:
                            icon: "eye-off-outline" if password.password == True else "eye-outline"
                            theme_text_color: "Custom"
                            text_color: "#8d8a8c"
                            pos_hint: {"center_x": 0.5, "center_y": 0.5}
                            on_press: root.view_password()
                            
                CustomFlatButton:
                    id: avatar
                    size_hint_y: None
                    height: "35dp"
                    text: "Add Image"
                    on_press: root.add_image()
                    
                MDLabel:
                    id: error
                    size_hint_y: None
                    height: "30dp"
                    halign: "center"
                    font_style: "Label"
                    role: "small"
                    
                CustomFlatButton:
                    id: modal_button
                    size_hint_y: None
                    height: "35dp"
                    text: "Add"
                    on_press: root.callback(root)
                    
                BoxLayout:
                    
#######################################################STUDENTS MODAL
<StudentModal>:
    background: ""
    background_color: [0,0,0,0]
    
    AnchorLayout:
        anchor_x: "right"
        
        BoxLayout:
            orientation: "vertical"
            size_hint_x: None
            width: "400dp"
            padding: "10dp"
            spacing: "40dp"
            canvas.before:
                Color:
                    rgba: [1,1,1,1]
                Rectangle:
                    pos: self.pos
                    size: self.size
                    
            BoxLayout:
                size_hint_y: None
                height: "35dp"
                spacing: "10dp"
                
                MDLabel:
                    id: modal_title
                    text: "Add student"
                    font_style: "Label"
                    role: "large"
                    bold: True
                    
                FloatLayout:
                    size_hint_x: None
                    width: self.height
                    
                    MDIconButton:
                        icon: "close"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        on_press: root.dismiss()
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}
                        
            BoxLayout:
                orientation: "vertical"
                spacing: "10dp"
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Name"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: name
                        hint_text: "Teacher's full name..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "65dp"
                        text: "Grade"
                        font_style: "Label"
                        role: "medium"
                        bold: True

                    CustomDropDown:
                        id: grade
                        text: "Select grade..."
                        values: ["1","2","3","4","5","6","7","8"]
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "65dp"
                        text: "Class"
                        font_style: "Label"
                        role: "medium"
                        bold: True

                    CustomDropDown:
                        id: classes
                        text: "Select class..."
                        values: ["A","B","C","D","E","F","G","H"]
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Username"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: username
                        hint_text: "Teacher's username..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "65dp"
                        text: "D.O.B"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    MDLabel:
                        id: dob
                        font_style: "Label"
                        role: "medium"
                        
                    FloatLayout:
                        size_hint_x: None
                        width: self.height
        
                        MDIconButton:
                            icon: "calendar"
                            theme_text_color: "Custom"
                            text_color: "#8d8a8c"
                            pos_hint: {"center_x": 0.5, "center_y": 0.5}
                            on_press: root.show_date_picker()
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Email"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: email
                        hint_text: "Teacher's email address..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Phone"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: phone
                        hint_text: "Teacher's phone number..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Address"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: address
                        hint_text: "Teacher's physical address..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Password"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: password
                        password: True
                        hint_text: "Teacher's password..."
                        multiline: False
                        
                    FloatLayout:
                        size_hint_x: None
                        width: self.height
        
                        MDIconButton:
                            icon: "eye-off-outline" if password.password == True else "eye-outline"
                            theme_text_color: "Custom"
                            text_color: "#8d8a8c"
                            pos_hint: {"center_x": 0.5, "center_y": 0.5}
                            on_press: root.view_password()
                            
                CustomFlatButton:
                    id: avatar
                    size_hint_y: None
                    height: "35dp"
                    text: "Add Image"
                    on_press: root.add_image()
                    
                MDLabel:
                    id: error
                    size_hint_y: None
                    height: "30dp"
                    halign: "center"
                    font_style: "Label"
                    role: "small"
                    
                CustomFlatButton:
                    id: modal_button
                    size_hint_y: None
                    height: "35dp"
                    text: "Add"
                    on_press: root.callback(root)
                    
                BoxLayout:
                    
                    
                    
#######################################################STUDENTS MODAL
<ParentModal>:
    background: ""
    background_color: [0,0,0,0]
    
    AnchorLayout:
        anchor_x: "right"
        
        BoxLayout:
            orientation: "vertical"
            size_hint_x: None
            width: "400dp"
            padding: "10dp"
            spacing: "40dp"
            canvas.before:
                Color:
                    rgba: [1,1,1,1]
                Rectangle:
                    pos: self.pos
                    size: self.size
                    
            BoxLayout:
                size_hint_y: None
                height: "35dp"
                spacing: "10dp"
                
                MDLabel:
                    id: modal_title
                    text: "Add parent"
                    font_style: "Label"
                    role: "large"
                    bold: True
                    
                FloatLayout:
                    size_hint_x: None
                    width: self.height
                    
                    MDIconButton:
                        icon: "close"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        on_press: root.dismiss()
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}
                        
            BoxLayout:
                orientation: "vertical"
                spacing: "10dp"
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Name"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: name
                        hint_text: "Teacher's full name..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "65dp"
                        text: "Student"
                        font_style: "Label"
                        role: "medium"
                        bold: True

                    CustomDropDown:
                        id: student
                        text: "Select student..."
                        values: ["Tanaka Doe","Peter Doe","John Smith","Jane Smith"]
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Username"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: username
                        hint_text: "Teacher's username..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "65dp"
                        text: "D.O.B"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    MDLabel:
                        id: dob
                        font_style: "Label"
                        role: "medium"
                        
                    FloatLayout:
                        size_hint_x: None
                        width: self.height
        
                        MDIconButton:
                            icon: "calendar"
                            theme_text_color: "Custom"
                            text_color: "#8d8a8c"
                            pos_hint: {"center_x": 0.5, "center_y": 0.5}
                            on_press: root.show_date_picker()
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Email"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: email
                        hint_text: "Teacher's email address..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Phone"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: phone
                        hint_text: "Teacher's phone number..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Address"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: address
                        hint_text: "Teacher's physical address..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Password"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: password
                        password: True
                        hint_text: "Teacher's password..."
                        multiline: False
                        
                    FloatLayout:
                        size_hint_x: None
                        width: self.height
        
                        MDIconButton:
                            icon: "eye-off-outline" if password.password == True else "eye-outline"
                            theme_text_color: "Custom"
                            text_color: "#8d8a8c"
                            pos_hint: {"center_x": 0.5, "center_y": 0.5}
                            on_press: root.view_password()
                            
                CustomFlatButton:
                    id: avatar
                    size_hint_y: None
                    height: "35dp"
                    text: "Add Image"
                    on_press: root.add_image()
                    
                MDLabel:
                    id: error
                    size_hint_y: None
                    height: "30dp"
                    halign: "center"
                    font_style: "Label"
                    role: "small"
                    
                CustomFlatButton:
                    id: modal_button
                    size_hint_y: None
                    height: "35dp"
                    text: "Add"
                    on_press: root.callback(root)
                    
                BoxLayout:
                    
                    
                    
#######################################################CLASS MODAL
<ClassModal>:
    background: ""
    background_color: [0,0,0,0]
    
    AnchorLayout:
        anchor_x: "right"
        
        BoxLayout:
            orientation: "vertical"
            size_hint_x: None
            width: "400dp"
            padding: "10dp"
            spacing: "40dp"
            canvas.before:
                Color:
                    rgba: [1,1,1,1]
                Rectangle:
                    pos: self.pos
                    size: self.size
                    
            BoxLayout:
                size_hint_y: None
                height: "35dp"
                spacing: "10dp"
                
                MDLabel:
                    id: modal_title
                    text: "Add class"
                    font_style: "Label"
                    role: "large"
                    bold: True
                    
                FloatLayout:
                    size_hint_x: None
                    width: self.height
                    
                    MDIconButton:
                        icon: "close"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        on_press: root.dismiss()
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}
                        
            BoxLayout:
                orientation: "vertical"
                spacing: "10dp"
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Class"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: classes
                        hint_text: "Class name..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "65dp"
                        text: "Grade"
                        font_style: "Label"
                        role: "medium"
                        bold: True

                    CustomDropDown:
                        id: grade
                        text: "Select grade..."
                        values: ["1","2","3","4","5"]
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Capacity"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: capacity
                        hint_text: "Class' capacity..."
                        multiline: False
                        input_filter: "int"
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "65dp"
                        text: "Supervisor"
                        font_style: "Label"
                        role: "medium"
                        bold: True

                    CustomDropDown:
                        id: supervisor
                        text: "Select supervisor..."
                        values: ["John","James","Smith","Smitty","Jane"]
                    
                MDLabel:
                    id: error
                    size_hint_y: None
                    height: "30dp"
                    halign: "center"
                    font_style: "Label"
                    role: "small"
                    
                CustomFlatButton:
                    id: modal_button
                    size_hint_y: None
                    height: "35dp"
                    text: "Add"
                    on_press: root.callback(root)
                    
                BoxLayout:
                    
                    
                    
                    
#######################################################SUBJECTS MODAL
<SubjectModal>:
    background: ""
    background_color: [0,0,0,0]
    
    AnchorLayout:
        anchor_x: "right"
        
        BoxLayout:
            orientation: "vertical"
            size_hint_x: None
            width: "400dp"
            padding: "10dp"
            spacing: "40dp"
            canvas.before:
                Color:
                    rgba: [1,1,1,1]
                Rectangle:
                    pos: self.pos
                    size: self.size
                    
            BoxLayout:
                size_hint_y: None
                height: "35dp"
                spacing: "10dp"
                
                MDLabel:
                    id: modal_title
                    text: "Add subject"
                    font_style: "Label"
                    role: "large"
                    bold: True
                    
                FloatLayout:
                    size_hint_x: None
                    width: self.height
                    
                    MDIconButton:
                        icon: "close"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        on_press: root.dismiss()
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}
                        
            BoxLayout:
                orientation: "vertical"
                spacing: "10dp"
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "60dp"
                        text: "Subject"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    TextField:
                        id: subject
                        hint_text: "Subject name..."
                        multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "65dp"
                        text: "Teacher"
                        font_style: "Label"
                        role: "medium"
                        bold: True

                    CustomDropDown:
                        id: teacher
                        text: "Select teacher..."
                        values: ["John","James","Smith","Smitty","Jane"]
                    
                MDLabel:
                    id: error
                    size_hint_y: None
                    height: "30dp"
                    halign: "center"
                    font_style: "Label"
                    role: "small"
                    
                CustomFlatButton:
                    id: modal_button
                    size_hint_y: None
                    height: "35dp"
                    text: "Add"
                    on_press: root.callback(root)
                    
                BoxLayout:
                    
                
                    
                    
                    
                    
#######################################################SUBJECTS MODAL
<NoticeModal>:
    background: ""
    background_color: [0,0,0,0]
    
    AnchorLayout:
        anchor_x: "right"
        
        BoxLayout:
            orientation: "vertical"
            size_hint_x: None
            width: "400dp"
            padding: "10dp"
            spacing: "40dp"
            canvas.before:
                Color:
                    rgba: [1,1,1,1]
                Rectangle:
                    pos: self.pos
                    size: self.size
                    
            BoxLayout:
                size_hint_y: None
                height: "35dp"
                spacing: "10dp"
                
                MDLabel:
                    id: modal_title
                    text: "Add subject"
                    font_style: "Label"
                    role: "large"
                    bold: True
                    
                FloatLayout:
                    size_hint_x: None
                    width: self.height
                    
                    MDIconButton:
                        icon: "close"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        on_press: root.dismiss()
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}
                        
            BoxLayout:
                orientation: "vertical"
                spacing: "10dp"
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
    
                    MDLabel:
                        size_hint_x: None
                        width: "105dp"
                        text: "Date"
                        font_style: "Label"
                        role: "medium"
                        bold: True
    
                    MDLabel:
                        id: date
                        font_style: "Label"
                        role: "medium"
                        
                    FloatLayout:
                        size_hint_x: None
                        width: self.height
        
                        MDIconButton:
                            icon: "calendar"
                            theme_text_color: "Custom"
                            text_color: "#8d8a8c"
                            pos_hint: {"center_x": 0.5, "center_y": 0.5}
                            on_press: root.show_date_picker()
                
                BoxLayout:
                    size_hint_y: None
                    height: "80dp"
                    padding: ["10dp", "2.5dp"]
                    spacing: "10dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#f5f5f5")
                        RoundedRectangle:
                            size: self.size
                            pos: self.pos
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        orientation: "vertical"
                        size_hint_x: None
                        width: "100dp"
                        
    
                        MDLabel:
                            size_hint_y: None
                            height: "35dp"
                            text: "Announcement"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        BoxLayout:
                    
                    TextField:
                        id: announcement
                        hint_text: "Announcement..."
                    
                MDLabel:
                    id: error
                    size_hint_y: None
                    height: "30dp"
                    halign: "center"
                    font_style: "Label"
                    role: "small"
                    
                CustomFlatButton:
                    id: modal_button
                    size_hint_y: None
                    height: "35dp"
                    text: "Add"
                    on_press: root.callback(root)
                    
                BoxLayout:
                    
                    
""")

class TeacherModal(ModalView):
    id = StringProperty()
    avatar = StringProperty()
    name = StringProperty()
    username = StringProperty()
    dob = StringProperty()
    email = StringProperty()
    phone = StringProperty()
    address = StringProperty()
    password = StringProperty()
    close = StringProperty()
    callback = ObjectProperty(allownone = True)
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.filemanager = MDFileManager(
            background_color_toolbar = "#0096c7",
            background_color_selection_button ="#0096c7",
            select_path = self.select_path,
            exit_manager = self.exit_file_manager,
            preview = True
        )

    def add_image(self):
        self.filemanager.show('/')

    def select_path(self, path):
        self.ids.avatar.text = rf"{path}"
        self.exit_file_manager(self)

    def exit_file_manager(self, _):
        self.filemanager.close()

    def show_date_picker(self):
        date_picker = MDModalDatePicker()
        date_picker.bind(on_ok = self.on_date_ok)
        date_picker.bind(on_cancel = self.on_date_cancel)
        date_picker.open()

    def on_date_ok(self, instance_date_picker):
        self.ids.dob.text = str(instance_date_picker.get_date()[0])
        instance_date_picker.dismiss()

    def on_date_cancel(self, instance_date_picker):
        instance_date_picker.dismiss()


    def on_name(self, instance, name):
        self.ids.name.text = name
        self.ids.modal_button.text = "Update"
        self.ids.modal_title.text = "Update teacher"

    def on_username(self, instance, username):
        self.ids.username.text = username

    def on_dob(self, instance, dob):
        self.ids.dob.text = dob

    def on_email(self, instance, email):
        self.ids.email.text = email

    def on_phone(self, instance, phone):
        self.ids.phone.text = phone

    def on_address(self, instance, address):
        self.ids.address.text = address

    def on_password(self, instance, password):
        self.ids.password.text = password

    def on_close(self, instance, close):
        self.dismiss()

    def view_password(self):
        if self.ids.password.password:
            self.ids.password.password = False
        else:
            self.ids.password.password = True

#########################################################STUDENTS MODAL

class StudentModal(ModalView):
    id = StringProperty()
    avatar = StringProperty()
    name = StringProperty()
    grade = StringProperty()
    classes = StringProperty()
    username = StringProperty()
    dob = StringProperty()
    email = StringProperty()
    phone = StringProperty()
    address = StringProperty()
    password = StringProperty()
    close = StringProperty()
    callback = ObjectProperty(allownone = True)
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.filemanager = MDFileManager(
            background_color_toolbar = "#0096c7",
            background_color_selection_button ="#0096c7",
            select_path = self.select_path,
            exit_manager = self.exit_file_manager,
            preview = True
        )
        Clock.schedule_once(self.show_classes, .1)

    def add_image(self):
        self.filemanager.show('/')

    def select_path(self, path):
        self.ids.avatar.text = rf"{path}"
        self.exit_file_manager(self)

    def exit_file_manager(self, _):
        self.filemanager.close()

    def show_classes(self, dt):
        # classes = []
        # conn = psycopg2.connect(
        #     dbname="lms",
        #     user="mtech",
        #     password="12345678Mtech",
        #     host="localhost",
        #     port="5432"
        # )
        # cursor = conn.cursor()
        # cursor.execute("SELECT * FROM classes")
        # classes = cursor.fetchall()
        # cursor.close()
        # conn.close()
        # for x in classes:
        #     data = str(x[1])
        #
        #     classes.append(data)

        classes = []
        try:
            with psycopg2.connect(
                dbname="lms",
                user="mtech",
                password="12345678Mtech",
                host="localhost",
                port="5432"
                ) as conn:
                    with conn.cursor() as cursor:
                        cursor.execute("SELECT * FROM classes")
                        rows = cursor.fetchall()
                        classes = [str(row[1]) for row in rows]

            self.ids.classes.values = classes
        except psycopg2.Error as e:
            return None

    def show_date_picker(self):
        date_picker = MDModalDatePicker()
        date_picker.bind(on_ok = self.on_date_ok)
        date_picker.bind(on_cancel = self.on_date_cancel)
        date_picker.open()

    def on_date_ok(self, instance_date_picker):
        self.ids.dob.text = str(instance_date_picker.get_date()[0])
        instance_date_picker.dismiss()

    def on_date_cancel(self, instance_date_picker):
        instance_date_picker.dismiss()


    def on_name(self, instance, name):
        self.ids.name.text = name
        self.ids.modal_button.text = "Update"
        self.ids.modal_title.text = "Update student"

    def on_grade(self, instance, grade):
        self.ids.grade.text = grade

    def on_classes(self, instance, classes):
        self.ids.classes.text = classes

    def on_username(self, instance, username):
        self.ids.username.text = username

    def on_dob(self, instance, dob):
        self.ids.dob.text = dob

    def on_email(self, instance, email):
        self.ids.email.text = email

    def on_phone(self, instance, phone):
        self.ids.phone.text = phone

    def on_address(self, instance, address):
        self.ids.address.text = address

    def on_password(self, instance, password):
        self.ids.password.text = password

    def on_close(self, instance, close):
        self.dismiss()

    def view_password(self):
        if self.ids.password.password:
            self.ids.password.password = False
        else:
            self.ids.password.password = True

#########################################################STUDENTS MODAL

class ParentModal(ModalView):
    id = StringProperty()
    avatar = StringProperty()
    name = StringProperty()
    student = StringProperty()
    username = StringProperty()
    dob = StringProperty()
    email = StringProperty()
    phone = StringProperty()
    address = StringProperty()
    password = StringProperty()
    close = StringProperty()
    callback = ObjectProperty(allownone = True)
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.filemanager = MDFileManager(
            background_color_toolbar = "#0096c7",
            background_color_selection_button ="#0096c7",
            select_path = self.select_path,
            exit_manager = self.exit_file_manager,
            preview = True
        )

    def add_image(self):
        self.filemanager.show('/')

    def select_path(self, path):
        self.ids.avatar.text = rf"{path}"
        self.exit_file_manager(self)

    def exit_file_manager(self, _):
        self.filemanager.close()

    def show_date_picker(self):
        date_picker = MDModalDatePicker()
        date_picker.bind(on_ok = self.on_date_ok)
        date_picker.bind(on_cancel = self.on_date_cancel)
        date_picker.open()

    def on_date_ok(self, instance_date_picker):
        self.ids.dob.text = str(instance_date_picker.get_date()[0])
        instance_date_picker.dismiss()

    def on_date_cancel(self, instance_date_picker):
        instance_date_picker.dismiss()


    def on_name(self, instance, name):
        self.ids.name.text = name
        self.ids.modal_button.text = "Update"
        self.ids.modal_title.text = "Update parent"

    def on_student(self, instance, student):
        self.ids.student.text = student

    def on_username(self, instance, username):
        self.ids.username.text = username

    def on_dob(self, instance, dob):
        self.ids.dob.text = dob

    def on_email(self, instance, email):
        self.ids.email.text = email

    def on_phone(self, instance, phone):
        self.ids.phone.text = phone

    def on_address(self, instance, address):
        self.ids.address.text = address

    def on_password(self, instance, password):
        self.ids.password.text = password

    def on_close(self, instance, close):
        self.dismiss()

    def view_password(self):
        if self.ids.password.password:
            self.ids.password.password = False
        else:
            self.ids.password.password = True

#########################################################STUDENTS MODAL

class ClassModal(ModalView):
    id = StringProperty()
    classes = StringProperty()
    grade = StringProperty()
    capacity = StringProperty()
    supervisor = StringProperty()
    close = StringProperty()
    callback = ObjectProperty(allownone = True)

    def on_classes(self, instance, classes):
        self.ids.classes.text = classes
        self.ids.modal_button.text = "Update"
        self.ids.modal_title.text = "Update class"

    def on_grade(self, instance, grade):
        self.ids.grade.text = grade

    def on_capacity(self, instance, capacity):
        self.ids.capacity.text = capacity

    def on_supervisor(self, instance, supervisor):
        self.ids.supervisor.text = supervisor

    def on_close(self, instance, close):
        self.dismiss()

#########################################################SUBJECTS MODAL

class SubjectModal(ModalView):
    id = StringProperty()
    subject = StringProperty()
    teacher = StringProperty()
    close = StringProperty()
    callback = ObjectProperty(allownone = True)

    def on_subject(self, instance, subject):
        self.ids.subject.text = subject
        self.ids.modal_button.text = "Update"
        self.ids.modal_title.text = "Update subject"

    def on_teacher(self, instance, teacher):
        self.ids.teacher.text = teacher

    def on_close(self, instance, close):
        self.dismiss()

#########################################################NOTICES MODAL

class NoticeModal(ModalView):
    id = StringProperty()
    date = StringProperty()
    announcement = StringProperty()
    close = StringProperty()
    callback = ObjectProperty(allownone = True)

    def show_date_picker(self):
        date_picker = MDModalDatePicker()
        date_picker.bind(on_ok = self.on_date_ok)
        date_picker.bind(on_cancel = self.on_date_cancel)
        date_picker.open()

    def on_date_ok(self, instance_date_picker):
        self.ids.date.text = str(instance_date_picker.get_date()[0])
        instance_date_picker.dismiss()

    def on_date_cancel(self, instance_date_picker):
        instance_date_picker.dismiss()

    def on_date(self, instance, date):
        self.ids.date.text = date
        self.ids.modal_button.text = "Update"
        self.ids.modal_title.text = "Update notice"

    def on_announcement(self, instance, announcement):
        self.ids.announcement.text = announcement

    def on_close(self, instance, close):
        self.dismiss()