from kivy.clock import Clock
from kivy.properties import ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from widgets.modals import TeacherModal
from widgets.popups import ConfirmPopUp
from widgets.tables import TeacherTab

Builder.load_file('views/teachers/teachers.kv')

class Teachers(Screen):
    teachers = ListProperty()
    def on_enter(self, *args):
        self.addTeacher = []
        self.updateTeacher = []
        self.deleteTeacher = None
        Clock.schedule_once(self.run_essentials, .1)

    def run_essentials(self, dt):
        self.show_teachers()

    def show_teachers(self):
        self.teachers = []
        teachers = [1,2,3,4,5,6,7,8]
        for x in teachers:
            data = {
                "id" : "1",
                "avatar" : "assets/images/avatar.png",
                "name" : "Tanaka Peter",
                "username" : "TP",
                "dob" : "1/1/1111",
                "email" : "tp@mt.com",
                "phone" : "+1234567890",
                "address" : "8 NoWhere Street, Mars",
                "password" : "qwertyu",
            }

            self.teachers.append(data)

    def on_teachers(self, instance, teachers):
        table = self.ids.teachers_list
        table.clear_widgets()
        for teacher in teachers:
            tableRow = TeacherTab()
            tableRow.id = str(teacher["id"])
            tableRow.avatar = str(teacher["avatar"])
            tableRow.name = str(teacher["name"])
            tableRow.username = str(teacher["username"])
            tableRow.dob = str(teacher["dob"])
            tableRow.email = str(teacher["email"])
            tableRow.phone = str(teacher["phone"])
            tableRow.address = str(teacher["address"])
            tableRow.password = str(teacher["password"])
            tableRow.update_callback = self.open_modal_update
            tableRow.delete_callback = self.delete_teacher
            table.add_widget(tableRow)

########################################################OPEN MODALS
    def open_modal_add(self):
        open_modal_add = TeacherModal()
        open_modal_add.callback = self.add_teacher
        open_modal_add.open()

    def open_modal_update(self, instance):
        open_modal_update = TeacherModal()
        open_modal_update.id = instance.id
        open_modal_update.avatar = instance.avatar
        open_modal_update.name = instance.name
        open_modal_update.username = instance.username
        open_modal_update.dob = instance.dob
        open_modal_update.email = instance.email
        open_modal_update.phone = instance.phone
        open_modal_update.address = instance.address
        open_modal_update.password = instance.password
        open_modal_update.callback = self.update_teacher
        open_modal_update.open()

########################################################ADD

    def add_teacher(self, teacher):
        avatar = teacher.ids.avatar.text
        name = teacher.ids.name.text
        username = teacher.ids.username.text
        dob = teacher.ids.dob.text
        email = teacher.ids.email.text
        phone = teacher.ids.phone.text
        address = teacher.ids.address.text
        password = teacher.ids.password.text

        if name == "" or username == "" or dob == "" or email == "" or phone == "" or address == "":
            teacher.ids.error.text = "Fill in all the required fields!"
            teacher.ids.error.color = "red"
        else:
            if len(password) < 8:
                teacher.ids.error.text = "Password must be at least 8 characters long!"
                teacher.ids.error.color = "red"
            else:
                teacher.close = "close"
                self.addTeacher = [avatar,name,username,dob,email,phone,address,password]
                add_teacher = ConfirmPopUp()
                add_teacher.title = "Add teacher?"
                add_teacher.callback = self.add_teacher_callback
                add_teacher.open()

    def add_teacher_callback(self, _):
        avatar = self.addTeacher[0]
        name = self.addTeacher[1]
        username = self.addTeacher[2]
        dob = self.addTeacher[3]
        email = self.addTeacher[4]
        phone = self.addTeacher[5]
        address = self.addTeacher[6]
        password = self.addTeacher[7]


########################################################UPDATE

    def update_teacher(self, teacher):
        id = teacher.id
        avatar = teacher.ids.avatar.text
        name = teacher.ids.name.text
        username = teacher.ids.username.text
        dob = teacher.ids.dob.text
        email = teacher.ids.email.text
        phone = teacher.ids.phone.text
        address = teacher.ids.address.text
        password = teacher.ids.password.text

        if name == "" or username == "" or dob == "" or email == "" or phone == "" or address == "":
            teacher.ids.error.text = "Fill in all the required fields!"
            teacher.ids.error.color = "red"
        else:
            if len(password) < 8:
                teacher.ids.error.text = "Password must be at least 8 characters long!"
                teacher.ids.error.color = "red"
            else:
                teacher.close = "close"
                self.updateTeacher = [id,avatar,name,username,dob,email,phone,address,password]
                update_teacher = ConfirmPopUp()
                update_teacher.title = "Update teacher?"
                update_teacher.callback = self.update_teacher_callback
                update_teacher.open()

    def update_teacher_callback(self, _):
        id = self.updateTeacher[0]
        avatar = self.updateTeacher[1]
        name = self.updateTeacher[2]
        username = self.updateTeacher[3]
        dob = self.updateTeacher[4]
        email = self.updateTeacher[5]
        phone = self.updateTeacher[6]
        address = self.updateTeacher[7]
        password = self.updateTeacher[8]

########################################################DELETE

    def delete_teacher(self, teacher):
        self.deleteTeacher = teacher.id
        delete_teacher = ConfirmPopUp()
        delete_teacher.title = "Delete teacher?"
        delete_teacher.callback = self.delete_teacher_callback
        delete_teacher.open()

    def delete_teacher_callback(self, _):
        id = self.deleteTeacher

