from kivy.clock import Clock
from kivy.properties import NumericProperty, ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
import numpy as np
import matplotlib.pyplot as plt
from kivy_garden.matplotlib.backend_kivyagg import FigureCanvasKivyAgg as FCK

from widgets.tables import NoticeTab

Builder.load_file('views/dashboard/dashboard.kv')

class Dashboard(Screen):
    students = NumericProperty(521)
    teachers = NumericProperty(28)
    parents = NumericProperty(125)
    subjects = NumericProperty(35)
    classes = NumericProperty(22)
    announcements = ListProperty()
    def on_enter(self, *args):
        Clock.schedule_once(self.run_essentials, .1)

    def run_essentials(self, dt):
        self.show_students_chart()
        self.show_earnings_chart()
        self.show_announcements()

    def show_students_chart(self):
        male_percentage = 44
        female_percentage = 56

        fig, ax = plt.subplots()
        fig.patch.set_facecolor("none")
        ax.patch.set_facecolor("none")

        total = male_percentage + female_percentage
        male_angle = (male_percentage/total  *  360)
        female_angle = (female_percentage/total  *  360)

        colors = ["#0096c7", "#ffa07a"]

        wedges, _ = ax.pie(
            [male_angle, female_angle],
            startangle = 125,
            colors=colors,
            radius=1.2,
            counterclock=False,
            wedgeprops={"width": 0.3}
        )

        ax.set_xticks([])
        ax.set_yticks([])
        ax.spines.clear()

        self.ids.gender_chart.clear_widgets()
        self.ids.gender_chart.add_widget(FCK(fig))

    def show_earnings_chart(self):
        months =["Jan","Feb","Mar","April","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
        earnings = np.random.randint(10, 50, size=12)
        expenses = np.random.randint(10, 50, size=12)

        x = np.arange(len(months))
        width = 0.35

        fig, ax = plt.subplots()
        fig.patch.set_facecolor("none")
        ax.patch.set_facecolor("none")
        ax.bar(x-width/2, earnings, width, label="Earnings", color="#0096c7")
        ax.bar(x-width/2, expenses, width, label="Expenses", color="#ffa07a")

        ax.set_xticks([])
        ax.set_yticks([])

        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["bottom"].set_visible(False)
        ax.spines["left"].set_visible(False)

        self.ids.earnings_chart.clear_widgets()
        self.ids.earnings_chart.add_widget(FCK(fig))

    def show_announcements(self):
        self.announcements = []
        announcements = [1,2,3,4,5,6,7,8]
        for x in announcements:
            data = {
                "id": "1",
                "date": "5 March 2025",
                "details": "Inter-schools competition for 5th graders."
            }

            self.announcements.append(data)

    def on_announcements(self, instance, announcements):
        table = self.ids.dash_notices_list
        table.clear_widgets()
        for announcement in announcements:
            tableRow = NoticeTab()
            tableRow.id = str(announcement["id"])
            tableRow.date = str(announcement["date"])
            tableRow.details = str(announcement["details"])
            table.add_widget(tableRow)














