import psycopg2
from kivy.clock import Clock
from kivy.properties import ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from widgets.modals import NoticeModal
from widgets.popups import ConfirmPopUp
from widgets.tables import CreateNoticeTab

Builder.load_file('views/notices/notices.kv')

class Notices(Screen):
    notices = ListProperty()
    def on_enter(self, *args):
        self.addNotice = []
        self.updateNotice = []
        self.deleteNotice = None
        Clock.schedule_once(self.run_essentials, .1)

    def run_essentials(self, dt):
        self.show_notices()

    def show_notices(self):
        self.notices = []
        conn = psycopg2.connect(
            dbname="lms",
            user="mtech",
            password="12345678Mtech",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM notices")
        notices = cursor.fetchall()
        cursor.close()
        conn.close()
        for x in notices:
            data = {
                "id" : str(x[0]),
                "date" : str(x[3]),
                "announcement" : str(x[2])
            }

            self.notices.append(data)

    def on_notices(self, instance, notices):
        table = self.ids.notices_list
        table.clear_widgets()
        for notice in notices:
            tableRow = CreateNoticeTab()
            tableRow.id = str(notice["id"])
            tableRow.date = str(notice["date"])
            tableRow.announcement = str(notice["announcement"])
            tableRow.update_callback = self.open_modal_update
            tableRow.delete_callback = self.delete_notice
            table.add_widget(tableRow)

########################################################OPEN MODALS
    def open_modal_add(self):
        open_modal_add = NoticeModal()
        open_modal_add.callback = self.add_notice
        open_modal_add.open()

    def open_modal_update(self, instance):
        open_modal_update = NoticeModal()
        open_modal_update.id = instance.id
        open_modal_update.date = instance.date
        open_modal_update.announcement = instance.announcement
        open_modal_update.callback = self.update_notice
        open_modal_update.open()

########################################################ADD

    def add_notice(self, notice):
        date = notice.ids.date.text
        announcement = notice.ids.announcement.text

        if date == "" or announcement == "":
            notice.ids.error.text = "Fill in all the required fields!"
            notice.ids.error.color = "red"
        else:
            notice.close = "close"
            self.addNotice = [date,announcement]
            add_notice = ConfirmPopUp()
            add_notice.title = "Add notice?"
            add_notice.callback = self.add_notice_callback
            add_notice.open()

    def add_notice_callback(self, _):
        date = self.addNotice[0]
        announcement = self.addNotice[1]
        subject = "asd"
        conn = psycopg2.connect(
            dbname="lms",
            user="mtech",
            password="12345678Mtech",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()
        sql = "INSERT INTO notices (subject, announcement) VALUES (%s, %s)"
        values = [subject, announcement]
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        self.show_notices()


########################################################UPDATE

    def update_notice(self, notice):
        id = notice.id
        date = notice.ids.date.text
        announcement = notice.ids.announcement.text

        if date == "" or announcement == "":
            notice.ids.error.text = "Fill in all the required fields!"
            notice.ids.error.color = "red"
        else:
            notice.close = "close"
            self.updateNotice = [id,date,announcement]
            update_notice = ConfirmPopUp()
            update_notice.title = "Update notice?"
            update_notice.callback = self.update_notice_callback
            update_notice.open()

    def update_notice_callback(self, _):
        id = self.updateNotice[0]
        date = self.updateNotice[1]
        announcement = self.updateNotice[2]
        conn = psycopg2.connect(
            dbname="lms",
            user="mtech",
            password="12345678Mtech",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()
        sql = "UPDATE notices SET announcement = %s WHERE id = %s"
        values = [announcement, id]
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        self.show_notices()

########################################################DELETE

    def delete_notice(self, notice):
        self.deleteNotice = notice.id
        delete_notice = ConfirmPopUp()
        delete_notice.title = "Delete notice?"
        delete_notice.callback = self.delete_notice_callback
        delete_notice.open()

    def delete_notice_callback(self, _):
        id = self.deleteNotice
        conn = psycopg2.connect(
            dbname="lms",
            user="mtech",
            password="12345678Mtech",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()
        sql = "DELETE FROM notices WHERE id = %s"
        values = [id]
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        self.show_notices()

