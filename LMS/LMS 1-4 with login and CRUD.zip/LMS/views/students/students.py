import psycopg2
from kivy.clock import Clock
from kivy.properties import ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from widgets.modals import StudentModal
from widgets.popups import ConfirmPopUp
from widgets.tables import StudentTab

Builder.load_file('views/students/students.kv')

class Students(Screen):
    students = ListProperty()
    def on_enter(self, *args):
        self.addStudent = []
        self.updateStudent = []
        self.deleteStudent = None
        Clock.schedule_once(self.run_essentials, .1)

    def run_essentials(self, dt):
        self.show_students()

    def show_students(self):
        self.students = []
        conn = psycopg2.connect(
            dbname="lms",
            user="mtech",
            password="12345678Mtech",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM students")
        students = cursor.fetchall()
        cursor.close()
        conn.close()
        for x in students:
            data = {
                "id" : str(x[0]),
                "avatar" : str(x[1]),
                "name" : str(x[2]),
                "grade" : str(x[3]),
                "classes" : str(x[4]),
                "username" : str(x[5]),
                "dob" : str(x[6]),
                "email" : str(x[7]),
                "phone" : str(x[8]),
                "address" : str(x[9]),
                "password" : str(x[10]),
            }

            self.students.append(data)

    def on_students(self, instance, students):
        table = self.ids.students_list
        table.clear_widgets()
        for student in students:
            tableRow = StudentTab()
            tableRow.id = str(student["id"])
            tableRow.avatar = str(student["avatar"])
            tableRow.name = str(student["name"])
            tableRow.grade = str(student["grade"])
            tableRow.classes = str(student["classes"])
            tableRow.username = str(student["username"])
            tableRow.dob = str(student["dob"])
            tableRow.email = str(student["email"])
            tableRow.phone = str(student["phone"])
            tableRow.address = str(student["address"])
            tableRow.password = str(student["password"])
            tableRow.update_callback = self.open_modal_update
            tableRow.delete_callback = self.delete_student
            table.add_widget(tableRow)

########################################################OPEN MODALS
    def open_modal_add(self):
        open_modal_add = StudentModal()
        open_modal_add.callback = self.add_student
        open_modal_add.open()

    def open_modal_update(self, instance):
        open_modal_update = StudentModal()
        open_modal_update.id = instance.id
        open_modal_update.avatar = instance.avatar
        open_modal_update.name = instance.name
        open_modal_update.grade = instance.grade
        open_modal_update.classes = instance.classes
        open_modal_update.username = instance.username
        open_modal_update.dob = instance.dob
        open_modal_update.email = instance.email
        open_modal_update.phone = instance.phone
        open_modal_update.address = instance.address
        open_modal_update.password = instance.password
        open_modal_update.callback = self.update_student
        open_modal_update.open()

########################################################ADD

    def add_student(self, student):
        avatar = student.ids.avatar.text
        name = student.ids.name.text
        grade = student.ids.grade.ids.spinner.text
        classes = student.ids.classes.ids.spinner.text
        username = student.ids.username.text
        dob = student.ids.dob.text
        email = student.ids.email.text
        phone = student.ids.phone.text
        address = student.ids.address.text
        password = student.ids.password.text

        if name == "" or grade == "Select grade..." or classes == "Select class..." or username == "" or dob == "" or email == "" or phone == "" or address == "":
            student.ids.error.text = "Fill in all the required fields!"
            student.ids.error.color = "red"
        else:
            if len(password) < 8:
                student.ids.error.text = "Password must be at least 8 characters long!"
                student.ids.error.color = "red"
            else:
                student.close = "close"
                self.addStudent = [avatar,name,grade,classes,username,dob,email,phone,address,password]
                add_student = ConfirmPopUp()
                add_student.title = "Add student?"
                add_student.callback = self.add_student_callback
                add_student.open()

    def add_student_callback(self, _):
        avatar = self.addStudent[0]
        name = self.addStudent[1]
        grade = self.addStudent[2]
        classes = self.addStudent[3]
        username = self.addStudent[4]
        dob = self.addStudent[5]
        email = self.addStudent[6]
        phone = self.addStudent[7]
        address = self.addStudent[8]
        password = self.addStudent[9]
        conn = psycopg2.connect(
            dbname="lms",
            user="mtech",
            password="12345678Mtech",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()
        sql = "INSERT INTO students (avatar,name,grade,class,username,dob,email,phone,address,password) VALUES (%s, %s, %s, %s, %s,%s,%s,%s,%s,%s)"
        values = [avatar,name,grade,classes,username,dob,email,phone,address,password]
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        self.show_students()


########################################################UPDATE

    def update_student(self, student):
        id = student.id
        avatar = student.ids.avatar.text
        name = student.ids.name.text
        grade = student.ids.grade.ids.spinner.text
        classes = student.ids.classes.ids.spinner.text
        username = student.ids.username.text
        dob = student.ids.dob.text
        email = student.ids.email.text
        phone = student.ids.phone.text
        address = student.ids.address.text
        password = student.ids.password.text

        if name == "" or grade == "Select grade..." or classes == "Select class..." or username == ""  or username == "" or dob == "" or email == "" or phone == "" or address == "":
            student.ids.error.text = "Fill in all the required fields!"
            student.ids.error.color = "red"
        else:
            if len(password) < 8:
                student.ids.error.text = "Password must be at least 8 characters long!"
                student.ids.error.color = "red"
            else:
                student.close = "close"
                self.updateStudent = [id,avatar,name,grade,classes,username,dob,email,phone,address,password]
                update_student = ConfirmPopUp()
                update_student.title = "Update student?"
                update_student.callback = self.update_student_callback
                update_student.open()

    def update_student_callback(self, _):
        id = self.updateStudent[0]
        avatar = self.updateStudent[1]
        name = self.updateStudent[2]
        grade = self.updateStudent[3]
        classes = self.updateStudent[4]
        username = self.updateStudent[5]
        dob = self.updateStudent[6]
        email = self.updateStudent[7]
        phone = self.updateStudent[8]
        address = self.updateStudent[9]
        password = self.updateStudent[10]
        conn = psycopg2.connect(
            dbname="lms",
            user="mtech",
            password="12345678Mtech",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()
        sql = """UPDATE students SET 
            avatar  = %s,
            name  = %s,
            grade  = %s,
            class  = %s,
            username  = %s,
            dob  = %s,
            email  = %s,
            phone  = %s,
            address  = %s,
            password = %s WHERE id = %s"""
        values = [avatar,name,grade,classes,username,dob,email,phone,address,password,id]
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        self.show_students()

########################################################DELETE

    def delete_student(self, student):
        self.deleteStudent = student.id
        delete_student = ConfirmPopUp()
        delete_student.title = "Delete student?"
        delete_student.callback = self.delete_student_callback
        delete_student.open()

    def delete_student_callback(self, _):
        id = self.deleteStudent
        conn = psycopg2.connect(
            dbname="lms",
            user="mtech",
            password="12345678Mtech",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()
        sql = "DELETE FROM students WHERE id = %s"
        values = [id]
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        self.show_students()


