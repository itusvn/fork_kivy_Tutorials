import json

import psycopg2
from kivymd.app import MDApp
from psycopg2 import sql
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

Builder.load_file('views/auth/auth.kv')

class Auth(Screen):
    def on_enter(self, *args):
        return super().on_enter(*args)

    def sign_in(self):
        username = self.ids.username.text
        password = self.ids.password.text

        if username == "" or password == "":
            self.ids.error.text = "Fill in all required fields!"
            self.ids.error.color = "red"
        else:
            user_types = ["students", "teachers", "parents"]
            conn = None
            try:
                conn = psycopg2.connect(
                    dbname = "lms",
                    user = "mtech",
                    password = "12345678Mtech",
                    host = "localhost",
                    port = "5432"
                )
                cursor = conn.cursor()
                for user_type in user_types:
                    query = sql.SQL("""
                        SELECT id, username FROM {} WHERE username = %s AND password = %s
                    """).format(sql.Identifier(user_type))

                    cursor.execute(query, (username, password))
                    result = cursor.fetchone()

                    if result:
                        user_data = {
                            "user_id" : result[0],
                            "username" : result[1],
                            "usertype" : user_type[:-1].capitalize()
                        }
                        cursor.close()
                        conn.close()
                        SESSION_FILE = "session.json"
                        with open(SESSION_FILE, 'w') as file:
                            json.dump(user_data, file)

                        MDApp.get_running_app().root.ids.screen_manager.current = "home_screen"
                    else:

                        self.ids.error.text = "Invalid credentials!"
                        self.ids.error.color = "red"

            except Exception as error:
                if conn:
                    conn.close()

    def view_password(self):
        if self.ids.password.password:
            self.ids.password.password = False
        else:
            self.ids.password.password = True
