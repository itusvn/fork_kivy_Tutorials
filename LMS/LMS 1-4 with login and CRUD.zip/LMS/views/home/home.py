import json

from kivy.clock import Clock
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivymd.app import MDApp
from kivy.properties import StringProperty

Builder.load_file('views/home/home.kv')
class Home(Screen):
    user = StringProperty("")
    user_type = StringProperty("")
    avatar = "assets/images/avatar.png"
    dash_screen = StringProperty()
    def on_enter(self, *args):
        Clock.schedule_once(self.get_user_id, 0.1)

    def get_user_id(self, dt):
        try:
            SESSION_FILE = "session.json"
            with open(SESSION_FILE, 'r') as file:
                session = json.load(file)
                self.user = session.get("username")
                self.user_type = session.get("user_type")
        except FileNotFoundError:
            return None

    def on_user_type(self, instance, user_type):
        if user_type == "Admin":
            self.dash_screen = "dashboard_screen"
            self.ids.home_screen_manager.current = "dashboard_screen"
        elif user_type == "Parents":
            self.dash_screen = "parent_profile_screen"
            self.ids.home_screen_manager.current = "parent_profile_screen"
        elif user_type == "Teachers":
            self.dash_screen = "teacher_profile_screen"
            self.ids.home_screen_manager.current = "teacher_profile_screen"
        else:
            self.dash_screen = "student_profile_screen"
            self.ids.home_screen_manager.current = "student_profile_screen"
