from kivy.clock import Clock
from kivy.properties import ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from widgets.modals import ParentModal
from widgets.popups import ConfirmPopUp
from widgets.tables import ParentTab

Builder.load_file('views/parents/parents.kv')

class Parents(Screen):
    parents = ListProperty()
    def on_enter(self, *args):
        self.addParent = []
        self.updateParent = []
        self.deleteParent = None
        Clock.schedule_once(self.run_essentials, .1)

    def run_essentials(self, dt):
        self.show_parents()

    def show_parents(self):
        self.parents = []
        parents = [1,2,3,4,5,6,7,8]
        for x in parents:
            data = {
                "id" : "1",
                "avatar" : "assets/images/avatar.png",
                "name" : "Tanaka Peter",
                "student" : "Tanaka Peter Jr.",
                "username" : "TP",
                "dob" : "1/1/1111",
                "email" : "tp@mt.com",
                "phone" : "+1234567890",
                "address" : "8 NoWhere Street, Mars",
                "password" : "qwertyu",
            }

            self.parents.append(data)

    def on_parents(self, instance, parents):
        table = self.ids.parents_list
        table.clear_widgets()
        for parent in parents:
            tableRow = ParentTab()
            tableRow.id = str(parent["id"])
            tableRow.avatar = str(parent["avatar"])
            tableRow.name = str(parent["name"])
            tableRow.student = str(parent["student"])
            tableRow.username = str(parent["username"])
            tableRow.dob = str(parent["dob"])
            tableRow.email = str(parent["email"])
            tableRow.phone = str(parent["phone"])
            tableRow.address = str(parent["address"])
            tableRow.password = str(parent["password"])
            tableRow.update_callback = self.open_modal_update
            tableRow.delete_callback = self.delete_parent
            table.add_widget(tableRow)

########################################################OPEN MODALS
    def open_modal_add(self):
        open_modal_add = ParentModal()
        open_modal_add.callback = self.add_student
        open_modal_add.open()

    def open_modal_update(self, instance):
        open_modal_update = ParentModal()
        open_modal_update.id = instance.id
        open_modal_update.avatar = instance.avatar
        open_modal_update.name = instance.name
        open_modal_update.student = instance.student
        open_modal_update.username = instance.username
        open_modal_update.dob = instance.dob
        open_modal_update.email = instance.email
        open_modal_update.phone = instance.phone
        open_modal_update.address = instance.address
        open_modal_update.password = instance.password
        open_modal_update.callback = self.update_student
        open_modal_update.open()

########################################################ADD

    def add_student(self, parent):
        avatar = parent.ids.avatar.text
        name = parent.ids.name.text
        student = parent.ids.student.ids.spinner.text
        username = parent.ids.username.text
        dob = parent.ids.dob.text
        email = parent.ids.email.text
        phone = parent.ids.phone.text
        address = parent.ids.address.text
        password = parent.ids.password.text

        if name == "" or student == "Select student..." or username == "" or dob == "" or email == "" or phone == "" or address == "":
            parent.ids.error.text = "Fill in all the required fields!"
            parent.ids.error.color = "red"
        else:
            if len(password) < 8:
                parent.ids.error.text = "Password must be at least 8 characters long!"
                parent.ids.error.color = "red"
            else:
                parent.close = "close"
                self.addParent = [avatar,name,student,username,dob,email,phone,address,password]
                add_student = ConfirmPopUp()
                add_student.title = "Add parent?"
                add_student.callback = self.add_student_callback
                add_student.open()

    def add_student_callback(self, _):
        avatar = self.addParent[0]
        name = self.addParent[1]
        student = self.addParent[2]
        username = self.addParent[3]
        dob = self.addParent[4]
        email = self.addParent[5]
        phone = self.addParent[6]
        address = self.addParent[7]
        password = self.addParent[8]


########################################################UPDATE

    def update_student(self, parent):
        id = parent.id
        avatar = parent.ids.avatar.text
        name = parent.ids.name.text
        student = parent.ids.student.ids.spinner.text
        username = parent.ids.username.text
        dob = parent.ids.dob.text
        email = parent.ids.email.text
        phone = parent.ids.phone.text
        address = parent.ids.address.text
        password = parent.ids.password.text

        if name == "" or student == "Select student..." or username == ""  or username == "" or dob == "" or email == "" or phone == "" or address == "":
            parent.ids.error.text = "Fill in all the required fields!"
            parent.ids.error.color = "red"
        else:
            if len(password) < 8:
                parent.ids.error.text = "Password must be at least 8 characters long!"
                parent.ids.error.color = "red"
            else:
                parent.close = "close"
                self.updateParent = [id,avatar,name,student,username,dob,email,phone,address,password]
                update_student = ConfirmPopUp()
                update_student.title = "Update parent?"
                update_student.callback = self.update_parent_callback
                update_student.open()

    def update_parent_callback(self, _):
        id = self.updateParent[0]
        avatar = self.updateParent[1]
        name = self.updateParent[2]
        student = self.updateParent[3]
        username = self.updateParent[4]
        dob = self.updateParent[5]
        email = self.updateParent[6]
        phone = self.updateParent[7]
        address = self.updateParent[8]
        password = self.updateParent[9]

########################################################DELETE

    def delete_parent(self, parent):
        self.deleteParent = parent.id
        delete_parent = ConfirmPopUp()
        delete_parent.title = "Delete parent?"
        delete_parent.callback = self.delete_parent_callback
        delete_parent.open()

    def delete_parent_callback(self, _):
        id = self.deleteParent

