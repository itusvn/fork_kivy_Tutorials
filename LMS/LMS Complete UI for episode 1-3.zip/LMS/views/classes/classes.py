from kivy.clock import Clock
from kivy.properties import ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from widgets.modals import ClassModal
from widgets.popups import ConfirmPopUp
from widgets.tables import ClassTab

Builder.load_file('views/classes/classes.kv')


class Classes(Screen):
    classes = ListProperty()
    def on_enter(self, *args):
        self.addClass = []
        self.updateClass = []
        self.deleteClass = None
        Clock.schedule_once(self.run_essentials, .1)

    def run_essentials(self, dt):
        self.show_classes()

    def show_classes(self):
        self.classes = []
        classes = [1,2,3,4,5,6,7,8]
        for x in classes:
            data = {
                "id" : "1",
                "classes" : "G",
                "grade" : "8",
                "capacity" : "17",
                "supervisor" : "Tanaka Peter Jr."
            }

            self.classes.append(data)

    def on_classes(self, instance, classes):
        table = self.ids.classes_list
        table.clear_widgets()
        for class_ in classes:
            tableRow = ClassTab()
            tableRow.id = str(class_["id"])
            tableRow.classes = str(class_["classes"])
            tableRow.grade = str(class_["grade"])
            tableRow.capacity = str(class_["capacity"])
            tableRow.supervisor = str(class_["supervisor"])
            tableRow.update_callback = self.open_modal_update
            tableRow.delete_callback = self.delete_class
            table.add_widget(tableRow)

########################################################OPEN MODALS
    def open_modal_add(self):
        open_modal_add = ClassModal()
        open_modal_add.callback = self.add_class
        open_modal_add.open()

    def open_modal_update(self, instance):
        open_modal_update = ClassModal()
        open_modal_update.id = instance.id
        open_modal_update.classes = instance.classes
        open_modal_update.grade = instance.grade
        open_modal_update.capacity = instance.capacity
        open_modal_update.supervisor = instance.supervisor
        open_modal_update.callback = self.update_class
        open_modal_update.open()

########################################################ADD

    def add_class(self, class_):
        classes = class_.ids.classes.text
        grade = class_.ids.grade.ids.spinner.text
        capacity = class_.ids.capacity.text
        supervisor = class_.ids.supervisor.ids.spinner.text

        if classes == "Select class..." or grade == "Select grade..." or capacity == "" or supervisor == "Select supervisor...":
            class_.ids.error.text = "Fill in all the required fields!"
            class_.ids.error.color = "red"
        else:
            class_.close = "close"
            self.addClass = [classes,grade,capacity,supervisor]
            add_class = ConfirmPopUp()
            add_class.title = "Add class?"
            add_class.callback = self.add_class_callback
            add_class.open()

    def add_class_callback(self, _):
        classes = self.addClass[0]
        grade = self.addClass[1]
        capacity = self.addClass[2]
        supervisor = self.addClass[3]


########################################################UPDATE

    def update_class(self, class_):
        id = class_.id
        classes = class_.ids.classes.text
        grade = class_.ids.grade.ids.spinner.text
        capacity = class_.ids.capacity.text
        supervisor = class_.ids.supervisor.ids.spinner.text

        if classes == "Select class..." or grade == "Select grade..." or capacity == "" or supervisor == "Select supervisor...":
            class_.ids.error.text = "Fill in all the required fields!"
            class_.ids.error.color = "red"
        else:
            class_.close = "close"
            self.updateClass = [id,classes,grade,capacity,supervisor]
            update_class = ConfirmPopUp()
            update_class.title = "Update class?"
            update_class.callback = self.update_class_callback
            update_class.open()

    def update_class_callback(self, _):
        id = self.updateClass[0]
        classes = self.updateClass[1]
        grade = self.updateClass[2]
        capacity = self.updateClass[3]
        supervisor = self.updateClass[4]

########################################################DELETE

    def delete_class(self, class_):
        self.deleteClass = class_.id
        delete_class = ConfirmPopUp()
        delete_class.title = "Delete class?"
        delete_class.callback = self.delete_parent_callback
        delete_class.open()

    def delete_parent_callback(self, _):
        id = self.deleteClass

