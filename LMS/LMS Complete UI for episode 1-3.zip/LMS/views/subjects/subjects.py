from kivy.clock import Clock
from kivy.properties import ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from widgets.modals import SubjectModal
from widgets.popups import ConfirmPopUp
from widgets.tables import SubjectTab

Builder.load_file('views/subjects/subjects.kv')

class Subjects(Screen):
    subjects = ListProperty()
    def on_enter(self, *args):
        self.addSubject = []
        self.updateSubject = []
        self.deleteSubject = None
        Clock.schedule_once(self.run_essentials, .1)

    def run_essentials(self, dt):
        self.show_subjects()

    def show_subjects(self):
        self.subjects = []
        subjects = [1,2,3,4,5,6,7,8]
        for x in subjects:
            data = {
                "id" : "1",
                "subject" : "Geography",
                "teacher" : "Tanaka Peter Jr."
            }

            self.subjects.append(data)

    def on_subjects(self, instance, subjects):
        table = self.ids.subjects_list
        table.clear_widgets()
        for subject in subjects:
            tableRow = SubjectTab()
            tableRow.id = str(subject["id"])
            tableRow.subject = str(subject["subject"])
            tableRow.teacher = str(subject["teacher"])
            tableRow.update_callback = self.open_modal_update
            tableRow.delete_callback = self.delete_subject
            table.add_widget(tableRow)

########################################################OPEN MODALS
    def open_modal_add(self):
        open_modal_add = SubjectModal()
        open_modal_add.callback = self.add_subject
        open_modal_add.open()

    def open_modal_update(self, instance):
        open_modal_update = SubjectModal()
        open_modal_update.id = instance.id
        open_modal_update.subject = instance.subject
        open_modal_update.teacher = instance.teacher
        open_modal_update.callback = self.update_class
        open_modal_update.open()

########################################################ADD

    def add_subject(self, subject):
        subject_ = subject.ids.subject.text
        teacher = subject.ids.teacher.ids.spinner.text

        if subject_ == "" or teacher == "Select teacher...":
            subject.ids.error.text = "Fill in all the required fields!"
            subject.ids.error.color = "red"
        else:
            subject.close = "close"
            self.addSubject = [subject_,teacher]
            add_subject = ConfirmPopUp()
            add_subject.title = "Add subject?"
            add_subject.callback = self.add_subject_callback
            add_subject.open()

    def add_subject_callback(self, _):
        subject = self.addSubject[0]
        teacher = self.addSubject[1]


########################################################UPDATE

    def update_class(self, subject):
        id = subject.id
        subject_ = subject.ids.subject.text
        teacher = subject.ids.teacher.ids.spinner.text

        if subject_ == "" or teacher == "Select teacher...":
            subject.ids.error.text = "Fill in all the required fields!"
            subject.ids.error.color = "red"
        else:
            subject.close = "close"
            self.updateSubject = [id,subject_,teacher]
            update_class = ConfirmPopUp()
            update_class.title = "Update subject?"
            update_class.callback = self.update_subject_callback
            update_class.open()

    def update_subject_callback(self, _):
        id = self.updateSubject[0]
        subject = self.updateSubject[1]
        teacher = self.updateSubject[2]

########################################################DELETE

    def delete_subject(self, subject):
        self.deleteSubject = subject.id
        delete_subject = ConfirmPopUp()
        delete_subject.title = "Delete subject?"
        delete_subject.callback = self.delete_subject_callback
        delete_subject.open()

    def delete_subject_callback(self, _):
        id = self.deleteSubject

