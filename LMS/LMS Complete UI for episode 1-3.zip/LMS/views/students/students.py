from kivy.clock import Clock
from kivy.properties import ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from widgets.modals import StudentModal
from widgets.popups import ConfirmPopUp
from widgets.tables import StudentTab

Builder.load_file('views/students/students.kv')

class Students(Screen):
    students = ListProperty()
    def on_enter(self, *args):
        self.addStudent = []
        self.updateStudent = []
        self.deleteStudent = None
        Clock.schedule_once(self.run_essentials, .1)

    def run_essentials(self, dt):
        self.show_students()

    def show_students(self):
        self.students = []
        students = [1,2,3,4,5,6,7,8]
        for x in students:
            data = {
                "id" : "1",
                "avatar" : "assets/images/avatar.png",
                "name" : "Tanaka Peter",
                "grade" : "7",
                "classes" : "A",
                "username" : "TP",
                "dob" : "1/1/1111",
                "email" : "tp@mt.com",
                "phone" : "+1234567890",
                "address" : "8 NoWhere Street, Mars",
                "password" : "qwertyu",
            }

            self.students.append(data)

    def on_students(self, instance, students):
        table = self.ids.students_list
        table.clear_widgets()
        for student in students:
            tableRow = StudentTab()
            tableRow.id = str(student["id"])
            tableRow.avatar = str(student["avatar"])
            tableRow.name = str(student["name"])
            tableRow.grade = str(student["grade"])
            tableRow.classes = str(student["classes"])
            tableRow.username = str(student["username"])
            tableRow.dob = str(student["dob"])
            tableRow.email = str(student["email"])
            tableRow.phone = str(student["phone"])
            tableRow.address = str(student["address"])
            tableRow.password = str(student["password"])
            tableRow.update_callback = self.open_modal_update
            tableRow.delete_callback = self.delete_student
            table.add_widget(tableRow)

########################################################OPEN MODALS
    def open_modal_add(self):
        open_modal_add = StudentModal()
        open_modal_add.callback = self.add_student
        open_modal_add.open()

    def open_modal_update(self, instance):
        open_modal_update = StudentModal()
        open_modal_update.id = instance.id
        open_modal_update.avatar = instance.avatar
        open_modal_update.name = instance.name
        open_modal_update.grade = instance.grade
        open_modal_update.classes = instance.classes
        open_modal_update.username = instance.username
        open_modal_update.dob = instance.dob
        open_modal_update.email = instance.email
        open_modal_update.phone = instance.phone
        open_modal_update.address = instance.address
        open_modal_update.password = instance.password
        open_modal_update.callback = self.update_student
        open_modal_update.open()

########################################################ADD

    def add_student(self, student):
        avatar = student.ids.avatar.text
        name = student.ids.name.text
        grade = student.ids.grade.ids.spinner.text
        classes = student.ids.classes.ids.spinner.text
        username = student.ids.username.text
        dob = student.ids.dob.text
        email = student.ids.email.text
        phone = student.ids.phone.text
        address = student.ids.address.text
        password = student.ids.password.text

        if name == "" or grade == "Select grade..." or classes == "Select class..." or username == "" or dob == "" or email == "" or phone == "" or address == "":
            student.ids.error.text = "Fill in all the required fields!"
            student.ids.error.color = "red"
        else:
            if len(password) < 8:
                student.ids.error.text = "Password must be at least 8 characters long!"
                student.ids.error.color = "red"
            else:
                student.close = "close"
                self.addStudent = [avatar,name,grade,classes,username,dob,email,phone,address,password]
                add_student = ConfirmPopUp()
                add_student.title = "Add student?"
                add_student.callback = self.add_student_callback
                add_student.open()

    def add_student_callback(self, _):
        avatar = self.addStudent[0]
        name = self.addStudent[1]
        grade = self.addStudent[2]
        classes = self.addStudent[3]
        username = self.addStudent[4]
        dob = self.addStudent[5]
        email = self.addStudent[6]
        phone = self.addStudent[7]
        address = self.addStudent[8]
        password = self.addStudent[9]


########################################################UPDATE

    def update_student(self, student):
        id = student.id
        avatar = student.ids.avatar.text
        name = student.ids.name.text
        grade = student.ids.grade.ids.spinner.text
        classes = student.ids.classes.ids.spinner.text
        username = student.ids.username.text
        dob = student.ids.dob.text
        email = student.ids.email.text
        phone = student.ids.phone.text
        address = student.ids.address.text
        password = student.ids.password.text

        if name == "" or grade == "Select grade..." or classes == "Select class..." or username == ""  or username == "" or dob == "" or email == "" or phone == "" or address == "":
            student.ids.error.text = "Fill in all the required fields!"
            student.ids.error.color = "red"
        else:
            if len(password) < 8:
                student.ids.error.text = "Password must be at least 8 characters long!"
                student.ids.error.color = "red"
            else:
                student.close = "close"
                self.updateStudent = [id,avatar,name,grade,classes,username,dob,email,phone,address,password]
                update_student = ConfirmPopUp()
                update_student.title = "Update student?"
                update_student.callback = self.update_student_callback
                update_student.open()

    def update_student_callback(self, _):
        id = self.updateStudent[0]
        avatar = self.updateStudent[1]
        name = self.updateStudent[2]
        grade = self.updateStudent[3]
        classes = self.updateStudent[4]
        username = self.updateStudent[5]
        dob = self.updateStudent[6]
        email = self.updateStudent[7]
        phone = self.updateStudent[8]
        address = self.updateStudent[9]
        password = self.updateStudent[10]

########################################################DELETE

    def delete_student(self, student):
        self.deleteStudent = student.id
        delete_student = ConfirmPopUp()
        delete_student.title = "Delete student?"
        delete_student.callback = self.delete_student_callback
        delete_student.open()

    def delete_student_callback(self, _):
        id = self.deleteStudent


