from kivy.clock import Clock
from kivy.properties import ListProperty, StringProperty, NumericProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from widgets.tables import NoticeTab, ScheduleTab

Builder.load_file('views/studentprofile/studentprofile.kv')

class Studentprofile(Screen):
    image = StringProperty("assets/images/avatar.png")
    teacher_name = StringProperty("Tanaka PM")
    email = StringProperty("tanaka@mt.com")
    phone = StringProperty("+1234567890")
    attendance = NumericProperty(71)
    subjects = NumericProperty(35)
    classes = NumericProperty(22)
    announcements = ListProperty()
    lessons = ListProperty()

    def on_enter(self, *args):
        Clock.schedule_once(self.run_essentials, .1)

    def run_essentials(self, dt):
        self.show_announcements()
        self.show_lessons()

    def show_announcements(self):
        self.announcements = []
        announcements = [1,2,3,4,5,6,7,8]
        for x in announcements:
            data = {
                "id": "1",
                "date": "5 March 2025",
                "details": "Inter-schools competition for 5th graders."
            }

            self.announcements.append(data)

    def on_announcements(self, instance, announcements):
        table = self.ids.profile_notices_list
        table.clear_widgets()
        for announcement in announcements:
            tableRow = NoticeTab()
            tableRow.id = str(announcement["id"])
            tableRow.date = str(announcement["date"])
            tableRow.details = str(announcement["details"])
            table.add_widget(tableRow)

    def show_lessons(self):
        self.lessons = []
        lessons = [1,2,3,4,5,6,7,8]
        for x in lessons:
            data = {
                "id": "1",
                "subject": "Geography",
                "classes": "6B"
            }

            self.lessons.append(data)

    def on_lessons(self, instance, lessons):
        table = self.ids.today_schedule_list
        table.clear_widgets()
        for lesson in lessons:
            tableRow = ScheduleTab()
            tableRow.id = str(lesson["id"])
            tableRow.subject = str(lesson["subject"])
            tableRow.classes = str(lesson["classes"])
            table.add_widget(tableRow)
