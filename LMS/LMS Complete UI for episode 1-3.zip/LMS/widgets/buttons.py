from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.spinner import Spinner
from kivy.properties import StringProperty, ListProperty
from kivy.uix.behaviors import ToggleButtonBehavior, ButtonBehavior

Builder.load_string("""
<NavigationTab>:
    background_normal: ""
    background_down: ""
    background_color: [0,0,0,0]
    size_hint_y: None
    height: "35dp"
    spacing: "5dp"
    allow_no_selection: False
    
    BoxLayout:
        size_hint_x: None
        width: "4dp"
        canvas.before:
            Color:
                rgba: [0,0,0,0] if root.state == "normal" else rgba("#0096c7")
            RoundedRectangle:
                size: self.size
                pos: self.pos
                radius: [0,5,5,0]
                
    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIcon:
            icon: root.icon
            theme_text_color: "Custom"
            text_color: [0,0,0,0.7] if root.state == "normal" else rgba("#0096c7")
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            
    MDLabel:
        text: root.text
        font_style: "Label"
        role: "medium"
        bold: True
        color: [0,0,0,0.7] if root.state == "normal" else rgba("#0096c7")

<CustomDropDown>:
    MDIcon:
        icon: "chevron-down"
        theme_text_color: "Custom"
        text_color: "#8d8a8c"
        pos_hint: {"center_x": 0.9, "center_y": 0.5}
        
    Spinner:
        id: spinner
        text: root.text
        values: root.values
        font_size: "12sp"
        sync_width: True
        sync_height: True
        color: "#8d8a8c"
        option_cls: Factory.sp
        background_color: [0,0,0,0]
        background_normal: ""
        background_down: ""
        pos_hint: {"center_x": 0.5, "center_y": 0.5}
        
        
<CustomButton>:
    background_color: [0,0,0,0]
    background_down: ""
    background_normal: ""
    padding: ["10dp", 0]
    spacing: "10dp"
    canvas.before:
        Color:
            rgba: rgba("#0096c7")
        RoundedRectangle:
            size: self.size
            pos: self.pos
            radius: [5,5,5,5]
        
    MDIcon:
        size_hint_y: None
        width: self.height
        icon: root.icon
        theme_text_color: "Custom"
        text_color: "#ffffff"
        pos_hint: {"center_x": 0.5, "center_y": 0.5}
            
    MDLabel:
        text: root.text
        font_style: "Label"
        role: "medium"
        color: "#ffffff"
        bold: True
        
        
<CustomFlatButton>:
    background_color: [0,0,0,0]
    background_down: ""
    background_normal: ""
    padding: ["10dp", 0]
    canvas.before:
        Color:
            rgba: rgba("#0096c7")
        RoundedRectangle:
            size: self.size
            pos: self.pos
            radius: [5,5,5,5]
            
    MDLabel:
        text: root.text
        font_style: "Label"
        role: "medium"
        color: "#ffffff"
        bold: True
        halign: "center"
"""
)

class NavigationTab(ToggleButtonBehavior, BoxLayout):
    icon = StringProperty()
    text = StringProperty()

class CustomDropDown(FloatLayout):
    icon = StringProperty()
    values = ListProperty()
    text = StringProperty()

class CustomButton(ButtonBehavior, BoxLayout):
    icon = StringProperty()
    text = StringProperty()

    # def on_icon(self, instance, icon):
    #     self.ids.icon.icon = icon

class CustomFlatButton(ButtonBehavior, BoxLayout):
    text = StringProperty()