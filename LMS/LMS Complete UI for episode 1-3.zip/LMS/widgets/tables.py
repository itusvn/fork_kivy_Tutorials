from kivy.uix.boxlayout import BoxLayout
from kivy.uix.behaviors import ButtonBehavior
from kivy.properties import StringProperty, ObjectProperty
from kivy.lang import Builder

Builder.load_string("""
<NoticeTab>:
    size_hint_y: None
    height: "40dp"
    padding: "1dp"
    canvas.before:
        Color:
            rgba: rgba("#f1f1f1")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [5,5,5,5]

    BoxLayout:
        padding: ["10dp","2.5dp"]
        spacing: "10dp"
        canvas.before:
            Color:
                rgba: [1,1,1,1]
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [5,5,5,5]
                
        MDLabel:
            size_hint_x: .15
            text: root.date
            font_style: "Label"
            role: "medium"
                
        MDLabel:
            size_hint_x: .85
            text: root.details
            font_style: "Label"
            role: "medium"
            
<ScheduleTab>:
    size_hint_y: None
    height: "30dp"
    spacing: "10dp"

    MDLabel:
        text: root.subject
        font_style: "Label"
        role: "medium"
        halign: "center"

    MDLabel:
        text: root.classes
        font_style: "Label"
        role: "medium"
        halign: "center"
        
#########################################################TEACHERS TAB


<TeacherTab>:
    size_hint_y: None
    height: "35dp"
    spacing: "10dp"
    padding: [0,0,0,"2dp"]
    on_press: root.update_callback(self)
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        Rectangle:
            pos: self.pos
            size: [self.size[0], dp(1)]
    
    BoxLayout:
        size_hint_x: None
        width: self.height
        canvas.before:
            Color:
                rgba: rgba("ffffff")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [5,5,5,5]
                source: root.avatar
        

    MDLabel:
        text: root.name
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.username
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.dob
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.email
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.phone
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.address
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.password
        font_style: "Label"
        role: "medium"

    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIconButton:
            icon: "delete-outline"
            theme_text_color: "Custom"
            text_color: "#ff6666"
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            on_press: root.delete_callback(self)
        
#########################################################STUDENTS TAB


<StudentTab>:
    size_hint_y: None
    height: "35dp"
    spacing: "10dp"
    padding: [0,0,0,"2dp"]
    on_press: root.update_callback(self)
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        Rectangle:
            pos: self.pos
            size: [self.size[0], dp(1)]
    
    BoxLayout:
        size_hint_x: None
        width: self.height
        canvas.before:
            Color:
                rgba: rgba("ffffff")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [5,5,5,5]
                source: root.avatar

    MDLabel:
        text: root.name
        font_style: "Label"
        role: "medium"

    MDLabel:
        size_hint_x: None
        width: "50dp"
        text: root.grade
        font_style: "Label"
        role: "medium"
        

    MDLabel:
        size_hint_x: None
        width: "50dp"
        text: root.classes
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.username
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.dob
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.email
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.phone
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.address
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.password
        font_style: "Label"
        role: "medium"

    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIconButton:
            icon: "delete-outline"
            theme_text_color: "Custom"
            text_color: "#ff6666"
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            on_press: root.delete_callback(self)
        
#########################################################PARENTS TAB


<ParentTab>:
    size_hint_y: None
    height: "35dp"
    spacing: "10dp"
    padding: [0,0,0,"2dp"]
    on_press: root.update_callback(self)
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        Rectangle:
            pos: self.pos
            size: [self.size[0], dp(1)]
    
    BoxLayout:
        size_hint_x: None
        width: self.height
        canvas.before:
            Color:
                rgba: rgba("ffffff")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [5,5,5,5]
                source: root.avatar

    MDLabel:
        text: root.name
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.student
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.username
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.dob
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.email
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.phone
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.address
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.password
        font_style: "Label"
        role: "medium"

    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIconButton:
            icon: "delete-outline"
            theme_text_color: "Custom"
            text_color: "#ff6666"
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            on_press: root.delete_callback(self)
        
#########################################################CLASSES TAB


<ClassTab>:
    size_hint_y: None
    height: "35dp"
    spacing: "10dp"
    padding: [0,0,0,"2dp"]
    on_press: root.update_callback(self)
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        Rectangle:
            pos: self.pos
            size: [self.size[0], dp(1)]

    MDLabel:
        text: root.classes
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.grade
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.capacity
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.supervisor
        font_style: "Label"
        role: "medium"

    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIconButton:
            icon: "delete-outline"
            theme_text_color: "Custom"
            text_color: "#ff6666"
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            on_press: root.delete_callback(self)
        
#########################################################SUBJECTS TAB


<SubjectTab>:
    size_hint_y: None
    height: "35dp"
    spacing: "10dp"
    padding: [0,0,0,"2dp"]
    on_press: root.update_callback(self)
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        Rectangle:
            pos: self.pos
            size: [self.size[0], dp(1)]

    MDLabel:
        text: root.subject
        font_style: "Label"
        role: "medium"

    MDLabel:
        text: root.teacher
        font_style: "Label"
        role: "medium"

    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIconButton:
            icon: "delete-outline"
            theme_text_color: "Custom"
            text_color: "#ff6666"
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            on_press: root.delete_callback(self)
        
#########################################################NOTICES TAB


<CreateNoticeTab>:
    size_hint_y: None
    height: "35dp"
    spacing: "10dp"
    padding: [0,0,0,"2dp"]
    on_press: root.update_callback(self)
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        Rectangle:
            pos: self.pos
            size: [self.size[0], dp(1)]

    MDLabel:
        size_hint_x: .15
        text: root.date
        font_style: "Label"
        role: "medium"

    MDLabel:
        size_hint_x: .85
        text: root.announcement
        font_style: "Label"
        role: "medium"

    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIconButton:
            icon: "delete-outline"
            theme_text_color: "Custom"
            text_color: "#ff6666"
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            on_press: root.delete_callback(self)
        
""")

class NoticeTab(BoxLayout):
    date = StringProperty()
    details = StringProperty()

class ScheduleTab(BoxLayout):
    subject = StringProperty()
    classes = StringProperty()

#########################################################TEACHERS TAB
class TeacherTab(ButtonBehavior, BoxLayout):
    id = StringProperty()
    avatar = StringProperty()
    name = StringProperty()
    username = StringProperty()
    dob = StringProperty()
    email = StringProperty()
    phone = StringProperty()
    address = StringProperty()
    password = StringProperty()
    update_callback = ObjectProperty(allownone = True)
    delete_callback = ObjectProperty(allownone = True)

#########################################################TEACHERS TAB
class StudentTab(ButtonBehavior, BoxLayout):
    id = StringProperty()
    avatar = StringProperty()
    name = StringProperty()
    grade = StringProperty()
    classes = StringProperty()
    username = StringProperty()
    dob = StringProperty()
    email = StringProperty()
    phone = StringProperty()
    address = StringProperty()
    password = StringProperty()
    update_callback = ObjectProperty(allownone = True)
    delete_callback = ObjectProperty(allownone = True)

#########################################################PARENTS TAB
class ParentTab(ButtonBehavior, BoxLayout):
    id = StringProperty()
    avatar = StringProperty()
    name = StringProperty()
    student = StringProperty()
    username = StringProperty()
    dob = StringProperty()
    email = StringProperty()
    phone = StringProperty()
    address = StringProperty()
    password = StringProperty()
    update_callback = ObjectProperty(allownone = True)
    delete_callback = ObjectProperty(allownone = True)

#########################################################CLASSES TAB
class ClassTab(ButtonBehavior, BoxLayout):
    id = StringProperty()
    classes = StringProperty()
    grade = StringProperty()
    capacity = StringProperty()
    supervisor = StringProperty()
    update_callback = ObjectProperty(allownone = True)
    delete_callback = ObjectProperty(allownone = True)

#########################################################CLASSES TAB
class SubjectTab(ButtonBehavior, BoxLayout):
    id = StringProperty()
    subject = StringProperty()
    teacher = StringProperty()
    update_callback = ObjectProperty(allownone = True)
    delete_callback = ObjectProperty(allownone = True)

#########################################################CLASSES TAB
class CreateNoticeTab(ButtonBehavior, BoxLayout):
    id = StringProperty()
    date = StringProperty()
    announcement = StringProperty()
    update_callback = ObjectProperty(allownone = True)
    delete_callback = ObjectProperty(allownone = True)
