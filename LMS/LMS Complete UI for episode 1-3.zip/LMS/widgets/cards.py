from kivy.lang import Builder
from kivy.properties import StringProperty, NumericProperty
from kivy.uix.boxlayout import BoxLayout

Builder.load_string("""
<UserCard>:
    orientation: "vertical"
    padding: "10dp"
    canvas.before:
        Color:
            rgba: rgba("#f5f5f5")
        RoundedRectangle:
            size: self.size
            pos: self.pos
            radius: [5,5,5,5]

    BoxLayout:
        size_hint_y: None
        height: "35dp"

        FloatLayout:
            size_hint_x: None
            width: self.height

            MDIcon:
                icon: root.icon
                theme_text_color: "Custom"
                text_color: [0,0,0,0.7]
                pos_hint: {"center_x": 0.5, "center_y": 0.5}

        MDLabel:
            text: root.text
            halign: "right"
            font_style: "Label"
            role: "medium"
            bold: True
            color: [0,0,0,0.7]

    MDLabel:
        text: str(root.num)
        halign: "right"
        font_style: "Label"
        role: "medium"
        bold: True
        color: [0,0,0,0.7]
        
<ProfileCard>:
    padding: "10dp"
    spacing: "10dp"
    canvas.before:
        Color:
            rgba: rgba("#f5f5f5")
        RoundedRectangle:
            size: self.size
            pos: self.pos
            radius: [5,5,5,5]
            
    BoxLayout:
        size_hint_x: None
        width: self.height
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                size: self.size
                pos: self.pos
                radius: [5,5,5,5]
                source: root.image
                
    BoxLayout:
        orientation: "vertical"
        spacing: "10dp"

        MDLabel:
            text: root.name
            font_style: "Label"
            role: "medium"
            bold: True
            color: [0,0,0,0.7]
    
        MDLabel:
            text: root.email
            font_style: "Label"
            role: "medium"
            bold: True
            color: [0,0,0,0.7]
    
        MDLabel:
            text: root.phone
            font_style: "Label"
            role: "medium"
            bold: True
            color: [0,0,0,0.7]
        
        
    

""")

class UserCard(BoxLayout):
    icon = StringProperty()
    text = StringProperty()
    num = NumericProperty()

class ProfileCard(BoxLayout):
    image = StringProperty()
    name = StringProperty()
    email = StringProperty()
    phone = StringProperty()