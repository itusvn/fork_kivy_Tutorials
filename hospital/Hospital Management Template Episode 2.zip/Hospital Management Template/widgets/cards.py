from kivy.lang import Builder
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout

Builder.load_string('''
<InfoCard>:
    size_hint_y: None
    height: "90dp"
    padding: "1dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [5,5,5,5]

    BoxLayout:
        orientation: "vertical"
        padding: "10dp"
        spacing: "10dp"
        canvas.before:
            Color:
                rgba: [1,1,1,1]
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [5,5,5,5]

        BoxLayout:
            size_hint_y: None
            height: "40dp"
            spacing: "10dp"

            FloatLayout:
                size_hint_x: None
                width: self.height
                canvas.before:
                    Color:
                        rgba: rgba("#0096c7")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [5,5,5,5]

                MDIcon:
                    icon: root.icon
                    theme_text_color: "Custom"
                    text_color: "#ffffff"
                    pos_hint: {"center_x":0.5, "center_y":0.5}

            MDLabel:
                text: root.info
                font_style: "Title"
                role: "medium"
                bold: True
                halign: "right"

        MDLabel:
            text: root.title
            font_style: "Label"
            role: "medium"
            halign: "right"
            color: [0,0,0,0.5]
''')


class InfoCard(BoxLayout):
    icon = StringProperty()
    info = StringProperty()
    title = StringProperty()


