from kivy.lang import Builder
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput

Builder.load_string('''
<TextField>:
    cursor_color: [0,0,0,1]
    foreground_color: [0,0,0,1]
    background_color: 0, 0, 0, 0
    background_normal: ''
    background_active: ''
    write_tab: False
    font_size: "11sp"
    font_name: app.body
    
###############################
<CustomTextField>:
    size_hint_y: None
    height: "35dp"
    padding: "1dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [5,5,5,5]
            
    BoxLayout:
        padding: ["10dp", "2.5dp"]
        spacing: "10dp"
        canvas.before:
            Color:
                rgba: rgba("#f7f7f7")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [5,5,5,5]
                
        MDLabel:
            size_hint_x: None
            width: "60dp"
            text: root.label
            font_style: "Label"
            role: "medium"
            bold: True
                
        TextField:
            id: text_input
            hint_text: root.hint_text
            multiline: "False"
    
###############################
<CustomTextFieldLarge>:
    padding: "1dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [5,5,5,5]
            
    BoxLayout:
        padding: ["10dp", "2.5dp"]
        spacing: "10dp"
        canvas.before:
            Color:
                rgba: rgba("#f7f7f7")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [5,5,5,5]
                
        AnchorLayout:
            size_hint_x: None
            width: "60dp"
            anchor_y: "top"
                
            MDLabel:
                size_hint_y: None
                height: "30dp"
                text: root.label
                font_style: "Label"
                role: "medium"
                bold: True
                
        TextField:
            id: text_input
            hint_text: root.hint_text
            multiline: "False"
        
''')

class TextField(TextInput):
    def __init__(self, **kw) -> None:
        super().__init__(**kw)
 
class CustomTextField(BoxLayout):
    label = StringProperty()
    hint_text = StringProperty()
    input_filter = StringProperty("string")

class CustomTextFieldLarge(BoxLayout):
    label = StringProperty()
    hint_text = StringProperty()
