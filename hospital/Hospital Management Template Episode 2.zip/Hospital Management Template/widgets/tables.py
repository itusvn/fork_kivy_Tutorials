from kivy.uix.boxlayout import BoxLayout
from kivy.uix.behaviors import ButtonBehavior
from kivy.properties import StringProperty, ObjectProperty
from kivy.lang import Builder

Builder.load_string("""
<RecentPatientsTab>:
    size_hint_y: None
    height: "30dp"
    padding: ["10dp", 0]
    spacing: "10dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        Rectangle:
            pos: self.pos
            size: [self.size[0], dp(1)]

    MDLabel:
        size_hint_x: 0.3
        text: root.name
        font_style: "Label"
        role: "medium"

    MDLabel:
        size_hint_x: 0.3
        text: root.address
        font_style: "Label"
        role: "medium"

    MDLabel:
        size_hint_x: 0.1
        text: root.dob
        font_style: "Label"
        role: "medium"

    MDLabel:
        size_hint_x: 0.1
        text: root.phone
        font_style: "Label"
        role: "medium"

    MDLabel:
        size_hint_x: 0.1
        text: root.gender
        font_style: "Label"
        role: "medium"

    MDLabel:
        size_hint_x: 0.1
        text: root.blood_type
        font_style: "Label"
        role: "medium"
        
###########################################################################
<ScheduledAppointmentsTab>:
    orientation: "vertical"
    size_hint_y: None
    height: "100dp"
    padding: "10dp"
    spacing: "10dp"
    on_press: root.callback(root)
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [5,5,5,5]

    MDLabel:
        text: root.patient
        font_style: "Label"
        role: "medium"
        bold: True
        halign: "right"

    MDLabel:
        text: root.doctor
        font_style: "Label"
        role: "medium"
        bold: True
        halign: "right"

    MDLabel:
        text: root.date + " " + root.time
        font_style: "Label"
        role: "medium"
        halign: "right"
    
""")

class RecentPatientsTab(BoxLayout):
    id = StringProperty()
    name = StringProperty()
    dob = StringProperty()
    gender = StringProperty()
    phone = StringProperty()
    email = StringProperty()
    address = StringProperty()
    blood_type = StringProperty()
    medical_history = StringProperty()

class ScheduledAppointmentsTab(ButtonBehavior, BoxLayout):
    id = StringProperty()
    patient = StringProperty()
    doctor = StringProperty()
    date = StringProperty()
    time = StringProperty()
    reason = StringProperty()
    status = StringProperty()
    callback = ObjectProperty(allownone=True)
