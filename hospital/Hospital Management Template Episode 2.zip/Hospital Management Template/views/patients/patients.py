from kivy.clock import Clock
from kivy.properties import NumericProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from data.connection import connection
from widgets.popups import WarningPopUp

Builder.load_file('views/patients/patients.kv')

class Patients(Screen):
    user_id = NumericProperty(1)

    patients = NumericProperty()
    doctors = NumericProperty()
    appointments = NumericProperty()
    beds = NumericProperty()
    def on_enter(self, *args):
        self.updateAppointment = None
        Clock.schedule_once(self.run_essentials, 0.1)

    def run_essentials(self, dt):
        self.fill_cards()

    def fill_cards(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            #Total Patients
            sql = "SELECT COUNT(*) FROM patients WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            patients = cursor.fetchone()[0]
            self.patients = patients

            #Total Doctors
            #Total Patients
            sql = "SELECT COUNT(*) FROM staff WHERE user_id = %s AND position = %s"
            values = [str(self.user_id), "Doctor"]
            cursor.execute(sql, values)
            doctors = cursor.fetchone()[0]
            self.doctors = doctors

            #Total Scheduled Appointments
            sql = "SELECT COUNT(*) FROM appointments WHERE user_id = %s AND status = %s"
            values = [str(self.user_id), "Scheduled"]
            cursor.execute(sql, values)
            appointments = cursor.fetchone()[0]
            self.appointments = appointments

            #Total Beds Available
            sql = "SELECT COUNT(*) FROM beds WHERE user_id = %s AND status = %s"
            values = [str(self.user_id), "Available"]
            cursor.execute(sql, values)
            beds = cursor.fetchone()[0]
            self.beds = beds

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()
