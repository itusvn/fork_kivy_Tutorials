import json
from datetime import datetime, date

from kivy.clock import Clock
from kivy.properties import NumericProperty, ListProperty, StringProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivymd.uix.filemanager import MDFileManager

from data.connection import connection
from widgets.images import ImageDetection
from widgets.popups import ConfirmPopUp, WarningPopUp
from widgets.tables import ScheduledAppointmentsTab

Builder.load_file('views/consultations/consultations.kv')

class Consultations(Screen):
    consultation_types = [
        "Acid reflux/GERD check-up",
        "Acne and skin rash consultation",
        "Antenatal/prenatal check-up",
        "Arthritis evaluation",
        "Back and spine consultation",
        "Bone and joint pain consultation",
        "Cardiac health screening",
        "Cataract evaluation",
        "Cholesterol management",
        "Colonoscopy follow-up",
        "Dental check-up",
        "Dental implant consultation",
        "Developmental assessment",
        "Diabetes management consultation",
        "Diabetic retinopathy screening",
        "Eczema/psoriasis treatment",
        "ECG review consultation",
        "Erectile dysfunction consultation",
        "Epilepsy/seizure evaluation",
        "Family planning consultation",
        "Fertility assessment",
        "General medical consultation",
        "Glaucoma screening",
        "Gynecological consultation",
        "Hair loss consultation",
        "Headache/migraine consultation",
        "Health screening",
        "Hearing test consultation",
        "High blood pressure consultation",
        "Hormone imbalance consultation",
        "Immunization consultation",
        "Incontinence consultation",
        "Kidney stone evaluation",
        "Liver function consultation",
        "Male reproductive health check-up",
        "Memory loss consultation",
        "Mole or skin cancer screening",
        "Obesity/weight management",
        "Optical/eye check-up",
        "Orthodontic consultation (braces)",
        "Pap smear screening",
        "Pediatric nutrition consultation",
        "Pediatric wellness check-up",
        "Periodontal (gum disease) evaluation",
        "Postnatal consultation",
        "Preventive health check-up",
        "Prostate screening",
        "Routine physical examination",
        "Sinus issues consultation",
        "Sports injury consultation",
        "Stomach pain consultation",
        "Stroke follow-up",
        "Testosterone level evaluation",
        "Throat infection consultation",
        "Thyroid disorder evaluation",
        "Tooth extraction consultation",
        "Tonsillitis evaluation",
        "Urinary tract infection consultation",
        "Vaccination consultation"
    ]


    user_id = NumericProperty()
    staff_id = NumericProperty()
    patient_id = NumericProperty()

    patients = NumericProperty()
    doctors = NumericProperty()
    appointments = NumericProperty()
    consultations = NumericProperty()

    scheduled_appointments = ListProperty()

    x_ray_image_file_path = StringProperty()
    def on_enter(self, *args):
        self.updateAppointment = None
        self.addConsultation = []
        self.file_manager_object = MDFileManager(
            background_color_toolbar = "blue",
            background_color_selection_button="blue",
            select_path = self.select_image_file_path,
            exit_manager = self.exit_file_manager,
            preview = True
        )
        Clock.schedule_once(self.run_essentials, 0.1)

    def select_image_file_path(self, path):
        self.x_ray_image_file_path = rf'{path}'
        self.exit_file_manager(self)

    def exit_file_manager(self, *args):
        self.file_manager_object.close()

    def run_essentials(self, dt):
        self.get_user_id()
        self.fill_cards()
        self.show_scheduled_appointments()

    def get_user_id(self):
        try:
            SESSION_FILE = "session.json"
            with open(SESSION_FILE, "r") as file:
                session = json.load(file)
                self.user_id = session.get("user_id")
                self.staff_id = session.get("staff_id")
        except FileNotFoundError:
            return None

    def refresh_appointments(self):
        self.show_scheduled_appointments()

    def fill_cards(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            #Total Patients
            sql = "SELECT COUNT(*) FROM patients WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            patients = cursor.fetchone()[0]
            self.patients = patients

            sql = "SELECT * FROM patients WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            patients_list = cursor.fetchall()
            list_of_patients = []
            for x in patients_list:
                list_of_patients.append(str(x[0]) + " | " + x[2])

            self.ids.patient.values = list_of_patients

            #Total Doctors
            sql = "SELECT COUNT(*) FROM staff WHERE user_id = %s AND position = %s"
            values = [str(self.user_id), "Doctor"]
            cursor.execute(sql, values)
            doctors = cursor.fetchone()[0]
            self.doctors = doctors

            #Total Scheduled Appointments
            sql = "SELECT COUNT(*) FROM appointments WHERE user_id = %s AND status = %s"
            values = [str(self.user_id), "Scheduled"]
            cursor.execute(sql, values)
            appointments = cursor.fetchone()[0]
            self.appointments = appointments

            #Total Consultations
            sql = "SELECT COUNT(*) FROM consultations WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            consultations = cursor.fetchone()[0]
            self.consultations = consultations

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def get_patient_info(self, text):
        if text == "Select patient...":
            pass
        else:
            patient_id = text[:text.find(" | ")]
            self.patient_id = patient_id
            conn = connection()
            cursor = conn.cursor()
            try:
                sql = "SELECT * FROM patients WHERE id = %s"
                values = [str(self.patient_id)]
                cursor.execute(sql, values)
                patient_info = cursor.fetchall()
                for x in patient_info:
                    self.ids.dob.text = str(x[3])
                    self.ids.gender.text = str(x[4])
                    self.ids.blood_type.text = str(x[8])
                    self.ids.pmh.ids.text_input.text = str(x[9])

            except Exception as error:
                warning_pop_up = WarningPopUp()
                warning_pop_up.title = f"{error}"
                warning_pop_up.open()

            finally:
                if conn:
                    conn.close()

    def clear(self):
        self.ids.patient.text = "Select patient..."
        self.ids.consultation_type.text = "Select consultation type..."
        self.ids.dob.text = ""
        self.ids.gender.text = ""
        self.ids.blood_type.text = ""
        self.ids.cc.ids.text_input.text = ""
        self.ids.hpi.ids.text_input.text = ""
        self.ids.pmh.ids.text_input.text = ""
        self.ids.pe.ids.text_input.text = ""
        self.ids.ros.ids.text_input.text = ""
        self.ids.allergies.ids.text_input.text = ""
        self.ids.family_history.ids.text_input.text = ""
        self.ids.social_history.ids.text_input.text = ""
        self.ids.diagnosis.ids.text_input.text = ""
        self.ids.treatment.ids.text_input.text = ""
        self.ids.error.text = ""

    def save(self):
        patient = self.ids.patient.text
        consultation_type = self.ids.consultation_type.text
        cc = self.ids.cc.ids.text_input.text
        hpi = self.ids.hpi.ids.text_input.text
        pmh = self.ids.pmh.ids.text_input.text
        pe = self.ids.pe.ids.text_input.text
        ros = self.ids.ros.ids.text_input.text
        allergies = self.ids.allergies.ids.text_input.text
        family_history = self.ids.family_history.ids.text_input.text
        social_history = self.ids.social_history.ids.text_input.text
        diagnosis = self.ids.diagnosis.ids.text_input.text
        treatment = self.ids.treatment.ids.text_input.text

        if (patient == "Select patient..." or consultation_type == "Select consultation type..." or cc == "" or hpi == ""
            or pmh == "" or pe == "" or ros == "" or allergies == "" or family_history == "" or social_history == ""
            or diagnosis == "" or treatment == ""):



            self.ids.error.text = "Fill in all required fields!"
        else:
            self.addConsultation = [
                consultation_type, cc, hpi, pmh, pe, ros, allergies,
                family_history, social_history, diagnosis, treatment
            ]
            add_consultation = ConfirmPopUp()
            add_consultation.title = "Add consultation information?"
            add_consultation.callback = self.save_callback
            add_consultation.open()

    def save_callback(self, *args):
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")

        user_id = self.user_id
        staff_id = self.staff_id
        patient_id = self.patient_id
        consultation_type = self.addConsultation[0]
        date_ = date.today()
        time = current_time
        cc = self.addConsultation[1]
        hpi = self.addConsultation[2]
        pmh = self.addConsultation[3]
        pe = self.addConsultation[4]
        ros = self.addConsultation[5]
        allergies = self.addConsultation[6]
        family_history = self.addConsultation[7]
        social_history = self.addConsultation[8]
        diagnosis = self.addConsultation[9]
        treatment = self.addConsultation[10]

        conn = connection()
        cursor = conn.cursor()
        try:
            sql = """
                INSERT INTO consultations (
                    user_id, patient_id, staff_id, consultation_type, date, time, cc, hpi, pmh, pe, ros,
                    allergies, family_history, social_history, diagnosis, treatment 
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            values = [
                user_id, patient_id, staff_id, consultation_type, date_, time, cc, hpi, pmh, pe, ros,
                allergies, family_history, social_history, diagnosis, treatment
            ]
            cursor.execute(sql, values)
            conn.commit()
            self.clear()

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()



    def fracture_detection(self):
        self.file_manager_object.show("/")

    def on_x_ray_image_file_path(self, instance, x_ray_image_file_path):
        fracture_detection = ImageDetection()
        fracture_detection.image_source = x_ray_image_file_path
        fracture_detection.open()























    def show_scheduled_appointments(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            self.scheduled_appointments = []
            sql = """
                SELECT
                    a.id,
                    a.user_id,
                    a.patient_id,
                    a.staff_id,
                    a.date,
                    a.time,
                    a.reason,
                    a.status,
                    p.name AS patient_name,
                    s.name AS doctor_name
                FROM appointments a
                JOIN patients p ON a.patient_id = p.id AND p.user_id = a.user_id
                JOIN staff s ON a.staff_id = s.id AND s.user_id = a.user_id
                WHERE a.user_id = %s AND a.status = %s;
            """
            values = [str(self.user_id), "Scheduled"]
            cursor.execute(sql, values)
            scheduled_appointments = cursor.fetchall()
            for x in scheduled_appointments:
                data = {
                    "id": x[0],
                    "patient": x[8],
                    "doctor": x[9],
                    "date": x[4],
                    "time": x[5],
                    "reason": x[6],
                    "status": x[7]
                }

                self.scheduled_appointments.append(data)

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def on_scheduled_appointments(self, instance, scheduled_appointments):
        table = self.ids.scheduled_appointments_list
        table.clear_widgets()
        for x in scheduled_appointments:
            tableRow = ScheduledAppointmentsTab()
            tableRow.id = str(x["id"])
            tableRow.patient = str(x["patient"])
            tableRow.doctor = str(x["doctor"])
            tableRow.date = str(x["date"])
            tableRow.time = str(x["time"])
            tableRow.reason = str(x["reason"])
            tableRow.status = str(x["status"])
            tableRow.callback = self.update_status
            table.add_widget(tableRow)

    def update_status(self, instance):
        self.updateAppointment = instance.id
        update_status = ConfirmPopUp()
        update_status.title = "Mark appointment as completed?"
        update_status.callback =  self.update_status_callback
        update_status.open()

    def update_status_callback(self, *args):
        id = self.updateAppointment
        status = "Completed"
        conn = connection()
        cursor = conn.cursor()
        try:
            sql = "UPDATE appointments SET status = %s WHERE id = %s"
            values = [status, id]
            cursor.execute(sql, values)
            conn.commit()
            self.show_scheduled_appointments()

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()
