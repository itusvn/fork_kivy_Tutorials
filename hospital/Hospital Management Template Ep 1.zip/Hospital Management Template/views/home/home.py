from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivy.properties import StringProperty

from widgets.popups import ConfirmPopUp

Builder.load_file('views/home/home.kv')
class Home(Screen):
    user = StringProperty("Tanaka Peter")
    user_type = StringProperty("Admin")
    avatar = "assets/images/avatar.png"
    def on_enter(self, *args):
        return super().on_enter(*args)

    def logout(self):
        logout = ConfirmPopUp()
        logout.title = "Are you sure you want to logout?"
        logout.callback = self.logout_callback
        logout.open()

    def logout_callback(self, *args):
        print("Logging out!")