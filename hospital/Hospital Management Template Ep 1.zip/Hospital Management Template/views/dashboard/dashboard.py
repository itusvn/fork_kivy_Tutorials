from kivy.clock import Clock
from kivy.properties import NumericProperty, ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from data.connection import connection
from widgets.popups import WarningPopUp

import numpy as np
import matplotlib.pyplot as plt
from kivy_garden.matplotlib.backend_kivyagg import FigureCanvasKivyAgg as FCK

from widgets.tables import RecentPatientsTab, ScheduledAppointmentsTab

Builder.load_file('views/dashboard/dashboard.kv')

class Dashboard(Screen):
    user_id = NumericProperty(1)

    patients = NumericProperty()
    doctors = NumericProperty()
    appointments = NumericProperty()
    beds = NumericProperty()

    recent_patients = ListProperty()
    scheduled_appointments = ListProperty()
    def on_enter(self, *args):
        Clock.schedule_once(self.run_essentials, 0.1)

    def run_essentials(self, dt):
        self.fill_cards()
        self.draw_chart()
        self.show_recent_patients()
        self.show_scheduled_appointments()

    def refresh_appointments(self):
        self.show_scheduled_appointments()

    def refresh_recent_patients(self):
        self.show_recent_patients()

    def fill_cards(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            #Total Patients
            sql = "SELECT COUNT(*) FROM patients WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            patients = cursor.fetchone()[0]
            self.patients = patients

            #Total Doctors
            #Total Patients
            sql = "SELECT COUNT(*) FROM staff WHERE user_id = %s AND position = %s"
            values = [str(self.user_id), "Doctor"]
            cursor.execute(sql, values)
            doctors = cursor.fetchone()[0]
            self.doctors = doctors

            #Total Scheduled Appointments
            sql = "SELECT COUNT(*) FROM appointments WHERE user_id = %s AND status = %s"
            values = [str(self.user_id), "Scheduled"]
            cursor.execute(sql, values)
            appointments = cursor.fetchone()[0]
            self.appointments = appointments

            #Total Beds Available
            sql = "SELECT COUNT(*) FROM beds WHERE user_id = %s AND status = %s"
            values = [str(self.user_id), "Available"]
            cursor.execute(sql, values)
            beds = cursor.fetchone()[0]
            self.beds = beds

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def draw_chart(self):
        selector = "Monthly"

        count = np.arange(12)
        labels = ["Jan", "Feb", "Mar", " Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

        #Simulated data
        patients = 50 + 10 * np.sin(0.5 * count) + np.random.randint(-5, 5, size = len(count))
        inpatients = 30 + 15 * np.sin(0.5 * count) + np.random.randint(-5, 5, size = len(count))

        fig, ax = plt.subplots(figsize = (10, 4))

        ax.plot(count, patients, label = "Patients", color = "blue")
        ax.plot(count, inpatients, label = "Inpatients", color = "mediumseagreen")
        ax.fill_between(count, patients, alpha = 0.05, color = "blue")
        ax.fill_between(count, inpatients, alpha = 0.05, color = "mediumseagreen")

        ax.set_xticks(count)
        ax.set_xticklabels(labels, fontsize= 8)
        ax.set_yticklabels(count, fontsize= 8, rotation=90)
        ax.set_title(f"{selector} Patient-Inpatient statistics", fontsize=8)
        ax.grid(True, linestyle="--", alpha=0.5)
        ax.legend(fontsize=8)

        ax.spines["top"].set_visible(False)
        ax.spines["bottom"].set_visible(False)
        ax.spines["left"].set_visible(False)
        ax.spines["right"].set_visible(False)

        fig.tight_layout()


        self.ids.our_chart.clear_widgets()
        self.ids.our_chart.add_widget(FCK(fig))

    def show_recent_patients(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            self.recent_patients = []
            sql = "SELECT * FROM patients WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            recent_patients = cursor.fetchall()
            for x in recent_patients:
                data = {
                    "id": x[0],
                    "name": x[2],
                    "dob": x[3],
                    "gender": x[4],
                    "phone": x[5],
                    "email": x[6],
                    "address": x[7],
                    "blood_type": x[8],
                    "medical_history": x[9]
                }

                self.recent_patients.append(data)

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def on_recent_patients(self, instance, recent_patients):
        table = self.ids.recent_patients_list
        table.clear_widgets()
        for x in recent_patients:
            tableRow = RecentPatientsTab()
            tableRow.id = str(x["id"])
            tableRow.name = str(x["name"])
            tableRow.dob = str(x["dob"])
            tableRow.gender = str(x["gender"])
            tableRow.phone = str(x["phone"])
            tableRow.email = str(x["email"])
            tableRow.address = str(x["address"])
            tableRow.blood_type = str(x["blood_type"])
            tableRow.medical_history = str(x["medical_history"])
            table.add_widget(tableRow)

    def show_scheduled_appointments(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            self.scheduled_appointments = []
            sql = """
                SELECT
                    a.id,
                    a.user_id,
                    a.patient_id,
                    a.staff_id,
                    a.date,
                    a.time,
                    a.reason,
                    a.status,
                    p.name AS patient_name,
                    s.name AS doctor_name
                FROM appointments a
                JOIN patients p ON a.patient_id = p.id AND p.user_id = a.user_id
                JOIN staff s ON a.staff_id = s.id AND s.user_id = a.user_id
                WHERE a.user_id = %s;
            """
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            scheduled_appointments = cursor.fetchall()
            for x in scheduled_appointments:
                data = {
                    "id": x[0],
                    "patient": x[8],
                    "doctor": x[9],
                    "date": x[4],
                    "time": x[5],
                    "reason": x[6],
                    "status": x[7]
                }

                self.scheduled_appointments.append(data)

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def on_scheduled_appointments(self, instance, scheduled_appointments):
        table = self.ids.scheduled_appointments_list
        table.clear_widgets()
        for x in scheduled_appointments:
            tableRow = ScheduledAppointmentsTab()
            tableRow.id = str(x["id"])
            tableRow.patient = str(x["patient"])
            tableRow.doctor = str(x["doctor"])
            tableRow.date = str(x["date"])
            tableRow.time = str(x["time"])
            tableRow.reason = str(x["reason"])
            tableRow.status = str(x["status"])
            table.add_widget(tableRow)