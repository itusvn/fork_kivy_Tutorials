from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.spinner import Spinner
from kivy.properties import StringProperty, ListProperty
from kivy.uix.behaviors import ToggleButtonBehavior, ButtonBehavior

Builder.load_string("""
<NavigationTab>:
    background_normal: ''
    background_down: ''
    background_color: [0,0,0,0]
    size_hint_y: None
    height: "40dp"
    allow_no_selection: False
    canvas.before:
        Color:
            rgba: [0,0,0,0] if root.state == "normal" else rgba("#0096c7")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [5,5,5,5]
                
    FloatLayout:
        size_hint_x: None
        width: self.height

        MDIcon:
            icon: root.icon
            theme_text_color: "Custom"
            text_color: [0,0,0,1] if root.state == "normal" else rgba("#ffffff")
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            
    MDLabel:
        text: root.text
        valign: "middle"
        font_style: "Label"
        role: "medium"
        bold: True
        color: [0,0,0,1] if root.state == "normal" else rgba("#ffffff")
        
        
        
##########################################################
<NavigationTabHoz>:
    orientation: "vertical"
    background_normal: ''
    background_down: ''
    background_color: [0,0,0,0]
    size_hint_y: None
    height: "35dp"
    spacing: "4dp"
    allow_no_selection: False
    
    BoxLayout:
        padding: ["10dp", 0]
        spacing: "4dp"
                
        FloatLayout:
            size_hint_x: None
            width: self.height
    
            MDIcon:
                icon: root.icon
                theme_text_color: "Custom"
                text_color: rgba("#8d8a8c") if root.state == "normal" else [0,0,0,1]
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
        MDLabel:
            text: root.text
            valign: "middle"
            font_style: "Label"
            role: "medium"
            bold: True
            color: rgba("#8d8a8c") if root.state == "normal" else [0,0,0,1]
    
    BoxLayout:
        size_hint_y: None
        height: "1dp" if root.state == "normal" else "3dp"
        canvas.before:
            Color:
                rgba: rgba("#8d8a8c") if root.state == "normal" else rgba("#0096c7")
            Rectangle:
                pos: self.pos
                size: self.size

#####################################
<CustomButton>:
    background_normal: ''
    background_down: ''
    background_color: [0,0,0,0]
    canvas.before:
        Color:
            rgba: rgba("#0096c7")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [5,5,5,5]
            
    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIcon:
            icon: root.icon
            theme_text_color: "Custom"
            text_color: "#ffffff"
            pos_hint: {"center_x":0.5, "center_y":0.5}
            
    MDLabel:
        text: root.text
        font_style: "Label"
        role: "medium"
        bold: True
        color: "#ffffff"

#####################################
<CustomFlatButton>:
    background_normal: ''
    background_down: ''
    background_color: [0,0,0,0]
    padding: ["10dp", 0]
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos[0] -2, self.pos[1] -2
            size: self.size
            radius: [5,5,5,5]
        Color:
            rgba: [0, 0.588, 0.78, 1]
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [5,5,5,5]
            
    MDLabel:
        text: root.text
        font_style: "Label"
        role: "medium"
        bold: True
        halign: "center"
        color: "#ffffff"

#####################################
<CustomCancelButton>:
    background_normal: ''
    background_down: ''
    background_color: [0,0,0,0]
    size_hint_y: None
    height: "30dp"
    padding: ["10dp", 0]
    canvas.before:
        Color:
            rgba: rgba("#ff0000")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [5,5,5,5]
            
    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIcon:
            icon: root.icon
            theme_text_color: "Custom"
            text_color: "#ffffff"
            pos_hint: {"center_x":0.1, "center_y":0.5}
            
    MDLabel:
        text: root.text
        font_style: "Label"
        role: "medium"
        bold: True
        color: "#ffffff"

#####################################

<CustomDropDown>:
    id: supplier
    MDIcon:
        id: icon
        icon: "chevron-down"
        theme_text_color: "Custom"
        text_color: "#8D8A8C"
        pos_hint: {"center_x":0.1, "center_y":0.5}

    Spinner:
        id: spinner
        text: root.text
        values: root.values
        font_size: "11sp"
        sync_width: True
        sync_height: True
        color: "#8D8A8C"
        option_cls: Factory.sp
        background_color: [0,0,0,0]
        background_normal: ''
        background_down: ''
        pos_hint: {"center_x":0.5, "center_y":0.5}
        
        
  

"""
)
class NavigationTab(ToggleButtonBehavior, BoxLayout):
    icon = StringProperty()
    text = StringProperty()

class NavigationTabHoz(ToggleButtonBehavior, BoxLayout):
    icon = StringProperty()
    text = StringProperty()

class CustomButton(ButtonBehavior, BoxLayout):
    icon = StringProperty()
    text = StringProperty()

class CustomFlatButton(ButtonBehavior, BoxLayout):
    text = StringProperty()

class CustomCancelButton(ButtonBehavior, BoxLayout):
    icon = StringProperty()
    text = StringProperty()

class CustomDropDown(FloatLayout):
    text = StringProperty()
    values = ListProperty()
