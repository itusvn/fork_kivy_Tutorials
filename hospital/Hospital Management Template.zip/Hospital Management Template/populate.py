import mysql.connector
from datetime import datetime

host = "localhost"
user = "root"
passwd = ""
db = "xyz"

def connection():
    return mysql.connector.connect(host=host, user=user, password=passwd, database=db)

def insert_dummy_data():
    conn = None
    try:
        conn = connection()
        cur = conn.cursor()

        # Insert into users
        cur.execute("""
            INSERT INTO users (name, email, phone, role, password)
            VALUES 
            ('Admin User', 'admin@hospital.com', '1234567890', 'admin', 'adminpass'),
            ('Dr. Alice Smith', 'alice@hospital.com', '1112223333', 'doctor', 'alicepass'),
            ('Nurse Bob', 'bob@hospital.com', '4445556666', 'nurse', 'bobpass');
        """)

        # Insert into staff
        cur.execute("""
            INSERT INTO staff (user_id, name, position, department, phone, email, address)
            VALUES 
            (1, 'Dr. Alice Smith', 'Doctor', 'Cardiology', '1112223333', 'alice@hospital.com', '123 Heart Street'),
            (1, 'Bob Johnson', 'Nurse', 'ICU', '4445556666', 'bob@hospital.com', '456 Care Lane');
        """)

        # Insert into patients
        cur.execute("""
            INSERT INTO patients (user_id, name, dob, gender, phone, email, address, blood_type, medical_history)
            VALUES 
            ('1', 'John Doe', '1980-05-20', 'Male', '9998887777', 'johndoe@example.com', '789 Patient Ave', 'A+', 'Diabetes'),
            ('1', 'Jane Roe', '1990-10-10', 'Female', '6665554444', 'janeroe@example.com', '321 Health Blvd', 'B+', 'Asthma');
        """)

        # Insert into appointments
        cur.execute("""
            INSERT INTO appointments (user_id, patient_id, staff_id, date, time, reason, status)
            VALUES 
            ('1', 1, 1, '2025-05-14', '10:30:00', 'Routine Checkup', 'Scheduled'),
            ('1', 2, 1, '2025-05-15', '14:00:00', 'Follow-up', 'Scheduled');
        """)

        # Insert into rooms
        cur.execute("""
            INSERT INTO rooms (user_id, room_number, type, capacity, status, notes)
            VALUES 
            ('1', '101', 'ICU', 1, 'Occupied', 'Ventilator available'),
            ('1', '102', 'General', 2, 'Available', 'Shared room');
        """)

        # Insert into beds
        cur.execute("""
            INSERT INTO beds (user_id, room_id, bed_number, status, patient_id)
            VALUES 
            ('1', 1, '1A', 'Occupied', 1),
            ('1', 2, '2A', 'Available', NULL),
            ('1', 2, '2B', 'Occupied', 2);
        """)

        # Insert into sales
        cur.execute("""
            INSERT INTO sales (user_id, patient_id, date, item, amount, method, notes)
            VALUES 
            ('1', 1, '2025-05-10', 'Consultation Fee', 150.00, 'Cash', 'Initial visit'),
            ('1', 2, '2025-05-11', 'Medication', 200.50, 'Card', 'Asthma inhaler');
        """)

        conn.commit()
        cur.close()
        print("Dummy data inserted successfully!")

    except Exception as error:
        print(f"Error: {error}")
    finally:
        if conn is not None:
            conn.close()

if __name__ == "__main__":
    insert_dummy_data()
