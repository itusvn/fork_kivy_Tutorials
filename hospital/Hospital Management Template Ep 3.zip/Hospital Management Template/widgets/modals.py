import json

from kivy.clock import Clock
from kivy.uix.modalview import ModalView
from kivy.lang import Builder
from kivymd.uix.filemanager import MDFileManager
from kivy.properties import StringProperty, ObjectProperty, NumericProperty
from kivymd.uix.pickers import MDModalDatePicker, MDTimePickerDialVertical

from data.connection import connection
from widgets.popups import WarningPopUp

Builder.load_string("""
<CreatePatientModal>:
    background: ""
    background_color: [0,0,0,0]
    
    AnchorLayout:
        anchor_x: "right"
        anchor_y: "center"
        
        BoxLayout:
            size_hint_x: 2/5
            padding: "40dp"
            
            BoxLayout:
                orientation: "vertical"
                padding: "10dp"
                spacing: "40dp"
                canvas.before:
                    Color:
                        rgba: rgba("#ffffff")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [5,5,5,5]
                        
                BoxLayout:
                    size_hint_y: None
                    height: "40dp"
                    spacing: "10dp"
                    
                    MDLabel:
                        id: modal_title
                        text: "Add patient"
                        font_style: "Label"
                        role: "medium"
                        bold: True
                        
                    FloatLayout:
                        size_hint_x: None
                        width: self.height
                        
                        MDIconButton:
                            icon: "close"
                            theme_text_color: "Custom"
                            text_color: "#8d8a8c"
                            on_press: root.dismiss()
                            pos_hint: {"center_x": 0.5, "center_y": 0.5}
                            
                BoxLayout:
                    orientation: "vertical"
                    spacing: "10dp"

                    CustomTextField:
                        id: name
                        label: "Name"
                        hint_text: "Patient's name..."

                    BoxLayout:
                        size_hint_y: None
                        height: "35dp"
                        padding: "1dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#e9e9e9")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]

                        BoxLayout:
                            padding: ["10dp", "2.5dp"]
                            canvas.before:
                                Color:
                                    rgba: rgba("#f7f7f7")
                                RoundedRectangle:
                                    pos: self.pos
                                    size: self.size
                                    radius: [5,5,5,5]

                            MDLabel:
                                size_hint_x: None
                                width: "70dp"
                                text: "D.O.B"
                                font_style: "Label"
                                role: "medium"
                                bold: True
                                
                            MDLabel:
                                id: dob
                                font_style: "Label"
                                role: "medium"
                        
                            FloatLayout:
                                size_hint_x: None
                                width: self.height
                                
                                MDIconButton:
                                    icon: "calendar"
                                    theme_text_color: "Custom"
                                    text_color: "#8d8a8c"
                                    on_press: root.open_date_picker()
                                    pos_hint: {"center_x": 0.5, "center_y": 0.5}

                    BoxLayout:
                        size_hint_y: None
                        height: "35dp"
                        padding: "1dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#e9e9e9")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]

                        BoxLayout:
                            padding: ["10dp", "2.5dp"]
                            canvas.before:
                                Color:
                                    rgba: rgba("#f7f7f7")
                                RoundedRectangle:
                                    pos: self.pos
                                    size: self.size
                                    radius: [5,5,5,5]

                            MDLabel:
                                size_hint_x: None
                                width: "70dp"
                                text: "Gender"
                                font_style: "Label"
                                role: "medium"
                                bold: True

                            Spinner:
                                id: gender
                                text: "Select patient's gender..."
                                values: ["Male", "Female"]
                                font_size: "11sp"
                                sync_width: True
                                sync_height: True
                                color: "#8D8A8C"
                                option_cls: Factory.sp
                                background_color: [0,0,0,0]
                                background_normal: ''
                                background_down: ''
                                pos_hint: {"center_x":0.5, "center_y":0.5}

                    CustomTextField:
                        id: phone
                        label: "Phone"
                        hint_text: "Patient's phone number..."

                    CustomTextField:
                        id: email
                        label: "Email"
                        hint_text: "Patient's email address..."

                    CustomTextFieldLarge:
                        size_hint_y: None
                        height: "70dp"
                        id: address
                        label: "Address"
                        hint_text: "Patient's physical address..."

                    BoxLayout:
                        size_hint_y: None
                        height: "35dp"
                        padding: "1dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#e9e9e9")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]

                        BoxLayout:
                            padding: ["10dp", "2.5dp"]
                            canvas.before:
                                Color:
                                    rgba: rgba("#f7f7f7")
                                RoundedRectangle:
                                    pos: self.pos
                                    size: self.size
                                    radius: [5,5,5,5]

                            MDLabel:
                                size_hint_x: None
                                width: "60dp"
                                text: "Blood type"
                                font_style: "Label"
                                role: "medium"
                                bold: True

                            Spinner:
                                id: blood_type
                                text: "Select patient's blood type..."
                                values: ["A+", "A-","B+", "B-", "AB+", "AB-", "O+", "O-"]
                                font_size: "11sp"
                                sync_width: True
                                sync_height: True
                                color: "#8D8A8C"
                                option_cls: Factory.sp
                                background_color: [0,0,0,0]
                                background_normal: ''
                                background_down: ''
                                pos_hint: {"center_x":0.5, "center_y":0.5}

                    CustomTextFieldLarge:
                        size_hint_y: None
                        height: "70dp"
                        id: medical_history
                        label: "Medical history"
                        hint_text: "Patient's medical history..."

                    MDLabel:
                        id: error
                        size_hint_y: None
                        height: "25dp"
                        font_style: "Label"
                        role: "small"
                        halign: "center"
                        color: "red"
                            
                    CustomFlatButton:
                        id: modal_button
                        size_hint_y: None
                        height: "40dp"
                        text: "Add"
                        on_press: root.callback(root)
                        
                    BoxLayout:
                    
##############################################################
<AppointmentsModal>:
    background: ""
    background_color: [0,0,0,0]
    
    AnchorLayout:
        anchor_x: "right"
        anchor_y: "center"
        
        BoxLayout:
            size_hint_x: 2/5
            padding: "40dp"
            
            BoxLayout:
                orientation: "vertical"
                padding: "10dp"
                spacing: "40dp"
                canvas.before:
                    Color:
                        rgba: rgba("#ffffff")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [5,5,5,5]
                        
                BoxLayout:
                    size_hint_y: None
                    height: "40dp"
                    spacing: "10dp"
                    
                    MDLabel:
                        id: modal_title
                        text: "Add appointment"
                        font_style: "Label"
                        role: "medium"
                        bold: True
                        
                    FloatLayout:
                        size_hint_x: None
                        width: self.height
                        
                        MDIconButton:
                            icon: "close"
                            theme_text_color: "Custom"
                            text_color: "#8d8a8c"
                            on_press: root.dismiss()
                            pos_hint: {"center_x": 0.5, "center_y": 0.5}
                            
                BoxLayout:
                    orientation: "vertical"
                    spacing: "10dp"



                    BoxLayout:
                        size_hint_y: None
                        height: "35dp"
                        padding: "1dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#e9e9e9")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]

                        BoxLayout:
                            padding: ["10dp", "2.5dp"]
                            canvas.before:
                                Color:
                                    rgba: rgba("#f7f7f7")
                                RoundedRectangle:
                                    pos: self.pos
                                    size: self.size
                                    radius: [5,5,5,5]

                            MDLabel:
                                size_hint_x: None
                                width: "60dp"
                                text: "Type"
                                font_style: "Label"
                                role: "medium"
                                bold: True

                            Spinner:
                                id: patient
                                text: "Select patient..."
                                font_size: "11sp"
                                sync_width: True
                                sync_height: True
                                color: "#8D8A8C"
                                option_cls: Factory.sp
                                background_color: [0,0,0,0]
                                background_normal: ''
                                background_down: ''
                                pos_hint: {"center_x":0.5, "center_y":0.5}
                                
                    BoxLayout:
                        size_hint_y: None
                        height: "35dp"
                        padding: "1dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#e9e9e9")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]

                        BoxLayout:
                            padding: ["10dp", "2.5dp"]
                            canvas.before:
                                Color:
                                    rgba: rgba("#f7f7f7")
                                RoundedRectangle:
                                    pos: self.pos
                                    size: self.size
                                    radius: [5,5,5,5]

                            MDLabel:
                                size_hint_x: None
                                width: "60dp"
                                text: "Doctor"
                                font_style: "Label"
                                role: "medium"
                                bold: True

                            Spinner:
                                id: doctor
                                text: "Select consulting doctor..."
                                font_size: "11sp"
                                sync_width: True
                                sync_height: True
                                color: "#8D8A8C"
                                option_cls: Factory.sp
                                background_color: [0,0,0,0]
                                background_normal: ''
                                background_down: ''
                                pos_hint: {"center_x":0.5, "center_y":0.5}

                    BoxLayout:
                        size_hint_y: None
                        height: "35dp"
                        padding: "1dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#e9e9e9")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]

                        BoxLayout:
                            padding: ["10dp", "2.5dp"]
                            canvas.before:
                                Color:
                                    rgba: rgba("#f7f7f7")
                                RoundedRectangle:
                                    pos: self.pos
                                    size: self.size
                                    radius: [5,5,5,5]

                            MDLabel:
                                size_hint_x: None
                                width: "70dp"
                                text: "Date"
                                font_style: "Label"
                                role: "medium"
                                bold: True
                                
                            MDLabel:
                                id: date
                                font_style: "Label"
                                role: "medium"
                        
                            FloatLayout:
                                size_hint_x: None
                                width: self.height
                                
                                MDIconButton:
                                    icon: "calendar"
                                    theme_text_color: "Custom"
                                    text_color: "#8d8a8c"
                                    on_press: root.open_date_picker()
                                    pos_hint: {"center_x": 0.5, "center_y": 0.5}

                    BoxLayout:
                        size_hint_y: None
                        height: "35dp"
                        padding: "1dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#e9e9e9")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]

                        BoxLayout:
                            padding: ["10dp", "2.5dp"]
                            canvas.before:
                                Color:
                                    rgba: rgba("#f7f7f7")
                                RoundedRectangle:
                                    pos: self.pos
                                    size: self.size
                                    radius: [5,5,5,5]

                            MDLabel:
                                size_hint_x: None
                                width: "70dp"
                                text: "Time"
                                font_style: "Label"
                                role: "medium"
                                bold: True
                                
                            MDLabel:
                                id: time
                                font_style: "Label"
                                role: "medium"
                        
                            FloatLayout:
                                size_hint_x: None
                                width: self.height
                                
                                MDIconButton:
                                    icon: "clock"
                                    theme_text_color: "Custom"
                                    text_color: "#8d8a8c"
                                    on_press: root.open_time_picker()
                                    pos_hint: {"center_x": 0.5, "center_y": 0.5}

                    CustomTextFieldLarge:
                        id: reason
                        label: "Reason"
                        hint_text: "Previous medical history..."

                    BoxLayout:
                        size_hint_y: None
                        height: "35dp"
                        padding: "1dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#e9e9e9")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]

                        BoxLayout:
                            padding: ["10dp", "2.5dp"]
                            canvas.before:
                                Color:
                                    rgba: rgba("#f7f7f7")
                                RoundedRectangle:
                                    pos: self.pos
                                    size: self.size
                                    radius: [5,5,5,5]

                            MDLabel:
                                size_hint_x: None
                                width: "60dp"
                                text: "Status"
                                font_style: "Label"
                                role: "medium"
                                bold: True

                            Spinner:
                                id: status
                                text: "Select appointment status..."
                                values: ["Scheduled", "Completed"]
                                font_size: "11sp"
                                sync_width: True
                                sync_height: True
                                color: "#8D8A8C"
                                option_cls: Factory.sp
                                background_color: [0,0,0,0]
                                background_normal: ''
                                background_down: ''
                                pos_hint: {"center_x":0.5, "center_y":0.5}
                                

                    MDLabel:
                        id: error
                        size_hint_y: None
                        height: "25dp"
                        font_style: "Label"
                        role: "small"
                        halign: "center"
                        color: "red"
                            
                    CustomFlatButton:
                        id: modal_button
                        size_hint_y: None
                        height: "40dp"
                        text: "Add"
                        on_press: root.callback(root)
                        
                    BoxLayout:
                
""")

class CreatePatientModal(ModalView):
    id = StringProperty()
    name = StringProperty()
    dob = StringProperty()
    gender = StringProperty()
    phone = StringProperty()
    email = StringProperty()
    address = StringProperty()
    blood_type = StringProperty()
    medical_history = StringProperty()
    close = StringProperty()
    callback = ObjectProperty(allownone=True)

    def open_date_picker(self):
        date_picker = MDModalDatePicker()
        date_picker.bind(on_ok = self.on_date_ok)
        date_picker.bind(on_cancel = self.on_date_cancel)
        date_picker.open()

    def on_date_ok(self, instance_date_picker):
        self.ids.dob.text = str(instance_date_picker.get_date()[0])
        instance_date_picker.dismiss()

    def on_date_cancel(self, instance_date_picker):
        instance_date_picker.dismiss()

    def on_name(self, instance, name):
        self.ids.name.ids.text_input.text = name
        self.ids.modal_title.text = "Update patient"
        self.ids.modal_button.text = "Update"

    def on_dob(self, instance, dob):
        self.ids.dob.text = dob

    def on_gender(self, instance, gender):
        self.ids.gender.text = gender

    def on_phone(self, instance, phone):
        self.ids.phone.ids.text_input.text = phone

    def on_email(self, instance, email):
        self.ids.email.ids.text_input.text = email

    def on_address(self, instance, address):
        self.ids.address.ids.text_input.text = address

    def on_blood_type(self, instance, blood_type):
        self.ids.blood_type.text = blood_type

    def on_medical_history(self, instance, medical_history):
        self.ids.medical_history.ids.text_input.text = medical_history

    def on_close(self, instance, close):
        self.dismiss()

###################################################################

class AppointmentsModal(ModalView):
    user_id = NumericProperty()
    id = StringProperty()
    patient_id = StringProperty()
    staff_id = StringProperty()
    patient = StringProperty()
    doctor = StringProperty()
    date = StringProperty()
    time = StringProperty()
    reason = StringProperty()
    status = StringProperty()
    close = StringProperty()
    callback = ObjectProperty(allownone=True)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        Clock.schedule_once(self.get_user_id, .1)
        Clock.schedule_once(self.get_patients, .1)

    def get_user_id(self, td):
        try:
            SESSION_FILE = "session.json"
            with open(SESSION_FILE, "r") as file:
                session = json.load(file)
                self.user_id = session.get("user_id")
        except FileNotFoundError:
            return None

    def get_patients(self, td):
        conn = connection()
        cursor = conn.cursor()
        try:

            sql = "SELECT * FROM patients WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            patients_list = cursor.fetchall()
            list_of_patients = []
            for x in patients_list:
                list_of_patients.append(str(x[0]) + " | " + x[2])

            self.ids.patient.values = list_of_patients

            sql = "SELECT * FROM staff WHERE user_id = %s AND position = %s"
            values = [str(self.user_id), "Doctor"]
            cursor.execute(sql, values)
            doctors_list = cursor.fetchall()
            list_of_doctors = []
            for x in doctors_list:
                list_of_doctors.append(str(x[0]) + " | " + x[2])

            self.ids.doctor.values = list_of_doctors

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def open_date_picker(self):
        date_picker = MDModalDatePicker()
        date_picker.bind(on_ok = self.on_date_ok)
        date_picker.bind(on_cancel = self.on_date_cancel)
        date_picker.open()

    def on_date_ok(self, instance_date_picker):
        self.ids.date.text = str(instance_date_picker.get_date()[0])
        instance_date_picker.dismiss()

    def on_date_cancel(self, instance_date_picker):
        instance_date_picker.dismiss()

    def open_time_picker(self):
        time_picker = MDTimePickerDialVertical()
        time_picker.bind(on_ok = self.on_time_ok)
        time_picker.bind(on_cancel = self.on_time_cancel)
        time_picker.open()

    def on_time_ok(self, instance_time_picker):
        self.ids.time.text = str(instance_time_picker.time)
        instance_time_picker.dismiss()

    def on_time_cancel(self, instance_time_picker):
        instance_time_picker.dismiss()

    def on_patient(self, instance, patient):
        self.ids.patient.text = self.patient_id + " | " + patient
        self.ids.modal_title.text = "Update appointment"
        self.ids.modal_button.text = "Update"

    def on_doctor(self, instance, doctor):
        self.ids.doctor.text = self.staff_id + " | " + doctor

    def on_date(self, instance, date):
        self.ids.date.text = date

    def on_time(self, instance, time):
        self.ids.time.text = time

    def on_reason(self, instance, reason):
        self.ids.reason.ids.text_input.text = reason

    def on_status(self, instance, status):
        self.ids.status.text = status

    def on_close(self, instance, close):
        self.dismiss()
