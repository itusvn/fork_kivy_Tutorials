import cv2
from kivy.clock import Clock
from kivy.core.image import Texture
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.image import Image
from kivy.uix.modalview import ModalView
from kivy.properties import ObjectProperty, StringProperty, ListProperty
from kivy.lang import Builder

Builder.load_string("""

<ImageDetection>:
    background: ""
    background_color: [0,0,0,0.1]
    
    AnchorLayout:
        anchor_x: "center"
        anchor_y: "center"
        
        FloatLayout:
            size_hint: 4/5, 4/5
            canvas.before:
                Color:
                    rgba: rgba("#ffffff")
                Rectangle:
                    pos: self.pos
                    size: self.size
                    
            BoxLayout:
                id: scanned_image
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
            FloatLayout:
                size_hint: None, None
                size: "40dp", "40dp"
                pos_hint: {"center_x": 0.95, "center_y": 0.95}
                canvas.before:
                    Color:
                        rgba: [1,1,1,0.35]
                    Rectangle:
                        pos: self.pos
                        size: self.size
                        
                MDIconButton:
                    icon: "close"
                    theme_text_color: "Custom"
                    text_color: "#ffffff"
                    pos_hint: {"center_x": 0.5, "center_y": 0.5}
                    on_press: root.dismiss()

""")


class ImageDetection(ModalView):
    image_source = StringProperty()

    def on_open(self):
        Clock.schedule_once(self.display_image, 0.5)

    def display_image(self, *args):
        if not self.image_source:
            print("No image source provided.")
            return

        img = cv2.imread(self.image_source)

        if img is None:
            print(f"Failed to load image: {self.image_source}")

        gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        cascade = cv2.CascadeClassifier("assets/myhaar.xml")
        detections = cascade.detectMultiScale(gray_img, 1.1, 5, minSize=(30,30))

        for (x, y, w, h) in detections:
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)

        texture = Texture.create(size=(img.shape[1], img.shape[0]), colorfmt="bgr")
        texture.blit_buffer(img.flatten(), colorfmt="bgr", bufferfmt="ubyte")
        texture.flip_vertical()

        img_widget = Image(texture=texture, size_hint=(1,1), fit_mode="fill")
        self.ids.scanned_image.clear_widgets()
        self.ids.scanned_image.add_widget(img_widget)






















