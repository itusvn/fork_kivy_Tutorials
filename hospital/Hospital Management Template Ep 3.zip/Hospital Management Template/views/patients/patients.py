import json

from kivy.clock import Clock
from kivy.properties import NumericProperty, ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from data.connection import connection
from widgets.modals import CreatePatientModal
from widgets.popups import WarningPopUp, ConfirmPopUp
from widgets.tables import PatientsTab

Builder.load_file('views/patients/patients.kv')

class Patients(Screen):
    user_id = NumericProperty()

    total_patients = NumericProperty()

    patients_in_db = ListProperty()
    def on_enter(self, *args):
        self.updateAppointment = None
        self.addPatient = []
        self.updatePatient = []
        self.deletePatient = None
        Clock.schedule_once(self.run_essentials, 0.1)

    def run_essentials(self, dt):
        self.get_user_id()
        self.fill_cards()
        self.show_patients_in_db()

    def get_user_id(self):
        try:
            SESSION_FILE = "session.json"
            with open(SESSION_FILE, "r") as file:
                session = json.load(file)
                self.user_id = session.get("user_id")
        except FileNotFoundError:
            return None

    def fill_cards(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            #Total Appointments
            sql = "SELECT COUNT(*) FROM appointments WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            total_patients = cursor.fetchone()[0]
            self.total_patients = total_patients

            #Total Scheduled Appointments
            sql = "SELECT COUNT(*) FROM appointments WHERE user_id = %s AND status = %s"
            values = [str(self.user_id), "Scheduled"]
            cursor.execute(sql, values)
            appointments = cursor.fetchone()[0]
            self.appointments = appointments

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def show_patients_in_db(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            self.patients_in_db = []
            sql = "SELECT * FROM patients WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            patients_in_db = cursor.fetchall()
            for x in patients_in_db:
                data = {
                    "id": x[0],
                    "name": x[2],
                    "dob": x[3],
                    "gender": x[4],
                    "phone": x[5],
                    "email": x[6],
                    "address": x[7],
                    "blood_type": x[8],
                    "medical_history": x[9]
                }

                self.patients_in_db.append(data)

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def on_patients_in_db(self, instance, patients_in_db):
        table = self.ids.patients_in_db_list
        table.clear_widgets()
        for x in patients_in_db:
            tableRow = PatientsTab()
            tableRow.id = str(x["id"])
            tableRow.name = str(x["name"])
            tableRow.dob = str(x["dob"])
            tableRow.gender = str(x["gender"])
            tableRow.phone = str(x["phone"])
            tableRow.email = str(x["email"])
            tableRow.address = str(x["address"])
            tableRow.blood_type = str(x["blood_type"])
            tableRow.medical_history = str(x["medical_history"])
            tableRow.update_callback = self.open_update_modal
            tableRow.delete_callback = self.delete_patient
            table.add_widget(tableRow)

#########################################################################
    def open_add_modal(self):
        add_modal = CreatePatientModal()
        add_modal.callback = self.add_patient
        add_modal.open()

#########################################################################
    def open_update_modal(self, instance):
        update_modal = CreatePatientModal()
        update_modal.id =instance.id
        update_modal.name =instance.name
        update_modal.dob = instance.dob
        update_modal.gender = instance.gender
        update_modal.phone = instance.phone
        update_modal.email = instance.email
        update_modal.address = instance.address
        update_modal.blood_type = instance.blood_type
        update_modal.medical_history = instance.medical_history
        update_modal.callback = self.update_patient
        update_modal.open()


#########################################################################

    def add_patient(self, instance):
        name =instance.ids.name.ids.text_input.text
        dob = instance.ids.dob.text
        gender = instance.ids.gender.text
        phone = instance.ids.phone.ids.text_input.text
        email = instance.ids.email.ids.text_input.text
        address = instance.ids.address.ids.text_input.text
        blood_type = instance.ids.blood_type.text
        medical_history = instance.ids.medical_history.ids.text_input.text

        if name == "" or dob == "" or gender == "Select patient's gender..." or phone == "" or email == "" or address == "" or blood_type == "Select patient's blood type":
            instance.ids.error.text = "Fill in the required fields!"
            instance.ids.error.color = "red"

        else:
            instance.close = "close"
            self.addPatient = [name, dob, gender, phone, email, address, blood_type, medical_history]
            add_patient = ConfirmPopUp()
            add_patient.title = "Add patient?"
            add_patient.callback = self.add_patient_callback
            add_patient.open()

    def add_patient_callback(self, *args):
        name = self.addPatient[0]
        dob = self.addPatient[1]
        gender = self.addPatient[2]
        phone = self.addPatient[3]
        email = self.addPatient[4]
        address = self.addPatient[5]
        blood_type = self.addPatient[6]
        medical_history = self.addPatient[7]

        conn = connection()
        cursor = conn.cursor()
        try:
            sql = """
                INSERT INTO patients (user_id, name, dob, gender, phone, email, address, blood_type, medical_history)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
            values = [self.user_id, name, dob, gender, phone, email, address, blood_type, medical_history]
            cursor.execute(sql, values)
            conn.commit()
            self.show_patients_in_db()

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()
#########################################################################

    def update_patient(self, instance):
        id = instance.id
        name =instance.ids.name.ids.text_input.text
        dob = instance.ids.dob.text
        gender = instance.ids.gender.text
        phone = instance.ids.phone.ids.text_input.text
        email = instance.ids.email.ids.text_input.text
        address = instance.ids.address.ids.text_input.text
        blood_type = instance.ids.blood_type.text
        medical_history = instance.ids.medical_history.ids.text_input.text

        if name == "" or dob == "" or gender == "Select patient's gender..." or phone == "" or email == "" or address == "" or blood_type == "Select patient's blood type":
            instance.ids.error.text = "Fill in the required fields!"
            instance.ids.error.color = "red"

        else:
            instance.close = "close"
            self.updatePatient = [id, name, dob, gender, phone, email, address, blood_type, medical_history]
            update_patient = ConfirmPopUp()
            update_patient.title = "Update patient?"
            update_patient.callback = self.update_patient_callback
            update_patient.open()

    def update_patient_callback(self, *args):
        id = self.updatePatient[0]
        name = self.updatePatient[1]
        dob = self.updatePatient[2]
        gender = self.updatePatient[3]
        phone = self.updatePatient[4]
        email = self.updatePatient[5]
        address = self.updatePatient[6]
        blood_type = self.updatePatient[7]
        medical_history = self.updatePatient[8]

        conn = connection()
        cursor = conn.cursor()
        try:
            sql = "UPDATE patients SET name = %s, dob = %s, gender = %s, phone = %s, email = %s, address = %s, blood_type = %s, medical_history =%s WHERE id =%s"
            values = [name, dob, gender, phone, email, address, blood_type, medical_history, id]
            cursor.execute(sql, values)
            conn.commit()
            self.show_patients_in_db()

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()




#########################################################################
#########################################################################
#########################################################################
#########################################################################
#########################################################################
#########################################################################
#########################################################################

    def delete_patient(self, instance):
        self.deletePatient = instance.id
        delete_patient = ConfirmPopUp()
        delete_patient.title = "Are you sure you want to delete this patient?"
        delete_patient.callback = self.delete_patient_callback
        delete_patient.open()

    def delete_patient_callback(self, *args):
        id = self.deletePatient
        conn = connection()
        cursor = conn.cursor()
        try:
            sql = "DELETE FROM patients WHERE id = %s"
            values = [id]
            cursor.execute(sql, values)
            conn.commit()
            self.show_patients_in_db()

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()











