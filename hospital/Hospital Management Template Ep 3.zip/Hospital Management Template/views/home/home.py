import json

from kivy.clock import Clock
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivy.properties import StringProperty

from widgets.popups import ConfirmPopUp

Builder.load_file('views/home/home.kv')
class Home(Screen):
    user = StringProperty()
    user_type = StringProperty("Admin")
    avatar = "assets/images/avatar.png"
    def on_enter(self, *args):
        Clock.schedule_once(self.run_essentials, 0.1)

    def run_essentials(self, dt):
        self.get_user_id()

    def get_user_id(self):
        try:
            SESSION_FILE = "session.json"
            with open(SESSION_FILE, "r") as file:
                session = json.load(file)
                self.user = session.get("username")
        except FileNotFoundError:
            return None

    def logout(self):
        logout = ConfirmPopUp()
        logout.title = "Are you sure you want to logout?"
        logout.callback = self.logout_callback
        logout.open()

    def logout_callback(self, *args):
        print("Logging out!")