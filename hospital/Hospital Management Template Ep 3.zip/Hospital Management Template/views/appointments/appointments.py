import json

from kivy.clock import Clock
from kivy.properties import NumericProperty, ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from data.connection import connection
from widgets.modals import AppointmentsModal
from widgets.popups import WarningPopUp, ConfirmPopUp
from widgets.tables import AppointmentsTab

Builder.load_file('views/appointments/appointments.kv')

class Appointments(Screen):
    user_id = NumericProperty()

    total_appointments = NumericProperty()
    appointments = NumericProperty()

    appointments_in_db = ListProperty()
    def on_enter(self, *args):
        self.addAppointment = []
        self.updateAppointment = []
        self.deleteAppointment = None
        Clock.schedule_once(self.run_essentials, 0.1)

    def run_essentials(self, dt):
        self.get_user_id()
        self.fill_cards()
        self.show_appointments_in_db()

    def get_user_id(self):
        try:
            SESSION_FILE = "session.json"
            with open(SESSION_FILE, "r") as file:
                session = json.load(file)
                self.user_id = session.get("user_id")
        except FileNotFoundError:
            return None

    def fill_cards(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            #Total Appointments
            sql = "SELECT COUNT(*) FROM appointments WHERE user_id = %s"
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            total_appointments = cursor.fetchone()[0]
            self.total_appointments = total_appointments

            #Total Scheduled Appointments
            sql = "SELECT COUNT(*) FROM appointments WHERE user_id = %s AND status = %s"
            values = [str(self.user_id), "Scheduled"]
            cursor.execute(sql, values)
            appointments = cursor.fetchone()[0]
            self.appointments = appointments

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def show_appointments_in_db(self):
        conn = connection()
        cursor = conn.cursor()
        try:
            self.appointments_in_db = []
            sql = """
                SELECT
                    a.id,
                    a.user_id,
                    a.patient_id,
                    a.staff_id,
                    a.date,
                    a.time,
                    a.reason,
                    a.status,
                    p.name AS patient_name,
                    s.name AS doctor_name
                FROM appointments a
                JOIN patients p ON a.patient_id = p.id AND p.user_id = a.user_id
                JOIN staff s ON a.staff_id = s.id AND s.user_id = a.user_id
                WHERE a.user_id = %s;
            """
            values = [str(self.user_id)]
            cursor.execute(sql, values)
            appointments_in_db = cursor.fetchall()
            print(appointments_in_db)
            for x in appointments_in_db:
                data = {
                    "id": x[0],
                    "patient_id": x[2],
                    "staff_id": x[3],
                    "patient": x[8],
                    "doctor": x[9],
                    "date": x[4],
                    "time": x[5],
                    "reason": x[6],
                    "status": x[7]
                }

                self.appointments_in_db.append(data)

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()

    def on_appointments_in_db(self, instance, appointments_in_db):
        table = self.ids.appointments_in_db_list
        table.clear_widgets()
        for x in appointments_in_db:
            tableRow = AppointmentsTab()
            tableRow.id = str(x["id"])
            tableRow.patient_id = str(x["patient_id"])
            tableRow.staff_id = str(x["staff_id"])
            tableRow.patient = str(x["patient"])
            tableRow.doctor = str(x["doctor"])
            tableRow.date = str(x["date"])
            tableRow.time = str(x["time"])
            tableRow.reason = str(x["reason"])
            tableRow.status = str(x["status"])
            tableRow.update_callback = self.open_update_modal
            tableRow.delete_callback = self.delete_appointment
            table.add_widget(tableRow)

#########################################################################
    def open_add_modal(self):
        add_modal = AppointmentsModal()
        add_modal.callback = self.add_appointment
        add_modal.open()

#########################################################################
    def open_update_modal(self, instance):
        update_modal = AppointmentsModal()
        update_modal.id =instance.id
        update_modal.patient_id =instance.patient_id
        update_modal.staff_id =instance.staff_id
        update_modal.patient =instance.patient
        update_modal.doctor = instance.doctor
        update_modal.date = instance.date
        update_modal.time = instance.time
        update_modal.reason = instance.reason
        update_modal.status = instance.status
        update_modal.callback = self.update_appointment
        update_modal.open()


#########################################################################

    def add_appointment(self, instance):
        patient =instance.ids.patient.text
        doctor = instance.ids.doctor.text
        date = instance.ids.date.text
        time = instance.ids.time.text
        reason = instance.ids.reason.ids.text_input.text
        status = instance.ids.status.text

        if patient == "Select patient..." or doctor == "Select consulting doctor..." or date == "" or time == "" or reason == "" or status == "Select appointment status...":
            instance.ids.error.text = "Fill in the required fields!"
            instance.ids.error.color = "red"

        else:
            instance.close = "close"
            patient_id = patient[:patient.find(" | ")]
            doctor_id = doctor[:doctor.find(" | ")]
            self.addAppointment = [patient_id, doctor_id, date, time, reason, status]
            add_appointment = ConfirmPopUp()
            add_appointment.title = "Add appointment?"
            add_appointment.callback = self.add_appointment_callback
            add_appointment.open()

    def add_appointment_callback(self, *args):
        patient = self.addAppointment[0]
        doctor = self.addAppointment[1]
        date = self.addAppointment[2]
        time = self.addAppointment[3]
        reason = self.addAppointment[4]
        status = self.addAppointment[5]

        conn = connection()
        cursor = conn.cursor()
        try:
            sql = """
                INSERT INTO appointments (user_id, patient_id, staff_id, date, time, reason, status)
                VALUES (%s,%s,%s,%s,%s,%s,%s)
            """
            values = [self.user_id, patient, doctor, date, time, reason, status]
            cursor.execute(sql, values)
            conn.commit()
            self.show_appointments_in_db()

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()
#########################################################################

    def update_appointment(self, instance):
        id = instance.id
        patient = instance.ids.patient.text
        doctor = instance.ids.doctor.text
        date = instance.ids.date.text
        time = instance.ids.time.text
        reason = instance.ids.reason.ids.text_input.text
        status = instance.ids.status.text

        if patient == "Select patient..." or doctor == "Select consulting doctor..." or date == "" or time == "" or reason == "" or status == "Select appointment status...":
            instance.ids.error.text = "Fill in the required fields!"
            instance.ids.error.color = "red"

        else:
            instance.close = "close"
            patient_id = patient[:patient.find(" | ")]
            doctor_id = doctor[:doctor.find(" | ")]
            self.updateAppointment = [id, patient_id, doctor_id, date, time, reason, status]
            update_appointment = ConfirmPopUp()
            update_appointment.title = "Update appointment?"
            update_appointment.callback = self.update_appointment_callback
            update_appointment.open()

    def update_appointment_callback(self, *args):
        id = self.updateAppointment[0]
        patient = self.updateAppointment[1]
        doctor = self.updateAppointment[2]
        date = self.updateAppointment[3]
        time = self.updateAppointment[4]
        reason = self.updateAppointment[5]
        status = self.updateAppointment[6]

        conn = connection()
        cursor = conn.cursor()
        try:
            sql = """
                    UPDATE appointments SET patient_id=%s, staff_id=%s, date=%s, time=%s, reason=%s, status=%s WHERE id=%s
                """
            values = [patient, doctor, date, time, reason, status, id]
            cursor.execute(sql, values)
            conn.commit()
            self.show_appointments_in_db()

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()




#########################################################################
#########################################################################
#########################################################################
#########################################################################
#########################################################################
#########################################################################
#########################################################################

    def delete_appointment(self, instance):
        self.deleteAppointment = instance.id
        delete_appointment = ConfirmPopUp()
        delete_appointment.title = "Are you sure you want to delete this appointment?"
        delete_appointment.callback = self.delete_patient_callback
        delete_appointment.open()

    def delete_patient_callback(self, *args):
        id = self.deleteAppointment
        conn = connection()
        cursor = conn.cursor()
        try:
            sql = "DELETE FROM appointments WHERE id = %s"
            values = [id]
            cursor.execute(sql, values)
            conn.commit()
            self.show_appointments_in_db()

        except Exception as error:
            warning_pop_up = WarningPopUp()
            warning_pop_up.title = f"{error}"
            warning_pop_up.open()

        finally:
            if conn:
                conn.close()












