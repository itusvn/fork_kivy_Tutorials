from kivy.uix.modalview import ModalView
from kivy.lang import Builder
from kivy.properties import StringProperty, ObjectProperty
from kivymd.uix.pickers import MDModalDatePicker

Builder.load_string("""
<ToDoModal>:
    background: ""
    background_color: [0,0,0,0]
    
    BoxLayout:
        orientation: "vertical"
        padding: "10dp"
        spacing: "40dp"
        canvas.before:
            Color:
                rgba: [1,1,1,1]
            Rectangle:
                pos: self.pos
                size: self.size
                
        BoxLayout:
            size_hint_y: None
            height: "30dp"
            spacing: "10dp"
            
            FloatLayout:
                size_hint_x: None
                width: self.height
                
                MDIconButton:
                    icon: "arrow-left"
                    theme_text_color: "Custom"
                    text_color: "#8d8a8c"
                    on_press: root.dismiss()
                    pos_hint: {"center_x": 0.5, "center_y": 0.5}
                    
            MDLabel:
                text: "My Task"
                font_style: "Title"
                role: "small"
                bold: True
                
        BoxLayout:
            orientation: "vertical"
            spacing: "10dp"
            
            BoxLayout:
                size_hint_y: None
                height: "30dp"
                padding: ["10dp", 0]
                spacing: "10dp"
                canvas.before:
                    Color:
                        rgba: rgba("#8d8a8c")
                    Line:
                        rounded_rectangle: self.x, self.y, self.width, self.height, 1
                        width: 1

                FloatLayout:
                    size_hint_x: None
                    width: self.height

                    MDIcon:
                        icon: "format-title"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}

                TextField:
                    id: title
                    multiline: False
                    hint_text: "Title..."
            
            BoxLayout:
                size_hint_y: None
                height: "30dp"
                padding: ["10dp", 0]
                spacing: "10dp"
                canvas.before:
                    Color:
                        rgba: rgba("#8d8a8c")
                    Line:
                        rounded_rectangle: self.x, self.y, self.width, self.height, 1
                        width: 1

                FloatLayout:
                    size_hint_x: None
                    width: self.height

                    MDIcon:
                        icon: "calendar"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}

                MDLabel:
                    id: due
                    font_style: "Label"
                    role: "small"

                FloatLayout:
                    size_hint_x: None
                    width: self.height

                    MDIconButton:
                        icon: "calendar"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}
                        on_press: root.show_date_picker()
            
            BoxLayout:
                size_hint_y: None
                height: "30dp"
                padding: ["10dp", 0]
                spacing: "10dp"
                canvas.before:
                    Color:
                        rgba: rgba("#8d8a8c")
                    Line:
                        rounded_rectangle: self.x, self.y, self.width, self.height, 1
                        width: 1

                FloatLayout:
                    size_hint_x: None
                    width: self.height

                    MDIcon:
                        icon: "fire"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}

                CustomDropDown:
                    id: priority
                    text: "Select priority level..."
                    values: ["Urgent","High","Medium","Low"]
            
            BoxLayout:
                padding: ["10dp", 0]
                spacing: "10dp"
                canvas.before:
                    Color:
                        rgba: rgba("#8d8a8c")
                    Line:
                        rounded_rectangle: self.x, self.y, self.width, self.height, 1
                        width: 1

                TextField:
                    id: notes
                    hint_text: "Notes (Optional)..."

            MDLabel:
                id: modal_error
                size_hint_y: None
                height: "20dp"
                halign: "center"
                font_style: "Label"
                role: "small"

            Button:
                background_normal: ""
                background_down: ""
                background_color: [0,0,0,0]
                size_hint_y: None
                height: "35dp"
                text: "save"
                color: "#ffffff"
                font_size: "12sp"
                font_name: app.bold
                on_press: root.callback(root)
                canvas.before:
                    Color:
                        rgba: rgba("#556d2f")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [5,5,5,5]
""")

class ToDoModal(ModalView):
    id = StringProperty()
    title = StringProperty()
    due = StringProperty()
    priority = StringProperty()
    notes = StringProperty()
    close = StringProperty()
    callback = ObjectProperty(allownone = True)

    def show_date_picker(self):
        date_picker = MDModalDatePicker(
            scrim_color = [0.3,0.4,0.1,0.5],
            radius = [5,5,5,5],
            size_hint = [0.9, 0.8]
        )
        date_picker.bind(on_ok = self.on_date_ok)
        date_picker.bind(on_cancel = self.on_date_cancel)
        date_picker.open()

    def on_date_ok(self, instance_date_picker):
        self.ids.due.text = str(instance_date_picker.get_date()[0])
        instance_date_picker.dismiss()

    def on_date_cancel(self, instance_date_picker):
        instance_date_picker.dismiss()

    def on_title(self, instance, title):
        self.ids.title.text = title

    def on_due(self, instance, due):
        self.ids.due.text = due

    def on_priority(self, instance, priority):
        self.ids.priority.text = priority

    def on_notes(self, instance, notes):
        self.ids.notes.text = notes

    def on_close(self, instance, close):
        self.dismiss()






