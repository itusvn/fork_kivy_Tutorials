from kivy.properties import StringProperty, ObjectProperty
from kivymd.uix.card import MDCard
from kivy.lang import Builder

Builder.load_string("""
<ToDoTab>:
    orientation: "vertical"
    size_hint_y: None
    height: "100dp"
    padding: "10dp"
    spacing: "10dp"
    style: "elevated"
    radius: [5,5,5,5]
    theme_bg_color: "Custom"
    md_bg_color: "#ffffff"
    
    MDLabel:
        size_hint_y: None
        height: "20dp"
        text: root.due
        font_style: "Label"
        role: "small"
        color: "#8d8a8c"
        halign: "right"
        
    MDLabel:
        text: root.title
        font_style: "Title"
        role: "medium"
        bold: True
        text_size: self.width, None
        shorten: True
        shorten_from: "right"
        
    BoxLayout:
        size_hint_y: None
        height: "35dp"
        spacing: "10dp"
        
        FloatLayout:
            size_hint_x: None
            width: self.height
            
            MDIcon:
                icon: "fire"
                theme_text_color: "Custom"
                text_color: [1,0,0,0.8] if root.priority == "Urgent" else [1,1,0,0.8] if root.priority == "High" else [0,1,0,0.8] if root.priority == "Medium" else [0,0,1,0.8]
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
        BoxLayout:
            
        FloatLayout:
            size_hint_x: None
            width: self.height
            
            MDIconButton:
                icon: "delete-outline"
                theme_text_color: "Custom"
                text_color: "#ff6666"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                on_press: root.delete_callback(root)
        
        FloatLayout:
            size_hint_x: None
            width: self.height
            
            MDIconButton:
                icon: "update"
                theme_text_color: "Custom"
                text_color: "#556d2f"
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                on_press: root.update_callback(root)
        
        FloatLayout:
            size_hint_x: None
            width: self.height
            
            MDCheckbox:
                pos_hint: {"center_x": 0.5, "center_y": 0.5}
                
""")

class ToDoTab(MDCard):
    id = StringProperty()
    title = StringProperty()
    due = StringProperty()
    priority = StringProperty()
    notes = StringProperty()
    update_callback = ObjectProperty(allownone = True)
    delete_callback = ObjectProperty(allownone = True)
