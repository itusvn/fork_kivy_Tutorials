from kivy.uix.floatlayout import FloatLayout
from kivy.uix.modalview import ModalView
from kivy.properties import ObjectProperty, StringProperty, ListProperty
from kivy.lang import Builder

Builder.load_string("""
<ConfirmPopUp>:
    background: ''
    background_color: [0,0,0,0.1]

    MDCard:
        orientation: "vertical"
        radius: "5dp"
        size_hint: None,None
        size: "300dp", "120dp"
        padding: "10dp"
        spacing: "10dp"

        MDLabel:
            text: root.title
            halign: "center"
            font_style: "Title"
            role: "small"
            
        BoxLayout:
            size_hint_y: None
            height: "35dp"
            spacing: "15dp"
            
            BoxLayout:
            
            FloatLayout:
                size_hint_x: None
                width: self.height
                canvas.before:
                    Color:
                        rgba: rgba("#ff6666")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [self.height]
                        
                MDIconButton:
                    icon: "close"
                    theme_text_color: "Custom"
                    text_color: "#ffffff"
                    pos_hint: {"center_x":0.5, "center_y": 0.5}
                    on_release: root.dismiss()
            
            FloatLayout:
                size_hint_x: None
                width: self.height
                canvas.before:
                    Color:
                        rgba: rgba("#556d2f")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [self.height]
                        
                MDIconButton:
                    icon: "check"
                    theme_text_color: "Custom"
                    text_color: "#ffffff"
                    pos_hint: {"center_x":0.5, "center_y": 0.5}
                    on_release: 
                        root.dismiss()
                        root.callback(self)

##############################################################

<WarningPopUp>:
    background: ''
    background_color: [0,0,0,0.1]

    MDCard:
        orientation: "vertical"
        radius: "5dp"
        size_hint: None,None
        size: "400dp", "120dp"
        padding: "10dp"
        spacing: "10dp"

        MDLabel:
            text: root.title
            halign: "center"
            font_style: "Title"
            role: "small"

        BoxLayout:
            size_hint_y: None
            height: "30dp"
            spacing: "15dp"

            BoxLayout:
            
            FloatLayout:
                size_hint_x: None
                width: self.height
                canvas.before:
                    Color:
                        rgba: rgba("#ff6666")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [self.height]
                        
                MDIconButton:
                    icon: "close"
                    theme_text_color: "Custom"
                    text_color: "#ffffff"
                    pos_hint: {"center_x":0.5, "center_y": 0.5}
                    on_release: root.dismiss()

""")


class ConfirmPopUp(ModalView):
    title = StringProperty()
    callback = ObjectProperty(allownone=True)


class WarningPopUp(ModalView):
    title = StringProperty()
