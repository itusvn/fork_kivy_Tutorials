from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.spinner import Spinner
from kivy.properties import StringProperty, ListProperty
from kivy.uix.behaviors import ToggleButtonBehavior, ButtonBehavior

Builder.load_string("""
<CustomDropDown>:
    MDIcon:
        id: icon
        icon: "chevron-down"
        theme_text_color: "Custom"
        text_color: "#8D8A8C"
        pos_hint: {"center_x":0.1, "center_y":0.5}

    Spinner:
        id: spinner
        text: root.text
        values: root.values
        font_size: "11sp"
        sync_width: True
        sync_height: True
        color: "#8D8A8C"
        option_cls: Factory.sp
        background_color: [0,0,0,0]
        background_normal: ''
        background_down: ''
        pos_hint: {"center_x":0.5, "center_y":0.5}

""")

class CustomDropDown(FloatLayout):
    text = StringProperty()
    values = ListProperty()