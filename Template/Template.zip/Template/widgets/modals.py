from kivy.uix.modalview import ModalView
from kivy.lang import Builder
from kivymd.uix.filemanager import MDFileManager
from kivy.properties import StringProperty, ObjectProperty
from kivymd.uix.pickers import MDModalDatePicker, MDTimePickerDialVertical

Builder.load_string("""
""")