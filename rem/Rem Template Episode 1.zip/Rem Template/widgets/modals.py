from kivy.uix.modalview import ModalView
from kivy.lang import Builder
from kivymd.uix.filemanager import MDFileManager
from kivy.properties import StringProperty, ObjectProperty
from kivymd.uix.pickers import MDModalDatePicker, MDTimePickerDialVertical

Builder.load_string("""
<PropertyModal>:
    background: ""
    background_color: [0,0,0,0]
    
    AnchorLayout:
        anchor_x: "center"
        anchor_y: "center"
        
        BoxLayout:
            orientation: "vertical"
            size_hint: 1/3, 4/5
            padding: "10dp"
            spacing: "40dp"
            canvas.before:
                Color:
                    rgba: [1,1,1,1]
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [5,5,5,5]
                    
            BoxLayout:
                size_hint_y: None
                height: "40dp"
                spacing: "10dp"
                
                MDLabel:
                    id: modal_title
                    text: "Add property"
                    font_style: "Label"
                    role: "large"
                    bold: True
                    
                FloatLayout:
                    size_hint_x: None
                    width: self.height
                    
                    MDIconButton:
                        icon: "close"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}
                        on_press: root.dismiss()
                        
            BoxLayout:
                orientation: "vertical"
                spacing: "10dp"
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "60dp"
                            text: "Name"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        TextField:
                            id: name
                            hint_text: "Property name..."
                            multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "60dp"
                            text: "Address"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        TextField:
                            id: address
                            hint_text: "Property address..."
                            multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "60dp"
                            text: "Value"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        TextField:
                            id: value
                            hint_text: "Property value..."
                            multiline: False
                            input_filter: "float"
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "60dp"
                            text: "Rent"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        TextField:
                            id: rent
                            hint_text: "Property monthly rent..."
                            multiline: False
                            input_filter: "float"
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "60dp"
                            text: "Tenant"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        CustomDropDown:
                            id: tenant
                            text: "Select current tenant..."
                            values: ["None", "Tate", "Sandra", "Keith"]
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "60dp"
                            text: "Type"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        CustomDropDown:
                            id: type
                            text: "Select property type..."
                            values: ["Apartment", "Condominium", "Townhouse", "Penthouse", "Villa", "Farmhouse"]
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "60dp"
                            text: "Status"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        CustomDropDown:
                            id: status
                            text: "Select property status..."
                            values: ["Available", "Under lease", "Rented", "Under renovation", "Under construction"]
                            
                BoxLayout:
                    size_hint_y: None
                    height: "50dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        BoxLayout:
                            orientation: "vertical"
                            size_hint_x: None
                            width: "60dp"
                            
                            MDLabel:
                                size_hint_y: None
                                height: "35dp"
                                text: "Notes"
                                font_style: "Label"
                                role: "medium"
                                bold: True
                            
                            BoxLayout:
                            
                        TextField:
                            id: notes
                            hint_text: "Property notes (Optional)..."
                            
                CustomFlatButton:
                    id: avatar
                    size_hint_y: None
                    height: "35dp"
                    text: "Add Image"
                    on_press: root.add_image()
                    
                MDLabel:
                    id: error
                    size_hint_y: None
                    height: "30dp"
                    font_style: "Label"
                    role: "small"
                    halign: "center"
                    
                            
                CustomFlatButton:
                    id: modal_button
                    size_hint_y: None
                    height: "35dp"
                    text: "Add"
                    on_press: root.callback(root)
                    
                BoxLayout:

################################################################TRANSACTIONS MODAL
<TransactionModal>:
    background: ""
    background_color: [0,0,0,0]
    
    AnchorLayout:
        anchor_x: "center"
        anchor_y: "center"
        
        BoxLayout:
            orientation: "vertical"
            size_hint: 1/3, 4/5
            padding: "10dp"
            spacing: "40dp"
            canvas.before:
                Color:
                    rgba: [1,1,1,1]
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [5,5,5,5]
                    
            BoxLayout:
                size_hint_y: None
                height: "40dp"
                spacing: "10dp"
                
                MDLabel:
                    id: modal_title
                    text: "Add transaction"
                    font_style: "Label"
                    role: "large"
                    bold: True
                    
                FloatLayout:
                    size_hint_x: None
                    width: self.height
                    
                    MDIconButton:
                        icon: "close"
                        theme_text_color: "Custom"
                        text_color: "#8d8a8c"
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}
                        on_press: root.dismiss()
                        
            BoxLayout:
                orientation: "vertical"
                spacing: "10dp"
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "65dp"
                            text: "Date"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "60dp"
                            text: "Address"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        TextField:
                            id: address
                            hint_text: "Property address..."
                            multiline: False
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "60dp"
                            text: "Value"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        TextField:
                            id: value
                            hint_text: "Property value..."
                            multiline: False
                            input_filter: "float"
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "60dp"
                            text: "Rent"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        TextField:
                            id: rent
                            hint_text: "Property monthly rent..."
                            multiline: False
                            input_filter: "float"
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "60dp"
                            text: "Tenant"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        CustomDropDown:
                            id: tenant
                            text: "Select current tenant..."
                            values: ["None", "Tate", "Sandra", "Keith"]
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "60dp"
                            text: "Type"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        CustomDropDown:
                            id: type
                            text: "Select property type..."
                            values: ["Apartment", "Condominium", "Townhouse", "Penthouse", "Villa", "Farmhouse"]
                
                BoxLayout:
                    size_hint_y: None
                    height: "35dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        MDLabel:
                            size_hint_x: None
                            width: "60dp"
                            text: "Status"
                            font_style: "Label"
                            role: "medium"
                            bold: True
                            
                        CustomDropDown:
                            id: status
                            text: "Select property status..."
                            values: ["Available", "Under lease", "Rented", "Under renovation", "Under construction"]
                            
                BoxLayout:
                    size_hint_y: None
                    height: "50dp"
                    padding: "1dp"
                    canvas.before:
                        Color:
                            rgba: rgba("#e9e9e9")
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
                            
                    BoxLayout:
                        padding: ["10dp", "2.5dp"]
                        spacing: "10dp"
                        canvas.before:
                            Color:
                                rgba: rgba("#f5f5f5")
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [5,5,5,5]
                                
                        BoxLayout:
                            orientation: "vertical"
                            size_hint_x: None
                            width: "60dp"
                            
                            MDLabel:
                                size_hint_y: None
                                height: "35dp"
                                text: "Notes"
                                font_style: "Label"
                                role: "medium"
                                bold: True
                            
                            BoxLayout:
                            
                        TextField:
                            id: notes
                            hint_text: "Property notes (Optional)..."
                            
                CustomFlatButton:
                    id: avatar
                    size_hint_y: None
                    height: "35dp"
                    text: "Add Image"
                    on_press: root.add_image()
                    
                MDLabel:
                    id: error
                    size_hint_y: None
                    height: "30dp"
                    font_style: "Label"
                    role: "small"
                    halign: "center"
                    
                            
                CustomFlatButton:
                    id: modal_button
                    size_hint_y: None
                    height: "35dp"
                    text: "Add"
                    on_press: root.callback(root)
                    
                BoxLayout:


""")

class PropertyModal(ModalView):
    id = StringProperty()
    avatar = StringProperty()
    name = StringProperty()
    address = StringProperty()
    value = StringProperty()
    rent = StringProperty()
    tenant = StringProperty()
    type = StringProperty()
    status = StringProperty()
    notes = StringProperty()
    close = StringProperty()
    callback = ObjectProperty(allownone = True)

    def on_name(self, instance, name):
        self.ids.name.text = name
        self.ids.modal_title.text = "Update property"
        self.ids.modal_button.text = "Update"

    def on_address(self, instance, address):
        self.ids.address.text = address

    def on_value(self, instance, value):
        self.ids.value.text = value

    def on_rent(self, instance, rent):
        self.ids.rent.text = rent

    def on_tenant(self, instance, tenant):
        self.ids.tenant.text = tenant

    def on_type(self, instance, type):
        self.ids.type.text = type

    def on_status(self, instance, status):
        self.ids.status.text = status

    def on_notes(self, instance, notes):
        self.ids.notes.text = notes

    def on_close(self, instance, close):
        self.dismiss()

#############################################################TRANSACTION MODAL

class TransactionModal(ModalView):
    id = StringProperty()
    date = StringProperty()
    property = StringProperty()
    amount = StringProperty()
    type = StringProperty()
    details = StringProperty()
    close = StringProperty()
    callback = ObjectProperty(allownone = True)

    def on_date(self, instance, date):
        self.ids.date.text = date
        self.ids.modal_title.text = "Update transaction"
        self.ids.modal_button.text = "Update"

    def on_property(self, instance, property):
        self.ids.property.text = property

    def on_amount(self, instance, amount):
        self.ids.amount.text = amount

    def on_type(self, instance, type):
        self.ids.type.text = type

    def on_details(self, instance, details):
        self.ids.details.text = details

    def on_close(self, instance, close):
        self.dismiss()
