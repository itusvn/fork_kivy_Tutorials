
from kivy.lang import Builder
from kivy.properties import StringProperty, NumericProperty, ColorProperty
from kivy.uix.boxlayout import BoxLayout

Builder.load_string("""
<InfoCard>:
    orientation: "vertical"
    size_hint_y: None
    height: self.minimum_height
    padding: "1dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [5,5,5,5]
            
    BoxLayout:            
        orientation: "vertical"
        size_hint_y: None
        height: self.minimum_height
        padding: "10dp"
        spacing: "10dp"
        canvas.before:
            Color:
                rgba: rgba("#f5f5f5")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [5,5,5,5]
    
        BoxLayout:
            size_hint_y: None
            height: "30dp"
            spacing: "10dp"

            BoxLayout:
                size_hint_x: None
                width: self.height
                padding: "1dp"
                canvas.before:
                    Color:
                        rgba: rgba("#e9e9e9")
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [5,5,5,5]
    
                FloatLayout:
                    canvas.before:
                        Color:
                            rgba: [1,1,1,1]
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [5,5,5,5]
        
                    MDIcon:
                        icon: root.icon
                        theme_text_color: "Custom"
                        text_color: "#556B2F"
                        pos_hint: {"center_x": 0.5, "center_y": 0.5}
    
            MDLabel:
                text: root.heading
                font_style: "Label"
                role: "large"
                bold: True
                color: [0,0,0,1]
    
        MDLabel:
            size_hint_y: None
            height: "30dp"
            text: root.sub_heading
            font_style: "Label"
            role: "small"
            halign: "right"
            color: [0,0,0,1]
    
        MDLabel:
            size_hint_y: None
            height: "30dp"
            text: str(root.total)
            font_style: "Label"
            role: "large"
            bold: True
            halign: "right"
            color: [0,0,0,1]
""")

class InfoCard(BoxLayout):
    icon = StringProperty()
    heading = StringProperty()
    sub_heading = StringProperty()
    total = NumericProperty()
