from kivy.uix.boxlayout import BoxLayout
from kivy.uix.behaviors import ButtonBehavior
from kivy.properties import StringProperty, ObjectProperty
from kivy.lang import Builder

Builder.load_string("""
<DashPropertyTab>:
    padding: [0,0,0,"2dp"]
    size_hint_y: None
    height: "40dp"
    spacing: "10dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        Rectangle:
            pos: self.pos
            size: [self.size[0], dp(1)]
            
    BoxLayout:
        size_hint_x: None
        width: self.height
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                size: self.size
                pos: self.pos
                radius: [5,5,5,5]
                source: root.avatar
                
    MDLabel:
        size_hint_x: 0.25
        text: root.name
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.25
        text: root.address
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.2
        text: root.tenant
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.15
        text: root.type
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.15
        text: root.status
        font_style: "Label"
        role: "medium"
        bold: True
        
        
####################################################################PROPERTY TAB

<PropertyTab>:
    padding: [0,0,0,"2dp"]
    size_hint_y: None
    height: "40dp"
    spacing: "10dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        Rectangle:
            pos: self.pos
            size: [self.size[0], dp(1)]
            
    BoxLayout:
        size_hint_x: None
        width: self.height
        canvas.before:
            Color:
                rgba: rgba("#ffffff")
            RoundedRectangle:
                size: self.size
                pos: self.pos
                radius: [5,5,5,5]
                source: root.avatar

    MDLabel:
        size_hint_x: 0.15
        text: root.name
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.3
        text: root.address
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.1
        text: root.value
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.1
        text: root.rent
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.15
        text: root.tenant
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.1
        text: root.type
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.1
        text: root.status
        font_style: "Label"
        role: "medium"
        bold: True

    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIconButton:
            icon: "update"
            theme_text_color: "Custom"
            text_color: "#556b2f"
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            on_press: root.update_callback(root)

    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIconButton:
            icon: "delete-outline"
            theme_text_color: "Custom"
            text_color: "#ff6666"
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            on_press: root.delete_callback(root)
        
        
####################################################################TRANSACTIONS TAB

<TransactionTab>:
    padding: [0,0,0,"2dp"]
    size_hint_y: None
    height: "40dp"
    spacing: "10dp"
    canvas.before:
        Color:
            rgba: rgba("#e9e9e9")
        Rectangle:
            pos: self.pos
            size: [self.size[0], dp(1)]

    MDLabel:
        size_hint_x: 0.15
        text: root.date
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.3
        text: root.property
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.15
        text: root.amount
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.1
        text: root.type
        font_style: "Label"
        role: "medium"
        bold: True

    MDLabel:
        size_hint_x: 0.3
        text: root.details
        font_style: "Label"
        role: "medium"
        bold: True

    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIconButton:
            icon: "update"
            theme_text_color: "Custom"
            text_color: "#556b2f"
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            on_press: root.update_callback(root)

    FloatLayout:
        size_hint_x: None
        width: self.height
        
        MDIconButton:
            icon: "delete-outline"
            theme_text_color: "Custom"
            text_color: "#ff6666"
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            on_press: root.delete_callback(root)
""")

class DashPropertyTab(BoxLayout):
    id = StringProperty()
    avatar = StringProperty()
    name = StringProperty()
    address = StringProperty()
    tenant = StringProperty()
    type = StringProperty()
    status = StringProperty()

#############################################################

class PropertyTab(BoxLayout):
    id = StringProperty()
    avatar = StringProperty()
    name = StringProperty()
    address = StringProperty()
    value = StringProperty()
    rent = StringProperty()
    tenant = StringProperty()
    type = StringProperty()
    status = StringProperty()
    notes = StringProperty()
    update_callback = ObjectProperty(allownone = True)
    delete_callback = ObjectProperty(allownone = True)

#############################################################

class TransactionTab(BoxLayout):
    id = StringProperty()
    date = StringProperty()
    property = StringProperty()
    amount = StringProperty()
    type = StringProperty()
    details = StringProperty()
    update_callback = ObjectProperty(allownone = True)
    delete_callback = ObjectProperty(allownone = True)

#############################################################
