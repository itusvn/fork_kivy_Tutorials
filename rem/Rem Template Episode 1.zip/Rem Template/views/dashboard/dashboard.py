from kivy.clock import Clock
from kivy.properties import NumericProperty, ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
import numpy as np
import matplotlib.pyplot as plt
from kivy_garden.matplotlib.backend_kivyagg import FigureCanvasKivyAgg as FCK

from widgets.tables import DashPropertyTab

Builder.load_file('views/dashboard/dashboard.kv')

class Dashboard(Screen):
    total_units = NumericProperty(0)
    total_income = NumericProperty(0)
    total_expenses = NumericProperty(0)
    total_clients = NumericProperty(0)
    properties_ = ListProperty()
    def on_enter(self, *args):
        Clock.schedule_once(self.run_essentials, .1)

    def run_essentials(self, dt):
        self.show_transactions_chart()
        self.show_properties()

    def show_transactions_chart(self):
        data_x = np.arange(1,13)
        income = np.random.randint(5000, 10000, 12)
        expenses = np.random.randint(5000, 10000, 12)
        sales = np.random.randint(5000, 10000, 12)

        fig, ax = plt.subplots()

        ax.plot(data_x, income, label="income", color="blue")
        ax.fill_between(data_x, income, alpha=0.03, color="blue")

        ax.plot(data_x, expenses, label="expenses", color="purple")
        ax.fill_between(data_x, expenses, alpha=0.03, color="purple")

        ax.plot(data_x, sales, label="sales", color="green")
        ax.fill_between(data_x, sales, alpha=0.03, color="green")

        ax.set_xlabel("Months", fontsize = 6)
        ax.set_ylabel("Amount ($)", fontsize = 6)

        ax.set_xticks(data_x)
        ax.set_xticklabels(data_x, fontsize = 6)
        ax.set_yticklabels(ax.get_yticks(), fontsize = 6)

        ax.spines["top"].set_visible(False)
        ax.spines["bottom"].set_visible(False)
        ax.spines["left"].set_visible(False)
        ax.spines["right"].set_visible(False)

        fig.tight_layout()

        self.ids.transactions_chart.clear_widgets()
        self.ids.transactions_chart.add_widget(FCK(fig))

    def show_properties(self):
        self.properties_ = []
        properties_ = [1,2,3,4,5,6,7,8]
        for x in properties_:
            data = {
                "id": "1",
                "avatar": "assets/images/house.JPG",
                "name": "Zues",
                "address": "12 Somewhere Nowhere Street, Mars",
                "tenant": "Linda Something",
                "type": "Condominium",
                "status": "Occupied"
            }

            self.properties_.append(data)

    def on_properties_(self, instance, properties_):
        table = self.ids.dash_properties_list
        table.clear_widgets()
        for x in properties_:
            tableRow = DashPropertyTab()
            tableRow.id = str(x["id"])
            tableRow.avatar = str(x["avatar"])
            tableRow.name = str(x["name"])
            tableRow.address = str(x["address"])
            tableRow.tenant = str(x["tenant"])
            tableRow.type = str(x["type"])
            tableRow.status = str(x["status"])
            table.add_widget(tableRow)




















