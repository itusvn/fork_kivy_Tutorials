from kivy.clock import Clock
from kivy.properties import ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from widgets.popups import ConfirmPopUp
from widgets.tables import TransactionTab

Builder.load_file('views/transactions/transactions.kv')

class Transactions(Screen):
    transactions = ListProperty()
    def on_enter(self, *args):
        self.addTransaction = []
        self.updateTransaction = []
        self.deleteTransaction = None
        Clock.schedule_once(self.run_essentials, .1)

    def run_essentials(self, dt):
        self.show_transactions()

    def show_transactions(self):
        self.transactions = []
        transactions = [1,2,3,4,5,6,7,8]
        for x in transactions:
            data = {
                "id": "1",
                "date": "Zues",
                "property": "12 Somewhere Nowhere Street, Mars",
                "amount": "750000",
                "type": "2000",
                "details": "Linda Something"
            }

            self.transactions.append(data)

    def on_transactions(self, instance, transactions):
        table = self.ids.transactions_list
        table.clear_widgets()
        for x in transactions:
            tableRow = TransactionTab()
            tableRow.id = str(x["id"])
            tableRow.date = str(x["date"])
            tableRow.property = str(x["property"])
            tableRow.amount = str(x["amount"])
            tableRow.type = str(x["type"])
            tableRow.details = str(x["details"])
            tableRow.update_callback = self.open_modal_update
            tableRow.delete_callback = self.delete_transaction
            table.add_widget(tableRow)

################################################################OPEN MODALS

    def open_modal_add(self):
        open_modal_add = TransactionModal()
        open_modal_add.callback = self.add_transaction
        open_modal_add.open()

    def open_modal_update(self, instance):
        open_modal_update = TransactionModal()
        open_modal_update.id = instance.id
        open_modal_update.date = instance.date
        open_modal_update.property = instance.property
        open_modal_update.amount = instance.amount
        open_modal_update.type = instance.type
        open_modal_update.details = instance.details
        open_modal_update.callback = self.update_transaction
        open_modal_update.open()


################################################################ADD

    def add_transaction(self, instance):
        date = instance.ids.date.text
        property = instance.ids.property.text
        amount = instance.ids.amount.text
        type = instance.ids.type.ids.spinner.text
        details = instance.ids.details.ids.spinner.text
        if date == "" or property == "" or amount == "" or type == "" or details == "Select current details...":
            instance.ids.error.text = "Fill in al required fields!"
            instance.ids.error.color = "red"
        else:
            instance.close = "close"
            self.addTransaction = [date,property,amount,type,details]
            add_transaction = ConfirmPopUp()
            add_transaction.title = "Add transaction?"
            add_transaction.callback = self.add_transaction_callback
            add_transaction.open()

    def add_transaction_callback(self, _):
        date = self.addTransaction[1]
        property = self.addTransaction[2]
        amount = self.addTransaction[3]
        type = self.addTransaction[4]
        details = self.addTransaction[5]


################################################################UPDATE

    def update_transaction(self, instance):
        id = instance.id
        date = instance.ids.date.text
        property = instance.ids.property.text
        amount = instance.ids.amount.text
        type = instance.ids.type.ids.spinner.text
        details = instance.ids.details.text

        if date == "" or property == "" or amount == "" or type == "" or details == "Select current details...":
            instance.ids.error.text = "Fill in al required fields!"
            instance.ids.error.color = "red"
        else:
            instance.close = "close"
            self.updateTransaction = [id,date,property,amount,type,details]
            update_transaction = ConfirmPopUp()
            update_transaction.title = "Update transaction?"
            update_transaction.callback = self.update_transaction_callback
            update_transaction.open()

    def update_transaction_callback(self, _):
        id = self.updateTransaction[0]
        date = self.updateTransaction[1]
        property = self.updateTransaction[2]
        amount = self.updateTransaction[3]
        type = self.updateTransaction[4]
        details = self.updateTransaction[5]

################################################################DELETE

    def delete_transaction(self, instance):
        self.deleteTransaction = instance.id
        delete_transaction = ConfirmPopUp()
        delete_transaction.title = "Delete transaction?"
        delete_transaction.callback = self.delete_transaction_callback
        delete_transaction.open()

    def delete_transaction_callback(self, _):
        id = self.deleteTransaction
