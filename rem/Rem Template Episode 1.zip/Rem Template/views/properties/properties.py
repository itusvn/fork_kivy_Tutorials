from kivy.clock import Clock
from kivy.properties import ListProperty
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

from widgets.modals import PropertyModal
from widgets.popups import ConfirmPopUp
from widgets.tables import PropertyTab

Builder.load_file('views/properties/properties.kv')

class Properties(Screen):
    properties_ = ListProperty()
    def on_enter(self, *args):
        self.addProperty = []
        self.updateProperty = []
        self.deleteProperty = None
        Clock.schedule_once(self.run_essentials, .1)

    def run_essentials(self, dt):
        self.show_properties()

    def show_properties(self):
        self.properties_ = []
        properties_ = [1,2,3,4,5,6,7,8]
        for x in properties_:
            data = {
                "id": "1",
                "avatar": "assets/images/house.JPG",
                "name": "Zues",
                "address": "12 Somewhere Nowhere Street, Mars",
                "value": "750000",
                "rent": "2000",
                "tenant": "Linda Something",
                "type": "Condominium",
                "status": "Occupied",
                "notes": "Occupied"
            }

            self.properties_.append(data)

    def on_properties_(self, instance, properties_):
        table = self.ids.properties_list
        table.clear_widgets()
        for x in properties_:
            tableRow = PropertyTab()
            tableRow.id = str(x["id"])
            tableRow.avatar = str(x["avatar"])
            tableRow.name = str(x["name"])
            tableRow.address = str(x["address"])
            tableRow.value = str(x["value"])
            tableRow.rent = str(x["rent"])
            tableRow.tenant = str(x["tenant"])
            tableRow.type = str(x["type"])
            tableRow.status = str(x["status"])
            tableRow.notes = str(x["notes"])
            tableRow.update_callback = self.open_modal_update
            tableRow.delete_callback = self.delete_property
            table.add_widget(tableRow)

################################################################OPEN MODALS

    def open_modal_add(self):
        open_modal_add = PropertyModal()
        open_modal_add.callback = self.add_property
        open_modal_add.open()

    def open_modal_update(self, instance):
        open_modal_update = PropertyModal()
        open_modal_update.id = instance.id
        open_modal_update.avatar = instance.avatar
        open_modal_update.name = instance.name
        open_modal_update.address = instance.address
        open_modal_update.value = instance.value
        open_modal_update.rent = instance.rent
        open_modal_update.tenant = instance.tenant
        open_modal_update.type = instance.type
        open_modal_update.status = instance.status
        open_modal_update.notes = instance.notes
        open_modal_update.callback = self.update_property
        open_modal_update.open()


################################################################ADD

    def add_property(self, instance):
        avatar = instance.ids.avatar.text
        name = instance.ids.name.text
        address = instance.ids.address.text
        value = instance.ids.value.text
        rent = instance.ids.rent.text
        tenant = instance.ids.tenant.ids.spinner.text
        type = instance.ids.type.ids.spinner.text
        status = instance.ids.status.ids.spinner.text
        notes = instance.ids.notes.text

        if name == "" or address == "" or value == "" or rent == "" or tenant == "Select current tenant..." or type == "Select property type..." or status == "Select property status...":
            instance.ids.error.text = "Fill in al required fields!"
            instance.ids.error.color = "red"
        else:
            instance.close = "close"
            self.addProperty = [avatar,name,address,value,rent,tenant,type,status,notes]
            add_property = ConfirmPopUp()
            add_property.title = "Add property?"
            add_property.callback = self.add_property_callback
            add_property.open()

    def add_property_callback(self, _):
        avatar = self.addProperty[0]
        name = self.addProperty[1]
        address = self.addProperty[2]
        value = self.addProperty[3]
        rent = self.addProperty[4]
        tenant = self.addProperty[5]
        type = self.addProperty[6]
        status = self.addProperty[7]
        notes = self.addProperty[8]


################################################################UPDATE

    def update_property(self, instance):
        id = instance.id
        avatar = instance.ids.avatar.text
        name = instance.ids.name.text
        address = instance.ids.address.text
        value = instance.ids.value.text
        rent = instance.ids.rent.text
        tenant = instance.ids.tenant.ids.spinner.text
        type = instance.ids.type.ids.spinner.text
        status = instance.ids.status.ids.spinner.text
        notes = instance.ids.notes.text

        if name == "" or address == "" or value == "" or rent == "" or tenant == "Select current tenant..." or type == "Select property type..." or status == "Select property status...":
            instance.ids.error.text = "Fill in al required fields!"
            instance.ids.error.color = "red"
        else:
            instance.close = "close"
            self.updateProperty = [id,avatar,name,address,value,rent,tenant,type,status,notes]
            update_property = ConfirmPopUp()
            update_property.title = "Update property?"
            update_property.callback = self.update_property_callback
            update_property.open()

    def update_property_callback(self, _):
        id = self.updateProperty[0]
        avatar = self.updateProperty[1]
        name = self.updateProperty[2]
        address = self.updateProperty[3]
        value = self.updateProperty[4]
        rent = self.updateProperty[5]
        tenant = self.updateProperty[6]
        type = self.updateProperty[7]
        status = self.updateProperty[8]
        notes = self.updateProperty[9]

################################################################DELETE

    def delete_property(self, instance):
        self.deleteProperty = instance.id
        delete_property = ConfirmPopUp()
        delete_property.title = "Delete property?"
        delete_property.callback = self.delete_property_callback
        delete_property.open()

    def delete_property_callback(self, _):
        id = self.deleteProperty
