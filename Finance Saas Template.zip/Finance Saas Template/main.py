from app import MainApp

MainApp().run()